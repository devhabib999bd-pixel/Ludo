-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 04, 2025 at 09:39 AM
-- Server version: 5.6.38
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lodu_bd1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`, `last_login`, `updated_at`, `created_at`) VALUES
(1, 'admin', '$2y$10$Uo4BUxWmaSLQEqxLzmm.WOq.C9HBK9AzLdftiDNMj1s1U/gVvCZSG', NULL, '2025-05-01 12:45:28', '2025-05-01 12:45:28'),
(2, '01405381488', '$2y$10$GU3FFpb5OQtBKlgnb9cOJO7UzZzyLActk1rRVFvR0RG8iO.kzFKJi', NULL, '2025-05-02 10:27:05', '2025-05-02 10:27:05');

-- --------------------------------------------------------

--
-- Table structure for table `deposits`
--

CREATE TABLE `deposits` (
  `id` int(11) NOT NULL,
  `user_uid` varchar(50) NOT NULL,
  `payment_method` enum('bkash','nagad','rocket') NOT NULL,
  `sender_number` varchar(15) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `transaction_id` varchar(50) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `admin_notes` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `deposits`
--

INSERT INTO `deposits` (`id`, `user_uid`, `payment_method`, `sender_number`, `amount`, `transaction_id`, `status`, `admin_notes`, `created_at`, `updated_at`) VALUES
(1, 'user_68136b72b3a518.05251063', 'bkash', '1405381487', 50.00, 'deposit_6814789b8d29a', 'approved', NULL, '2025-05-02 07:47:39', '2025-05-02 07:51:26'),
(2, 'user_68136b72b3a518.05251063', 'bkash', '1405381487', 200.00, 'deposit_68147e455d4b2', 'rejected', '', '2025-05-02 08:11:49', '2025-05-02 08:23:46'),
(3, 'user_68136b72b3a518.05251063', 'bkash', '1405381487', 200.00, 'deposit_68147e812af72', 'approved', '', '2025-05-02 08:12:49', '2025-05-02 08:23:32'),
(4, 'user_68136b72b3a518.05251063', 'bkash', '1405381487', 200.00, 'deposit_68149f6f316f8', 'pending', NULL, '2025-05-02 10:33:19', '2025-05-02 10:33:19'),
(5, 'user_68136b72b3a518.05251063', 'bkash', '1405381487', 200.00, 'deposit_68149f71ad577', 'pending', NULL, '2025-05-02 10:33:21', '2025-05-02 10:33:21'),
(6, 'user_68136b72b3a518.05251063', 'bkash', '1405381487', 200.00, 'deposit_6814a12e0db12', 'pending', NULL, '2025-05-02 10:40:46', '2025-05-02 10:40:46'),
(7, 'user_68136b72b3a518.05251063', 'bkash', '1405381487', 200.00, 'deposit_6814a14c8bfdd', 'pending', NULL, '2025-05-02 10:41:16', '2025-05-02 10:41:16'),
(8, 'user_68136b72b3a518.05251063', 'bkash', '1405381487', 200.00, 'deposit_6814a179a1049', 'pending', NULL, '2025-05-02 10:42:01', '2025-05-02 10:42:01'),
(9, 'user_68136b72b3a518.05251063', 'bkash', '1405381487', 200.00, 'deposit_6814a1ada510f', 'pending', NULL, '2025-05-02 10:42:53', '2025-05-02 10:42:53'),
(10, 'user_68136b72b3a518.05251063', 'bkash', '1405381487', 200.00, 'deposit_6814a1c1afbb8', 'pending', NULL, '2025-05-02 10:43:13', '2025-05-02 10:43:13'),
(11, 'user_68136b72b3a518.05251063', 'bkash', '0', 10.00, 'deposit_6814fa1c56721', 'approved', NULL, '2025-05-02 17:00:12', '2025-05-02 17:03:21'),
(12, 'user_68136b72b3a518.05251063', 'bkash', '0', 10.00, 'deposit_6814fb149b7f1', 'approved', NULL, '2025-05-02 17:04:20', '2025-05-02 17:04:20');

-- --------------------------------------------------------

--
-- Table structure for table `matches`
--

CREATE TABLE `matches` (
  `id` int(11) NOT NULL,
  `match_title` varchar(100) NOT NULL,
  `match_description` varchar(255) NOT NULL,
  `match_type` enum('classic','tdm','freefire','custom') NOT NULL,
  `entry_fee` decimal(10,2) DEFAULT NULL,
  `total_players` int(11) DEFAULT NULL,
  `joined_players` int(11) NOT NULL DEFAULT '0',
  `total_price` varchar(50) DEFAULT NULL,
  `version` varchar(50) NOT NULL DEFAULT 'Mobile',
  `board_type` varchar(50) NOT NULL DEFAULT 'Ludo King',
  `room_id` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `match_time` datetime DEFAULT NULL,
  `status` enum('waiting','ongoing','completed') DEFAULT 'waiting'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `matches`
--

INSERT INTO `matches` (`id`, `match_title`, `match_description`, `match_type`, `entry_fee`, `total_players`, `joined_players`, `total_price`, `version`, `board_type`, `room_id`, `created_by`, `match_time`, `status`) VALUES
(1, 'Special Big legend Match ?', 'Hi', 'classic', 20.00, 2, 1, '200', 'Mobile', '0', '1224', 'Admin', '2025-05-02 18:14:00', 'waiting');

-- --------------------------------------------------------

--
-- Table structure for table `match_participants`
--

CREATE TABLE `match_participants` (
  `id` int(11) NOT NULL,
  `match_id` int(11) DEFAULT NULL,
  `user_uid` varchar(50) DEFAULT NULL,
  `game_name` varchar(50) DEFAULT NULL,
  `joined_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `match_participants`
--

INSERT INTO `match_participants` (`id`, `match_id`, `user_uid`, `game_name`, `joined_at`) VALUES
(1, 1, 'user_68136b72b3a518.05251063', 'Md', '2025-05-02 18:20:44');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `id` int(11) NOT NULL,
  `notice` varchar(255) NOT NULL,
  `notification` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `received`
--

CREATE TABLE `received` (
  `id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `agent` varchar(100) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `txid` varchar(255) NOT NULL,
  `used_txid` varchar(10) DEFAULT 'false',
  `received_at` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `received`
--

INSERT INTO `received` (`id`, `type`, `agent`, `amount`, `txid`, `used_txid`, `received_at`) VALUES
(1, '', '', 0.00, '', 'true', '2025-05-02 18:20:23'),
(2, 'BKASH', '01821764249', 10.00, 'CE28SFCN0A', 'true', '2025-05-02 18:44:01');

-- --------------------------------------------------------

--
-- Table structure for table `referral_earnings`
--

CREATE TABLE `referral_earnings` (
  `id` int(11) NOT NULL,
  `user_uid` varchar(50) DEFAULT NULL,
  `referred_user_uid` varchar(50) DEFAULT NULL,
  `bonus_amount` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `site_info`
--

CREATE TABLE `site_info` (
  `id` int(11) NOT NULL,
  `site_logo` varchar(255) NOT NULL DEFAULT 'to/logo.png',
  `site_name` varchar(100) NOT NULL DEFAULT 'LUDO BD',
  `maintenance` enum('ON','OFF') DEFAULT 'OFF',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `site_info`
--

INSERT INTO `site_info` (`id`, `site_logo`, `site_name`, `maintenance`, `created_at`, `updated_at`) VALUES
(1, 'to/logo.png', 'LUDO BD12', '', '2025-05-02 12:07:14', '2025-05-03 04:37:02');

-- --------------------------------------------------------

--
-- Table structure for table `top_players`
--

CREATE TABLE `top_players` (
  `id` int(11) NOT NULL,
  `user_uid` varchar(50) DEFAULT NULL,
  `total_wins` int(11) DEFAULT '0',
  `total_earnings` decimal(10,2) DEFAULT '0.00',
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `user_uid` varchar(50) DEFAULT NULL,
  `type` enum('deposit','withdraw','transfer','reward') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `from_balance` enum('gaming','winning') DEFAULT 'gaming',
  `to_balance` enum('gaming','winning') DEFAULT 'gaming',
  `reference_id` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `user_uid`, `type`, `amount`, `from_balance`, `to_balance`, `reference_id`, `created_at`) VALUES
(0, 'user_68136b72b3a518.05251063', 'deposit', 200.00, '', 'gaming', 'deposit_68147e455d4b2', '2025-05-02 08:11:49'),
(0, 'user_68136b72b3a518.05251063', 'deposit', 200.00, '', 'gaming', 'deposit_68147e812af72', '2025-05-02 08:12:49'),
(0, 'user_68136b72b3a518.05251063', 'withdraw', 200.00, 'winning', 'gaming', '4', '2025-05-02 08:13:23'),
(0, 'user_68136b72b3a518.05251063', 'withdraw', 200.00, 'winning', 'gaming', '5', '2025-05-02 10:33:00'),
(0, 'user_68136b72b3a518.05251063', 'deposit', 200.00, '', 'gaming', 'deposit_68149f6f316f8', '2025-05-02 10:33:19'),
(0, 'user_68136b72b3a518.05251063', 'deposit', 200.00, '', 'gaming', 'deposit_68149f71ad577', '2025-05-02 10:33:21'),
(0, 'user_68136b72b3a518.05251063', 'deposit', 200.00, '', 'gaming', 'deposit_6814a12e0db12', '2025-05-02 10:40:46'),
(0, 'user_68136b72b3a518.05251063', 'deposit', 200.00, '', 'gaming', 'deposit_6814a14c8bfdd', '2025-05-02 10:41:16'),
(0, 'user_68136b72b3a518.05251063', 'deposit', 200.00, '', 'gaming', 'deposit_6814a179a1049', '2025-05-02 10:42:01'),
(0, 'user_68136b72b3a518.05251063', 'deposit', 200.00, '', 'gaming', 'deposit_6814a1ada510f', '2025-05-02 10:42:53'),
(0, 'user_68136b72b3a518.05251063', 'deposit', 200.00, '', 'gaming', 'deposit_6814a1c1afbb8', '2025-05-02 10:43:13'),
(0, 'user_68136b72b3a518.05251063', 'deposit', 10.00, '', 'gaming', 'deposit_6814fa1c56721', '2025-05-02 17:00:12'),
(0, 'user_68136b72b3a518.05251063', 'deposit', 10.00, '', 'gaming', 'deposit_6814fb149b7f1', '2025-05-02 17:04:20'),
(0, 'user_68136b72b3a518.05251063', 'withdraw', 200.00, 'winning', 'gaming', '', '2025-05-02 17:23:33'),
(0, 'user_68136b72b3a518.05251063', '', 20.00, 'gaming', 'gaming', 'Match ID: 1', '2025-05-02 18:20:44');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_uid` varchar(50) NOT NULL,
  `fast_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_picture` varchar(255) DEFAULT 'default.png',
  `referral_code` varchar(20) DEFAULT NULL,
  `referred_by` varchar(50) DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT '0',
  `is_banned` tinyint(1) DEFAULT '0',
  `ban_reason` text,
  `match_played` int(11) DEFAULT '0',
  `total_winnings` decimal(10,2) DEFAULT '0.00',
  `winning_balance` decimal(10,2) DEFAULT '0.00',
  `gaming_balance` decimal(10,2) DEFAULT '0.00',
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_uid`, `fast_name`, `last_name`, `phone`, `password`, `profile_picture`, `referral_code`, `referred_by`, `is_verified`, `is_banned`, `ban_reason`, `match_played`, `total_winnings`, `winning_balance`, `gaming_balance`, `last_login`, `created_at`) VALUES
(1, 'user_68136b72b3a518.05251063', 'Md', 'Arman1', '01405381488', 'arman9944', 'default.png', 'MD488', NULL, 1, 0, NULL, 0, 0.00, 288.00, 1850.00, '2025-05-04 13:33:08', '2025-05-01 12:39:14'),
(2, 'user_68136bafc13d32.74861342', 'Md', 'Arman1', '01405381487', 'arman9944', 'default.png', 'MD487', 'user_68136b72b3a518.05251063', 1, 0, '', 0, 0.00, 10.00, 0.00, '2025-05-01 18:40:49', '2025-05-01 12:40:15');

-- --------------------------------------------------------

--
-- Table structure for table `wallets`
--

CREATE TABLE `wallets` (
  `id` int(11) NOT NULL,
  `bkash` varchar(50) NOT NULL,
  `nagad` varchar(50) NOT NULL,
  `rocket` varchar(50) NOT NULL,
  `refer_bonus` varchar(50) NOT NULL,
  `signup_bonus` varchar(50) NOT NULL,
  `maximum_deposit` varchar(50) NOT NULL,
  `maximum_withdraw` varchar(50) NOT NULL,
  `telegram` varchar(50) NOT NULL,
  `whatsapp` varchar(50) NOT NULL,
  `add_money` varchar(50) NOT NULL,
  `join_video` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `wallets`
--

INSERT INTO `wallets` (`id`, `bkash`, `nagad`, `rocket`, `refer_bonus`, `signup_bonus`, `maximum_deposit`, `maximum_withdraw`, `telegram`, `whatsapp`, `add_money`, `join_video`) VALUES
(1, '0123456789', '0123456789', '0123456789', '100', '50', '10000', '6', 'https://t.me/Liveludoclub', 'https://t.me/Liveludoclub', 'https://www.youtube.com/embed/jVLKcN3r2ps', 'https://www.youtube.com/embed/jVLKcN3r2ps');

-- --------------------------------------------------------

--
-- Table structure for table `withdrawals`
--

CREATE TABLE `withdrawals` (
  `id` int(11) NOT NULL,
  `user_uid` varchar(50) NOT NULL,
  `payment_method` enum('bkash','nagad','rocket') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `receiver_number` varchar(15) NOT NULL,
  `transaction_id` varchar(50) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `admin_notes` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `withdrawals`
--

INSERT INTO `withdrawals` (`id`, `user_uid`, `payment_method`, `amount`, `receiver_number`, `transaction_id`, `status`, `admin_notes`, `created_at`, `updated_at`) VALUES
(1, 'user_68136b72b3a518.05251063', 'bkash', 200.00, '01405381487', NULL, 'approved', NULL, '2025-05-02 07:48:44', '2025-05-02 08:13:53'),
(4, 'user_68136b72b3a518.05251063', 'bkash', 200.00, '01405381487', NULL, 'approved', NULL, '2025-05-02 08:13:23', '2025-05-02 08:14:01'),
(5, 'user_68136b72b3a518.05251063', 'bkash', 200.00, '01405381487', '', 'approved', '', '2025-05-02 10:33:00', '2025-05-02 17:23:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `deposits`
--
ALTER TABLE `deposits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_uid` (`user_uid`);

--
-- Indexes for table `matches`
--
ALTER TABLE `matches`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `match_participants`
--
ALTER TABLE `match_participants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `match_id` (`match_id`),
  ADD KEY `user_uid` (`user_uid`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `received`
--
ALTER TABLE `received`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `txid` (`txid`),
  ADD KEY `agent` (`agent`),
  ADD KEY `txid_2` (`txid`),
  ADD KEY `used_txid` (`used_txid`);

--
-- Indexes for table `referral_earnings`
--
ALTER TABLE `referral_earnings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_uid` (`user_uid`),
  ADD KEY `referred_user_uid` (`referred_user_uid`);

--
-- Indexes for table `site_info`
--
ALTER TABLE `site_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `top_players`
--
ALTER TABLE `top_players`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_uid` (`user_uid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `user_uid` (`user_uid`),
  ADD UNIQUE KEY `referral_code` (`referral_code`),
  ADD KEY `referred_by` (`referred_by`);

--
-- Indexes for table `wallets`
--
ALTER TABLE `wallets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_withdrawals_user_uid` (`user_uid`),
  ADD KEY `idx_withdrawals_status` (`status`),
  ADD KEY `idx_withdrawals_created_at` (`created_at`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `deposits`
--
ALTER TABLE `deposits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `matches`
--
ALTER TABLE `matches`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `match_participants`
--
ALTER TABLE `match_participants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `received`
--
ALTER TABLE `received`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `referral_earnings`
--
ALTER TABLE `referral_earnings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `site_info`
--
ALTER TABLE `site_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `top_players`
--
ALTER TABLE `top_players`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wallets`
--
ALTER TABLE `wallets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `withdrawals`
--
ALTER TABLE `withdrawals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`referred_by`) REFERENCES `users` (`user_uid`) ON DELETE SET NULL;

--
-- Constraints for table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD CONSTRAINT `fk_withdrawals_user_uid` FOREIGN KEY (`user_uid`) REFERENCES `users` (`user_uid`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
