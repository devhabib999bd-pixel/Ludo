<?php
require_once 'config.php';

// Get top players from database
$top_players = [];
$query = "SELECT u.fast_name, u.last_name, u.profile_picture, tp.total_wins, tp.total_earnings 
          FROM top_players tp
          JOIN users u ON tp.user_uid = u.user_uid
          ORDER BY tp.total_earnings DESC 
          LIMIT 20";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $top_players[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($site_name); ?> - Top Players</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <style>
        * {
            outline: none;
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            margin: 0;
            padding: 0;
        }

        a {
            text-decoration: none;
            color: inherit;
            -webkit-touch-callout: none;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
        }
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .app-header {
            background-color: #07031e;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            box-sizing: border-box;
        }

        .header-content {
            display: flex;
            align-items: center;
            width: 100%;
        }

        .logo {
            display: inline-block;
            cursor: pointer;
            padding: 10px;
        }

        .logo img {
            width: 30px;
            height: auto;
            display: block;
        }

        .app-title {
            color: white;
            font-size: 1.2em;
            flex-grow: 1;
            margin-top: 14px;
            background: linear-gradient(90deg, #ffffff 10%, #cccccc 20%, #2a5280 30%, #ffffff 40%);
            background-size: 200% auto;
            color: transparent;
            background-clip: text;
            -webkit-background-clip: text;
            text-fill-color: transparent;
            animation: shimmer 3s linear infinite;
            font-family: 'LEMONMILK-Regular', sans-serif;
            letter-spacing: 0.5px;
        }

        @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #ffffff;
            margin-bottom: 60px; /* Add space for bottom navigation */
        }

        th, td {
            text-align: left;
            padding: 12px;
            border-bottom: 1px solid #dddddd;
        }

        th {
            background-color: #1f1f1f;
            color: white;
            font-size: 16px;
        }

        td {
            font-size: 14px;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .badge {
            vertical-align: middle;
            margin-left: 5px;
            width: 20px;
            height: auto;
        }

        .player-name {
            display: flex;
            align-items: center;
        }

        .player-avatar {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            margin-right: 10px;
            object-fit: cover;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0;
            box-sizing: border-box;
        }

        /* Bottom navigation styles */
        .bottom-navigation {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: #07031e;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            z-index: 1000;
        }

        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            color: #ccc;
            text-decoration: none;
            font-size: 12px;
        }

        .nav-item img {
            width: 24px;
            height: 24px;
            margin-bottom: 5px;
        }

        .nav-item.active {
            color: #fff;
        }
    </style>
</head>
<body>

    <header class="app-header">
        <div class="header-content">
            <a href="/profile.php" class="logo">
                <img src="to/backbutton.png" alt="Back Icon">
            </a>
            <h1 class="app-title">LUDO BD</h1>
        </div>
    </header>

    <div class="container">
        <table>
            <thead>
                <tr>
                    <th>Rank</th>
                    <th>Name</th>
                    <th>Winnings</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($top_players as $index => $player): ?>
                    <tr>
                        <td><?php echo $index + 1; ?></td>
                        <td>
                            <div class="player-name">
                                <img src="uploads/profile/<?php echo htmlspecialchars($player['profile_picture']); ?>" 
                                     alt="Player" class="player-avatar"
                                     onerror="this.src='to/default-avatar.png'">
                                <?php echo htmlspecialchars($player['fast_name'] . ' ' . $player['last_name']); ?>
                                <?php if ($player['total_wins'] > 100): ?>
                                    <img src="to/vip-card.png" alt="VIP" class="badge">
                                <?php endif; ?>
                            </div>
                        </td>
                        <td><?php echo number_format($player['total_earnings'], 0); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <nav class="bottom-navigation">
        <a href="admin.php" class="nav-item">
            <img src="to/chat1.png" alt="Chat">
            <span>Chat</span>
        </a>
        <a href="index.php" class="nav-item">
            <img src="to/play2.png" alt="Play">
            <span>Play</span>
        </a>
        <a href="profile.php" class="nav-item active">
            <img src="to/profile1.png" alt="Me">
            <span>Me</span>
        </a>
    </nav>

    <script>
        // Prevent context menu from showing on right-click or long-press
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });

        // Prevent the default behavior for right-click and middle-click
        document.addEventListener('mousedown', function(e) {
            if (e.button === 2 || e.button === 3) {
                e.preventDefault();
            }
        });

        // Prevent link behavior on long press
        document.querySelectorAll('a').forEach(function(link) {
            link.addEventListener('touchstart', function() {
                this.setAttribute('data-href', this.getAttribute('href'));
                this.removeAttribute('href');
            });

            link.addEventListener('touchend', function() {
                this.setAttribute('href', this.getAttribute('data-href'));
            });

            link.addEventListener('touchmove', function() {
                this.setAttribute('href', this.getAttribute('data-href'));
            });
        });

        // Handle avatar image errors
        document.querySelectorAll('.player-avatar').forEach(img => {
            img.onerror = function() {
                this.src = 'to/default-avatar.png';
            };
        });
    </script>
</body>
</html>