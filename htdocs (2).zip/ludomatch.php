<?php
session_start();
require_once 'config.php'; // Database configuration file

// Check if user is logged in
if (!isset($_SESSION['user_uid'])) {
    header("Location: login.php");
    exit();
}

$user_uid = $_SESSION['user_uid'];

// Fetch all 'waiting' matches with join status for current user
$query = "
    SELECT m.*, 
           (SELECT COUNT(*) FROM match_participants WHERE match_id = m.id) as joined_count,
           (SELECT COUNT(*) FROM match_participants WHERE match_id = m.id AND user_uid = ?) as user_joined
    FROM matches m
    WHERE m.status = 'waiting'
    ORDER BY m.match_time DESC
";

// Prepare the query
$stmt = $conn->prepare($query);

// Check if the query preparation was successful
if ($stmt === false) {
    die('Query preparation failed: ' . $conn->error);
}

// Bind the user_uid parameter as an integer
$stmt->bind_param('i', $user_uid);

// Execute the statement
$stmt->execute();

// Get the result
$result = $stmt->get_result();

// Fetch all matches as an associative array
$matches = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($site_name); ?> - Match</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Your existing CSS styles remain the same */
        .title-date-container {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            margin-left: 8px;
        }

        .title-date-container h5,
        .title-date-container p {
            margin: 0;
            color: black;
        }

        .title-date-container p {
            font-size: 14px;
            color: #ff4b5c;
        }

        * {
            outline: none;
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
        }

        body {
            padding-top: 60px;
            background-color: #1e2538;
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            margin-top: 80px;
        }

        .card {
            border-radius: 10px;
            background-color: white;
            color: black;
            padding: 2px;
            width: 104%;
            text-align: center;
            max-width: 600px;
            margin: 60px auto;
            border: none;
            margin-bottom: -3rem;
            margin-left: -0.5rem;
            margin-right: auto;
        }

        .card-header {
            display: flex;
            background-color: #fff;
            align-items: center;
            border-bottom: 0px solid #fff;
            padding-bottom: -4em;
        }

        .card-header img {
            width: 40px;
            height: auto;
        }

        .seat-full-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 1px;
            position: relative;
        }

        .seat-full-container::before {
            content: "";
            position: absolute;
            top: 0px;
            left: 0;
            height: 4px;
            background-color: #a7c4eb;
            z-index: 1;
            width: 71%;
            margin-top: 0.7rem;
        }

        .seat-full-container .progress-bar {
            position: absolute;
            top: 0px;
            left: 0;
            height: 4px;
            z-index: 2;
            margin-top: 0.7rem;
        }

        .seat-full-text {
            color: #ff4b5c;
            font-weight: bold;
            font-size: 12px;
            padding: 4px 4px;
            border: 2px solid red;
            border-radius: 4px;
            width: 85px;
            height: 33px;
            line-height: 20px;
            text-align: center;
            box-sizing: border-box;
        }

        .btn-joined {
            background-color: #4CAF50 !important;
            color: white !important;
            border: 2px solid #4CAF50 !important;
        }

        .btn-full {
            background-color: #ff4b5c !important;
            color: white !important;
            border: 2px solid #ff4b5c !important;
        }

        .availability-text {
            color: black;
            font-weight: bold;
            font-size: 12px;
            margin-top: 0.8rem;
            margin-left: 61%;
        }

        .toast {
            position: fixed;
            bottom: 20px;
            right: 20px;
            min-width: 200px;
            z-index: 9999;
            display: none;
        }

        .toast-header {
            background-color: #28a745;
            color: white;
            font-weight: bold;
            font-size: 14px;
        }

        .toast-body {
            background-color: white;
            color: black;
            font-size: 12px;
        }

        .header {
            width: 100%;
            padding: 15px;
            border-radius: 10px;
            background-color: #0a0a35;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            margin-bottom: 20px;
            color: #fff;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }

        .header h1 {
            margin-left: -70px;
            margin-top: 10px;
            font-size: 1.3em;
            font-weight: bold;
        }

        .header img {
            height: 30px;
            width: 30px;
            margin-left: -5px;
            margin-right: 0px;
        }

        .back-button img {
            height: 25px;
            width: 25px;
            transition: transform 0.2s ease-in-out;
        }

        .back-button img:hover {
            transform: scale(1.2);
        }

        .copy-message {
            display: none;
            background-color: #dff0d8;
            color: #3c763d;
            padding: 5px;
            border-radius: 5px;
            margin-top: 10px;
            font-size: 14px;
            font-weight: bold;
            text-align: center;
        }
        
        .row.mt-3 {
            margin-top: 10px;
        }

        .btn-primary.btn-block {
            margin-bottom: 10px;
        }

        .col-6 {
            padding-right: 5px;
            padding-left: 5px;
        }
    </style>
</head>
<body>
    <div class="header">
        <a href="/index.php" class="back-button">
            <img src="to/backbutton.png" alt="Back Icon" />
        </a>
        <h1>Ludo Matches</h1>
        <a href="upload_screenshot.php">
            <img src="to/upload.png" alt="Cart Icon" />
        </a>
    </div>

    <div class="container">
        <?php foreach ($matches as $match): 
            $is_full = ($match['joined_count'] >= $match['total_players']);
            $has_joined = ($match['user_joined'] > 0);
        ?>
            <div class="card">
                <div style="margin-bottom:-1em;" class="card-header">
                    <img src="/to/lodu.png" alt="Ludo King Logo" />
                    <div class="title-date-container">
                        <h5 class="mb-0" style="font-size:17px;"><?= htmlspecialchars($match['match_title']) ?></h5>
                        <p class="mb-0"><?= htmlspecialchars($match['match_description']) ?></p>
                    </div>
                </div>
                <div style="margin-bottom:-1em;" class="card-body">
                    <div style="margin-bottom:-1em;" class="row pera">
                        <div class="col-6">
                            <p style="color: #7f8280;" class="mb-0">Total Prize</p>
                            <p class="mb-0"><strong>৳<?= number_format($match['total_price'], 2) ?></strong></p>
                        </div>
                        <div class="col-6">
                            <p style="color: #7f8280;" class="mb-0">Entry Fee</p>
                            <p class="mb-0"><strong>৳<?= number_format($match['entry_fee'], 2) ?></strong></p>
                        </div>
                    </div>
                    <div class="row mt-3 ">
                        <div class="col-6">
                            <p style="color: #7f8280;" class="mb-0">Version</p>
                            <p class="mb-0"><strong><?= htmlspecialchars($match['version']) ?></strong></p>
                        </div>
                        <div class="col-6">
                            <p style="color: #7f8280;" class="mb-0">Board Type</p>
                            <p class="mb-0"><strong><?= htmlspecialchars($match['board_type']) ?></strong></p>
                        </div>
                    </div>
                    <div class="seat-full-container">
                        <div class="progress-bar" style="width: <?= ($match['joined_count'] / $match['total_players']) * 100 ?>%; background-color: #485bd4;"></div>
                        <span class="availability-text"><?= $match['joined_count'] ?> / <?= $match['total_players'] ?></span>
                        
                        <?php if ($is_full): ?>
                            <button class="seat-full-text btn-full" disabled>FULL</button>
                        <?php elseif ($has_joined): ?>
                            <button class="seat-full-text btn-joined" disabled>JOINED</button>
                        <?php else: ?>
                            <form method="POST" action="join.php">
                                <input type="hidden" name="roomid" value="<?= $match['room_id'] ?>" />
                                <button type="submit" class="seat-full-text" style="background-color: #2d7cd6; color: #fff; border: none;">JOIN</button>
                            </form>
                        <?php endif; ?>
                    </div>
                    <div class="row mt-3">
                        <div class="col-6">
                            <a href="video.php" class="btn btn-primary btn-block">কিভাবে খেলবেন?</a>
                        </div>
                        <div class="col-6">
                            <button class="btn btn-secondary btn-block" onclick="copyRoomId('<?= $match['room_id'] ?>', <?= $match['id'] ?>)">ROOM ID</button>
                            <div id="copyMessage<?= $match['id'] ?>" class="copy-message">Room ID copied!</div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
        function copyRoomId(roomId, matchId) {
            navigator.clipboard.writeText(roomId).then(() => {
                showCopyMessage(matchId);
            }).catch(err => {
                alert('Failed to copy Room ID');
            });
        }

        function showCopyMessage(matchId) {
            const copyMessage = document.getElementById('copyMessage' + matchId);
            copyMessage.style.display = 'block';
            setTimeout(() => {
                copyMessage.style.display = 'none';
            }, 2000);
        }
    </script>
</body