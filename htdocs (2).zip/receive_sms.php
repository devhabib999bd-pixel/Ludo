<?php
header("Content-Type: application/json");

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "lodu_bd1";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    echo json_encode(["status" => "error"]);
    exit();
}

$type = $_POST['type'] ?? '';
$agent = $_POST['agent'] ?? '';
$amount = $_POST['amount'] ?? '';
$txid = $_POST['txid'] ?? '';
$received_at = date("Y-m-d H:i:s");

$type = $conn->real_escape_string($type);
$agent = $conn->real_escape_string($agent);
$amount = $conn->real_escape_string($amount);
$txid = $conn->real_escape_string($txid);

$sql = "INSERT IGNORE INTO received (type, agent, amount, txid, used_txid, received_at)
        VALUES ('$type', '$agent', '$amount', '$txid', 'false', '$received_at')";

if ($conn->query($sql) === TRUE && $conn->affected_rows > 0) {
    echo json_encode([
        "status" => "success",
        "message" => "Payment Received"
    ]);
} else {
    echo json_encode(["status" => "error"]);
}

$conn->close();
?>
