<?php
session_start();
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_uid'])) {
    header("Location: login.php");
    exit();
}

// Get wallet data from database
$stmt = $conn->prepare("SELECT add_money FROM wallets LIMIT 1");
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // Handle case when no wallet data is found
    $add_money = ""; // Set a default value or handle error
} else {
    $wallets = $result->fetch_assoc();
    $add_money = $wallets['add_money'];
}
$stmt->close();
?>

<html xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>YouTube Video Player</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f9f9f9;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
    }

    .video-player-container {
      text-align: center;
      background: white;
      padding: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      width: 400px;
    }

    .video-player-container h1 {
      margin-bottom: 20px;
      color: #333;
    }

    .video-container {
      position: relative;
      overflow: hidden;
      padding-top: 56.25%; /* Aspect ratio 16:9 */
    }

    .video-container iframe {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
    }
  </style>
</head>
<body style="">
  <div class="video-player-container">
    <h1>কিভাবে খেলবেন</h1>
    <div class="video-container">
      <iframe src="<?php echo htmlspecialchars($add_money); ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen=""></iframe>
    </div>
  </div>
</body></html>