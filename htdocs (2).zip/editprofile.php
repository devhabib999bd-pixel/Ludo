<?php
session_start();
require_once 'config.php'; // Database connection file

// Check if user is logged in
if (!isset($_SESSION['user_uid'])) {
    header("Location: login.php");
    exit();
}

// Initialize variables
$error = '';
$success = '';
$username = '';
$phone = '';

// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}
// Get current user data
$user_uid = $_SESSION['user_uid'];
$query = "SELECT fast_name, last_name, phone, gaming_balance FROM users WHERE user_uid = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $user_uid);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user) {
    $username = $user['fast_name'] . ' ' . $user['last_name'];
    $phone = $user['phone'];
    $balance = $user['gaming_balance'];
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize inputs
    $new_username = trim($_POST['username'] ?? '');
    $new_password = trim($_POST['new-password'] ?? '');
    
    // Validate username
    if (!empty($new_username)) {
        if (strlen($new_username) < 3 || strlen($new_username) > 50) {
            $error = "Username must be between 3 and 50 characters";
        } else {
            // Split into first and last name
            $name_parts = explode(' ', $new_username, 2);
            $fast_name = $name_parts[0];
            $last_name = count($name_parts) > 1 ? $name_parts[1] : '';
            
            // Update username
            $query = "UPDATE users SET fast_name = ?, last_name = ? WHERE user_uid = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("sss", $fast_name, $last_name, $user_uid);
            
            if ($stmt->execute()) {
                $success = "Username updated successfully!";
                $username = $new_username;
            } else {
                $error = "Failed to update username";
            }
        }
    }
    
// Validate and update password if provided
if (!empty($new_password)) {
    if (strlen($new_password) < 6) {
        $error = empty($error) ? "Password must be at least 6 characters long" : $error . " and password must be at least 6 characters";
    } else {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $query = "UPDATE users SET password = ? WHERE user_uid = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $hashed_password, $user_uid);
        
        if ($stmt->execute()) {
            $success = empty($success) ? "Password updated successfully!" : $success . " and password updated!";
        } else {
            $error = empty($error) ? "Failed to update password" : $error . " and failed to update password";
        }
    }
}
    
    // If no changes were made
    if (empty($new_username) && empty($new_password)) {
        $error = "No changes were made";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($site_name); ?> - Edit Profile</title>
    <style>
        * {
            outline: none;
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            color: #333;
            padding-bottom: 60px;
        }

        a {
            text-decoration: none;
            color: inherit;
            -webkit-touch-callout: none;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 15px;
        }

        .app-header {
            background-color: #07031e;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 15px;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-content {
            display: flex;
            align-items: center;
            width: 100%;
        }

        .logo img {
            width: 25px;
            height: auto;
        }

        .app-title {
            color: white;
            font-size: 1.2em;
            flex-grow: 1;
            text-align: center;
            background: linear-gradient(90deg, #ffffff 10%, #cccccc 20%, #2a5280 30%, #ffffff 40%);
            background-size: 200% auto;
            color: transparent;
            background-clip: text;
            -webkit-background-clip: text;
            text-fill-color: transparent;
            animation: shimmer 3s linear infinite;
        }

        @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }

        .wallet-icon {
            display: flex;
            align-items: center;
            padding: 5px 10px;
            border: 2px solid #fff;
            border-radius: 20px;
            background-color: #1b1a3a;
            font-size: 0.9em;
        }

        .wallet-icon img {
            height: 18px;
            margin-right: 8px;
        }

        .balance-text {
            color: white;
            font-weight: bold;
        }

        .main-content {
            text-align: center;
            padding: 20px 0;
        }

        .hamster-icon {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 15px;
            border: 3px solid #FFD700;
        }

        .description {
            color: #666;
            margin-bottom: 20px;
        }

        .tasks {
            margin-top: 20px;
        }

        .task-item {
            display: flex;
            align-items: center;
            background-color: #fff;
            padding: 12px 15px;
            border-radius: 10px;
            margin-bottom: 12px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }

        .task-icon {
            width: 25px;
            height: 25px;
            margin-right: 15px;
        }

        .task-info {
            flex: 1;
            text-align: left;
        }

        .task-info label {
            color: #333;
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
            font-size: 0.9em;
        }

        .task-info input[type="text"],
        .task-info input[type="password"] {
            width: 100%;
            padding: 8px 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
            color: #555;
        }

        .task-info button {
            padding: 8px 15px;
            background-color: #FFD700;
            color: #000;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1em;
            font-weight: bold;
            transition: background-color 0.3s;
            width: 100%;
        }

        .task-info button:hover {
            background-color: #FFC107;
        }

        .task-status {
            margin-left: 10px;
            color: #999;
            font-weight: bold;
        }

        .error-message {
            color: #d9534f;
            margin: 15px 0;
            padding: 10px;
            background-color: #f8d7da;
            border-radius: 5px;
            display: <?php echo $error ? 'block' : 'none'; ?>;
        }

        .success-message {
            color: #5cb85c;
            margin: 15px 0;
            padding: 10px;
            background-color: #d4edda;
            border-radius: 5px;
            display: <?php echo $success ? 'block' : 'none'; ?>;
        }

        .bottom-navigation {
            background-color: #07031e;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
            z-index: 100;
        }

        .nav-item {
            text-align: center;
            color: #ccc;
            font-size: 0.8em;
            transition: all 0.2s;
            padding: 5px 10px;
        }

        .nav-item img {
            width: 24px;
            height: 24px;
            margin: 0 auto 5px;
            transition: all 0.2s;
        }

        .nav-item.active, .nav-item:hover {
            color: #FFD700;
            transform: scale(1.05);
        }

        .nav-item:hover img, .nav-item.active img {
            transform: scale(1.1);
        }
    </style>
</head>
<body>
<header class="app-header">
    <div class="header-content">
        <a href="profile.php" class="logo">
            <img src="to/backbutton.png" alt="Back">
        </a>
        <h1 class="app-title"><?php echo htmlspecialchars($site_name); ?></h1>
        <div class="wallet-icon">
            <img src="to/wallet2.png" alt="Wallet">
            <span class="balance-text"><?php echo number_format($balance, 2); ?></span>
        </div>
    </div>
</header>

<div class="container">
    <div class="main-content">
        <img src="to/image.png" alt="User Icon" class="hamster-icon">
        <h2><?php echo htmlspecialchars($username); ?></h2>
        <h4><?php echo htmlspecialchars($phone); ?></h4>
        <p class="description">Edit your profile information below:</p>
        
        <?php if ($error): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
    </div>

    <section class="tasks">
        <form method="POST" action="">
            <div class="task-item">
                <img src="to/me.png" alt="User Icon" class="task-icon">
                <div class="task-info">
                    <label for="username">Name:</label>
                    <input type="text" id="username" name="username" placeholder="Enter your new username" value="<?php echo htmlspecialchars($username); ?>">
                </div>
                <div class="task-status">→</div>
            </div>
            
            <div class="task-item">
                <img src="to/new-password.png" alt="Lock Icon" class="task-icon">
                <div class="task-info">
                    <label for="new-password">New Password:</label>
                    <input type="password" id="new-password" name="new-password" placeholder="Enter your new password">
                </div>
                <div class="task-status">→</div>
            </div>
            
            <div class="task-item">
                <img src="to/save.png" alt="Save Icon" class="task-icon">
                <div class="task-info">
                    <button type="submit">Save Changes</button>
                </div>
                <div class="task-status">→</div>
            </div>
        </form>
    </section>
</div>

<nav class="bottom-navigation">
    <a href="admin.php" class="nav-item">
        <img src="to/chat1.png" alt="Chat">
        <span>Chat</span>
    </a>
    <a href="index.php" class="nav-item">
        <img src="to/play2.png" alt="Play">
        <span>Play</span>
    </a>
    <a href="profile.php" class="nav-item active">
        <img src="to/profile1.png" alt="Me">
        <span>Me</span>
    </a>
</nav>

<script>
    // Prevent zooming and context menu
    document.addEventListener('wheel', function(e) {
        if (e.ctrlKey) e.preventDefault();
    }, { passive: false });
    
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
    });
    
    // Set active nav item
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', function() {
            document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Wallet click handler
    document.querySelector('.wallet-icon').addEventListener('click', function() {
        window.location.href = 'mywallet.php';
    });
    
    // Prevent long press on links
    document.querySelectorAll('a').forEach(link => {
        link.addEventListener('touchstart', function() {
            this.dataset.href = this.href;
            this.removeAttribute('href');
        });
        
        link.addEventListener('touchend', function() {
            if (this.dataset.href) {
                this.href = this.dataset.href;
            }
        });
    });
</script>
</body>
</html>