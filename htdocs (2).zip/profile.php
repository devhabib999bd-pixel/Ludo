<?php
session_start();
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_uid'])) {
    header("Location: login.php");
    exit();
}
// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}
// Get user data from database
$user_uid = $_SESSION['user_uid'];
$stmt = $conn->prepare("SELECT fast_name, last_name, phone, profile_picture, match_played, total_winnings, gaming_balance, winning_balance FROM users WHERE user_uid = ?");
$stmt->bind_param("s", $user_uid);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: login.php");
    exit();
}

$user = $result->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($site_name); ?> - Profile</title>
    <style>
        * {
            outline: none;
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        a {
            text-decoration: none;
            color: inherit;
            -webkit-touch-callout: none;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
        }
        @font-face {
            font-family: 'HindSiliguri-Medium';
            src: url('font/HindSiliguri-Medium.ttf') format('truetype');
        }
        @font-face {
            font-family: 'HindSiliguri-Bold';
            src: url('font/HindSiliguri-Bold.ttf') format('truetype');
        }
        @font-face {
            font-family: 'LEMONMILK-Regular';
            src: url('font/LEMONMILK-Regular.otf') format('opentype');
        }
        body {
            margin: 0;
            padding: 0;
            font-family: 'HindSiliguri-Medium', Arial, sans-serif;
            background-color: #0e0b27;
            color: white;
            display: flex;
            flex-direction: column;
            height: 100vh;
            justify-content: space-between;
        }
        .app-header {
            background-color: #07031e;
            height: 56px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 5px;
        }
        .header-content {
            display: flex;
            align-items: center;
            width: 100%;
        }
        .logo {
            height: 38px; 
            margin-left: 10px;
        }
        .app-title {
            color: white;
            font-size: 1.12em;
            flex-grow: 1;
            text-align: center;
            margin-left: -80px;
            position: relative;
            display: inline-block;
            background: linear-gradient(90deg, #ffffff 10%, #cccccc 20%, #2a5280 30%, #ffffff 40%);
            background-size: 200% auto;
            color: transparent;
            background-clip: text;
            -webkit-background-clip: text;
            text-fill-color: transparent;
            animation: shimmer 3s linear infinite;
            font-family: 'LEMONMILK-Regular', sans-serif;
            letter-spacing: 0.5px;
        }
        @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }
        .wallet-icon {
            display: flex;
            align-items: center;
            padding: 5px 10px;
            border: 2px solid #fff;
            border-radius: 40px;
            background-color: #1b1a3a;
            font-size: 0.9em;
            font-family: 'HindSiliguri-Medium', sans-serif;
            cursor: pointer;
        }
        .wallet-icon img {
            height: 20px;
            margin-right: 10px;
        }
        .balance-text {
            font-size: 1.2em;
            color: white;
        }
        .main-content {
            flex-grow: 1;
            padding: 20px;
            text-align: center;
            overflow-y: auto;
        }
        .bottom-navigation {
            background-color: #07031e;
            display: flex;
            justify-content: space-around;
            padding: 0px;
            position: fixed;
            width: 100%;
            bottom: -4px;
        }
        .nav-item {
            text-align: center;
            color: #ccc;
            text-decoration: none;
            font-size: 0.8.5em;
            transition: transform 0.2s ease, color 0.2s ease, opacity 0.2s ease;
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
            opacity: 1;
            font-family: 'HindSiliguri-Medium', sans-serif;
        }
        .nav-item img {
            width: 22px;
            height: auto;
            display: block;
            margin: 0 auto 5px;
            transition: transform 0.2s ease, opacity 0.2s ease;
            -webkit-tap-highlight-color: transparent;
        }
        .nav-item:hover, .nav-item:focus, .nav-item:active {
            transform: scale(1.1);
            color: #fff;
        }
        .nav-item:hover img, .nav-item:focus img, .nav-item:active img {
            transform: scale(1.2);
        }
        .inactive {
            opacity: 0.5;
        }
        .container {
            max-width: 400px;
            margin: 0 auto;
            padding: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            background-color: #111;
            border-radius: 10px;
            margin-bottom: 1em;
        }
        .hamster-icon {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            box-shadow: 0 0 10px rgba(255, 215, 0, 0.5);
            object-fit: cover;
        }
        .main-content h3 {
            font-size: 18px;
            margin: 10px 0;
            color: #FFD700;
        }
        .main-content h5 {
            font-size: 14px;
            margin: 5px 0;
            color: #ccc;
        }
        .white-container {
            background-color: white;
            padding: 8px;
            border-radius: 10px;
            margin-bottom: 1em;
            color: #000;
            text-align: left;
        }
        .statistics {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-radius: 10px;
            color: #000;
        }
        .stat-item {
            font-size: 14px;
            text-align: center;
            flex: 1;
        }
        .stat-item:not(:last-child) {
            border-right: 1px solid #ddd;
        }
        .stat-item p {
            margin: 5px 0;
        }
        .stat-item p:first-child {
            font-weight: bold;
            font-size: 16px;
        }
        .task-item {
            display: flex;
            align-items: center;
            padding: 8px 0;
        }
        .task-icon {
            width: 25px;
            height: 25px;
            margin-right: 10px;
        }
        .task-info {
            flex: 1;
        }
        .task-info p {
            margin: 0;
            font-size: 16px;
            color: #000;
        }
        .line-separator {
            height: 1px;
            background-color: #ddd;
            margin: 5px 0;
        }
    </style>
</head>
<body>

<header class="app-header">
    <div class="header-content">
        <img src="<?php echo htmlspecialchars($site_logo); ?>" alt="Site Logo" class="logo">
        <h1 class="app-title"><?php echo htmlspecialchars($site_name); ?></h1>
        <div class="wallet-icon" id="walletIcon">
            <img src="to/wallet2.png" alt="Wallet">
            <span class="balance-text"><?php echo number_format($user['gaming_balance'], 2); ?></span>
        </div>
    </div>
</header>

<div class="main-content">
    <div class="container">
        <div class="main-content">
            <img src="uploads/profile/<?php echo htmlspecialchars($user['profile_picture']); ?>" alt="Profile Picture" class="hamster-icon">
            <h3><?php echo htmlspecialchars($user['fast_name'] . ' ' . $user['last_name']); ?></h3>
            <h5><?php echo htmlspecialchars($user['phone']); ?></h5>
        </div>

        <div class="white-container">
            <div class="statistics">
                <div class="stat-item">
                    <p><?php echo number_format($user['gaming_balance'], 2); ?></p>
                    <p>Gaming Balance</p>
                </div>
                <div class="stat-item">
                    <p><?php echo number_format($user['winning_balance'], 2); ?></p>
                    <p>Winning Balance</p>
                </div>
            </div>
        </div>

        <div class="white-container">
            <div class="statistics">
                <div class="stat-item">
                    <p><?php echo $user['match_played']; ?></p>
                    <p>Match Played</p>
                </div>
                <div class="stat-item">
                    <p><?php echo number_format($user['total_winnings'], 2); ?></p>
                    <p>Total Winnings</p>
                </div>
            </div>
        </div>

        <div class="white-container">
            <div class="task-item">
                <img src="to/me.png" alt="My Profile" class="task-icon">
                <div class="task-info">
                    <a href="editprofile.php"><p>My Profile</p></a>
                </div>
            </div>
            <div class="line-separator"></div>
            <div class="task-item">
                <img src="to/wallet.png" alt="My Wallet" class="task-icon">
                <div class="task-info">
                    <a href="mywallet.php"><p>My Wallet</p></a>
                </div>
            </div>
            <div class="line-separator"></div>
            <div class="task-item">
                <img src="to/top-player.png" alt="Top Players" class="task-icon">
                <div class="task-info">
                    <a href="topplayer.php"><p>Top Players</p></a>
                </div>
            </div>
            <div class="line-separator"></div>
            <div class="task-item">
                <img src="to/salesman.png" alt="Refer And Earn" class="task-icon">
                <div class="task-info">
                    <a href="referearn.php"><p>Refer And Earn</p></a>
                </div>
            </div>
            <div class="line-separator"></div>
            <div class="task-item">
                <img src="to/support.png" alt="Admin Support" class="task-icon">
                <div class="task-info">
                    <a href="admin.php"><p>Admin Support</p></a>
                </div>
            </div>
            <div class="line-separator"></div>
            <div class="task-item">
                <img src="to/user.png" alt="Developer Profile" class="task-icon">
                <div class="task-info">
                    <a href="developer.php"><p>Developer Profile</p></a>
                </div>
            </div>
            <div class="line-separator"></div>
            <div class="task-item">
                <img src="to/right-arrow.png" alt="Logout" class="task-icon">
                <div class="task-info">
                    <a href="logout.php"><p>Logout</p></a>
                </div>
            </div>
        </div>
    </div>
</div>

<nav class="bottom-navigation">
    <a style="color: #fff;" href="admin.php" class="nav-item" id="chat">
        <img src="to/chat1.png" alt="Chat">
        <span>Chat</span>
    </a>
    <a style="color: #fff;" href="index.php" class="nav-item" id="play">
        <img src="to/play2.png" alt="Play">
        <span>Play</span>
    </a>
    <a style="color: #fff;" href="profile.php" class="nav-item active" id="me">
        <img src="to/profile1.png" alt="Me">
        <span>Me</span>
    </a>
</nav>

<script>
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});

document.addEventListener('mousedown', function(e) {
    if (e.button === 2 || e.button === 3) {
        e.preventDefault();
    }
});

document.querySelectorAll('a').forEach(function(link) {
    link.addEventListener('touchstart', function() {
        this.setAttribute('data-href', this.getAttribute('href'));
        this.removeAttribute('href');
    });

    link.addEventListener('touchend', function() {
        this.setAttribute('href', this.getAttribute('data-href'));
    });

    link.addEventListener('touchmove', function() {
        this.setAttribute('href', this.getAttribute('data-href'));
    });
});

document.getElementById('walletIcon').addEventListener('click', function() {
    window.location.href = 'mywallet.php';
});

document.addEventListener('DOMContentLoaded', function() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        });
    });
});
</script>

</body>
</html>