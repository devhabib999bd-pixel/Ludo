<?php
session_start();
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_uid'])) {
    header("Location: login.php");
    exit();
}

// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}

// Get user wallet data from database
$user_uid = $_SESSION['user_uid'];
$stmt = $conn->prepare("SELECT gaming_balance, winning_balance FROM users WHERE user_uid = ?");
$stmt->bind_param("s", $user_uid);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: login.php");
    exit();
}

$user = $result->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($site_name); ?> - My Wallet</title>
    <style>
        * {
            outline: none;
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        a {
            text-decoration: none;
            color: inherit;
            -webkit-touch-callout: none;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
        }
        body {
            font-family: 'Arial', sans-serif;
            background-color: #0e0b27;
            color: #333;
            display: flex;
            flex-direction: column;
            height: 100vh;
            justify-content: space-between;
        }
        .app-header {
            background-color: #07031e;
            height: 56px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 5px;
        }
        .header-content {
            display: flex;
            align-items: center;
            width: 100%;
        }
        .logo img {
            width: 32px;
            height: auto;
            margin-left: 17px;
            margin-right: 8px;
            display: block;
        }
        .app-title {
            color: white;
            font-size: 1.12em;
            flex-grow: 1;
            position: relative;
            display: inline-block;
            background: linear-gradient(90deg, #ffffff 10%, #cccccc 20%, #2a5280 30%, #ffffff 40%);
            background-size: 200% auto;
            color: transparent;
            background-clip: text;
            -webkit-background-clip: text;
            text-fill-color: transparent;
            animation: shimmer 3s linear infinite;
            font-family: 'LEMONMILK-Regular', sans-serif;
            letter-spacing: 0.5px;
        }
        @keyframes shimmer {
            0% { background-position: -200% 0; }
            100% { background-position: 200% 0; }
        }
        .wallet-icon {
            display: flex;
            align-items: center;
            padding: 5px 10px;
            border: 2px solid #fff;
            border-radius: 40px;
            background-color: #1b1a3a;
            font-size: 0.9em;
            cursor: pointer;
        }
        .wallet-icon img {
            height: 20px;
            margin-right: 10px;
        }
        .balance-text {
            font-size: 1.2em;
            color: white;
        }
        .main-content {
            flex-grow: 1;
            padding: 20px;
            text-align: center;
            overflow-y: auto;
        }
        .container {
            max-width: 400px;
            margin: 0 auto;
            padding: 8px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            color: #000;
        }
        .section {
            margin-bottom: 3px;
        }
        .balance-header h2 {
            font-size: 14px;
            font-weight: bold;
            margin: 0;
            color: #000;
        }
        
        #bottomSheet {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: white;
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
            padding: 20px;
            display: none;
            box-shadow: 0 -5px 10px rgba(0, 0, 0, 0.3);
        }
        .button-container {
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
        }
        .action-button {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 10px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 10px;
            background: none;
        }
        .action-button.auto {
            border: 2px solid pink;
        }
        .action-button.manual {
            border: 2px solid #FB9117;
        }
        #closeButton {
            padding: 8px 30px;
            font-size: 16px;
            cursor: pointer;
            background-color: red;
            color: white;
            border: none;
            margin-top: 20px;
            border-radius: 5px;
        }
        
        .balance-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0px;
        }

        .balance-header a {
            font-size: 15px;
            color: #888;
            margin-bottom: -28px;
            margin-right: 6px;
            margin-top: 0px;
            text-decoration: none;
            text-align: center;
            line-height: 1;
        }

        .balance-amount {
            font-size: 24px;
            font-weight: bold;
            color: #000;
            text-align: left;
            margin-top: 3px;
            margin-bottom: -8px;
        }

        .balance-amount2 {
            font-size: 14px;
            font-weight: bold;
            color: #000;
            text-align: left;
            margin-top: 3px;
        }

        .balance-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 2px 0;
        }
        .balance-item:last-child {
            border-bottom: none;
        }
        .balance-item .button {
            padding: 6px 12px;
            border-radius: 5px;
            color: white;
            margin-top: -19px;
            font-size: 14px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
        }
        .withdraw {
            background-color: #28a745;
        }
        .add-money {
            background-color: #007bff;
        }
        .transfer {
            margin-bottom: -12px;
            background-color: #6f42c1;
        }
        .line-separator {
            height: 1px;
            background-color: #e0e0e0;
            margin: 10px 0;
        }
        .instruction-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 8px 0;
        }
        .instruction-item img {
            width: 20px;
            margin-right: 10px;
        }
        .instruction-item a {
            display: flex;
            align-items: center;
            color: #000;
            text-decoration: none;
            font-size: 14px;
        }
        .instruction-item a img {
            width: 16px;
            height: 16px;
            margin-right: 5px;
        }
        .video-button {
            background-color: #e83e8c;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
        }
        .contact-us {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px;
            margin-left:65px;
            margin-right: 65px;
            background-color: #007bff;
            border-radius: 5px;
            margin-top: 10px;
            color: white;
            font-size: 14px;
            text-decoration: none;
        }
        .bottom-navigation {
            background-color: #07031e;
            display: flex;
            justify-content: space-around;
            padding: 10px 0;
            position: fixed;
            width: 100%;
            bottom: 0;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.5);
        }
        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            flex: 1;
            color: #ccc;
            padding: 5px;
            text-decoration: none;
            transition: color 0.3s, transform 0.3s;
            font-size: 12px;
        }
        .nav-item img {
            width: 24px;
            height: auto;
            margin-bottom: 5px;
        }
        .nav-item:hover, .nav-item.active {
            color: #fff;
        }
    </style>
</head>
<body>
    <header class="app-header">
        <div class="header-content">
            <a href="/profile.php" class="logo">
                <div class="back-button-container">
                    <img src="to/backbutton.png" alt="Back Icon">
                </div>
            </a>
            <h1 class="app-title"><?php echo htmlspecialchars($site_name); ?></h1>
            <div class="wallet-icon" id="walletIcon">
                <img src="to/wallet2.png" alt="WalletIcon">
                <span class="balance-text"><?php echo number_format($user['gaming_balance'], 2); ?></span>
            </div>
        </div>
    </header>

    <div class="main-content">
        <div class="container">
            <!-- Available Balance Section -->
            <div class="section">
                <div class="balance-header">
                    <h2>AVAILABLE BALANCE :</h2>
                    <a href="mywallet/transactions.php">View Transactions</a>
                </div>
                <div class="balance-amount">৳<?php echo number_format($user['gaming_balance'], 2); ?></div>
            </div>
            <div class="line-separator"></div>

            <!-- Winning Cash Balance Section -->
            <div class="section">
                <div class="balance-header">
                    <h2>🏆 WINNING BALANCE :</h2>
                </div>
                <div class="balance-item">
                    <div class="balance-amount">৳<?php echo number_format($user['winning_balance'], 2); ?></div>
                    <a href="mywallet/withdraw.php" class="button withdraw">WITHDRAW</a>
                </div>
            </div>
            <div class="line-separator"></div>

            <!-- Deposit Cash Balance Section -->
            <div class="section">
                <div class="balance-header">
                    <h2>💵 DEPOSIT BALANCE :</h2>
                </div>
                <div class="balance-item">
                    <div class="balance-amount">৳<?php echo number_format($user['gaming_balance'], 2); ?></div>
                   <a href="mywallet/deposit.php" class="button add-money">+ ADD MONEY</a>
                </div>
            </div>
            <div class="line-separator"></div>

            <!-- Transfer Section -->
            <div class="section">
                <div class="balance-header"></div>
                <div class="balance-item">
                    <div class="balance-amount2">🎮 WINNING TO GAMING BALANCE</div>
                    <a href="mywallet/winningtogaming.php" class="button transfer">TRANSFER</a>
                </div>
            </div>
            <div class="line-separator"></div>

            <!-- Instructions Section -->
            <div class="instruction-item">
                <a href=""><img src="to/video-icon.png" alt="Video">HOW TO ADD MONEY?</a>
                <a href="video2.php" class="video-button">ভিডিও দেখুন</a>
            </div>
            <div class="instruction-item">
                <a href="#"><img src="to/video-icon.png" alt="Video">HOW TO JOIN A MATCH?</a>
                <a href="video.php" class="video-button">ভিডিও দেখুন</a>
            </div>
            <div class="instruction-item">
                <a href="#"><img src="to/video-icon.png" alt="Video">HOW JOIN A LUDU MATCH?</a>
                <a href="video.php" class="video-button">ভিডিও দেখুন</a>
            </div>

            <!-- Contact Us Button -->
            <a href="admin.php" class="contact-us">CONTACT US</a>
        </div>
    </div>
    
    <!-- Bottom sheet dialog -->
    <div id="bottomSheet" style="margin-bottom: 100px;">
        <div class="button-container" style="margin-bottom: 30px;">
            <button class="action-button auto" onclick="location.href='amount.php'">
                <img src="to/bk.png" alt="Logo" width="50">
                Auto Add
            </button>
            <button class="action-button manual" onclick="location.href='mywallet/deposit.php'">
                <img src="to/bkash.png" alt="Logo" width="50">
                Manually
            </button>
        </div>
        <button id="closeButton" onclick="closeBottomSheet()">Close</button>
    </div>

    <nav class="bottom-navigation">
        <a href="admin.php" class="nav-item" id="chat">
            <img src="to/chat1.png" alt="Chat">
            <span>Chat</span>
        </a>
        <a href="index.php" class="nav-item" id="play">
            <img src="to/play2.png" alt="Play">
            <span>Play</span>
        </a>
        <a href="profile.php" class="nav-item active" id="me">
            <img src="to/profile1.png" alt="Me">
            <span>Me</span>
        </a>
    </nav>

    <script>
        // JavaScript functions to open and close the bottom sheet
        function openBottomSheet() {
            document.getElementById('bottomSheet').style.display = 'block';
        }

        function closeBottomSheet() {
            document.getElementById('bottomSheet').style.display = 'none';
        }

        // Prevent context menu from showing on right-click or long-press
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });

        // Prevent the default behavior for right-click and middle-click
        document.addEventListener('mousedown', function(e) {
            if (e.button === 2 || e.button === 3) {
                e.preventDefault();
            }
        });

        // Prevent link behavior on long press
        document.querySelectorAll('a').forEach(function(link) {
            link.addEventListener('touchstart', function() {
                this.setAttribute('data-href', this.getAttribute('href'));
                this.removeAttribute('href');
            });

            link.addEventListener('touchend', function() {
                this.setAttribute('href', this.getAttribute('data-href'));
            });

            link.addEventListener('touchmove', function() {
                this.setAttribute('href', this.getAttribute('data-href'));
            });
        });

        // Navigate to 'mywallet.php' when the wallet icon is clicked
        document.getElementById('walletIcon').addEventListener('click', function() {
            window.location.href = 'mywallet.php';
        });

        // Manage active state for navigation items
        document.addEventListener('DOMContentLoaded', function() {
            const navItems = document.querySelectorAll('.nav-item');
            navItems.forEach(item => {
                item.addEventListener('click', function() {
                    navItems.forEach(nav => nav.classList.remove('active'));
                    this.classList.add('active');
                });
            });
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
    </script>
</body>
</html>