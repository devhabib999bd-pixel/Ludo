<?php
session_start();
require_once 'config.php'; // Database configuration file

// Check if user is logged in
if (!isset($_SESSION['user_uid'])) {
    header("Location: login.php");
    exit();
}

$user_uid = $_SESSION['user_uid'];

// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}

// Fetch user data and balance
$user_query = "SELECT referral_code, gaming_balance, winning_balance, is_banned, ban_reason FROM users WHERE user_uid = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("s", $user_uid);
$stmt->execute();
$user_result = $stmt->get_result();

$gaming_balance = 0;
$winning_balance = 0;
$is_banned = false;
$ban_reason = '';

if ($user_result->num_rows > 0) {
    $user = $user_result->fetch_assoc();
    $gaming_balance = $user['gaming_balance'];
    $winning_balance = $user['winning_balance'];
    $is_banned = $user['is_banned'];
    $ban_reason = $user['ban_reason'];
    $referral_code = $user['referral_code'];
}
$stmt->close();
?>


<html xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo htmlspecialchars($site_name); ?> - Refer and Earn</title>
    <link rel="stylesheet" href="profile.css" />
    <script>
        // Function to prevent zooming with CTRL key and mouse wheel
        function preventZoom(e) {
            if (e.ctrlKey || e.metaKey) { // Check if the control key or meta key is pressed
                e.preventDefault(); // Prevent the default action of zooming
            }
        }

        // Listen for the wheel event to detect zoom attempts with CTRL
        document.addEventListener('wheel', preventZoom, { passive: false });

        // Prevent pinch zoom on mobile devices
        document.addEventListener('touchmove', function (e) {
            if (e.touches.length &gt; 1) { // Check if more than one finger is used
                e.preventDefault(); // Prevent the default multi-touch actions like pinch-zoom
            }
        }, { passive: false });
    </script>
    <style>
    * {
            outline: none;
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        a {
            text-decoration: none;
            color: inherit;
            -webkit-touch-callout: none;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
        }
        /* Toast styles for top-right notification */
        .toast {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            opacity: 0;
            transform: translateY(-20px);
            animation: fadeIn 0.5s forwards, fadeOut 0.5s 3.5s forwards;
            z-index: 9999;
            font-family: Arial, sans-serif;
        }

        @keyframes fadeIn {
            0% {
                opacity: 0;
                transform: translateY(-20px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeOut {
            0% {
                opacity: 1;
                transform: translateY(0);
            }
            100% {
                opacity: 0;
                transform: translateY(-20px);
            }
        }

        .container {
            margin-bottom: 5rem;
        }

        /* Additional CSS styles */
        .banner {
            width: 100%;
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
            border-radius: 8px;
        }

        .refer-content {
            margin-bottom: 20px;
            color: #ccc;
        }

        .refer-code {
            font-size: 18px;
            margin-bottom: 10px;
        }

        .refer-code span {
            color: #FFD700;
            font-weight: bold;
        }

        .refer-details {
            margin-bottom: 20px;
        }

        .share-button {
            background-color: #FFD700;
            color: #000;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .share-button:hover {
            background-color: #FFC107;
        }

        .wallet-icon {
            display: flex;
            align-items: center;
            padding: 5px 10px;
            border: 2px solid #fff;
            border-radius: 40px;
            background-color: #1b1a3a;
            font-size: 0.9em;
            font-family: 'HindSiliguri-Medium', sans-serif;
        }

        .wallet-icon img {
            height: 20px;
            margin-right: 10px;
        }

        .balance-text {
            font-size: 1.2em;
            color: white;
        }

        .referred-users {
            margin-top: 20px;
        }

        .referred-users h3 {
            margin-bottom: 10px;
            color: #FFD700;
            font-size: 18px;
        }

        .referred-users table {
            width: 100%;
            border-collapse: collapse;
        }

        .referred-users th, .referred-users td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #444;
        }

        .referred-users th {
            background-color: #333;
            color: #FFD700;
        }

        .referred-users tr:nth-child(even) {
            background-color: #222;
        }

        .claim-button {
            background-color: #28a745;
            color: #fff;
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }

        .claim-button[disabled] {
            background-color: #ccc;
            cursor: not-allowed;
        }

        .claim-status {
            font-weight: bold;
            font-size: 14px;
        }

        .claim-status.eligible {
            color: #28a745;
        }

        .claim-status.claimed {
            color: #FFD700;
        }

        .claim-status.ineligible {
            color: #FF0000;
        }
         * {
            outline: none;
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        a {
            text-decoration: none;
            color: inherit;
            -webkit-touch-callout: none;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
        }
        /* Additional CSS styles */
        .banner {
            width: 100%;
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
            border-radius: 8px;
        }

        a {
            text-decoration: none; /* Remove underline from links */
            color: inherit; /* Inherit text color */
        }

        .refer-content {
            margin-bottom: 20px;
            color: #ccc;
        }

        .refer-code {
            font-size: 18px;
            margin-bottom: 10px;
        }

        .refer-code span {
            color: #FFD700;
            font-weight: bold;
        }

        .refer-details {
            margin-bottom: 20px;
        }

        .share-button {
            background-color: #FFD700;
            color: #000;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .share-button:hover {
            background-color: #FFC107;
        }

        .app-header {
            background-color: #07031e;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 5px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .header-content {
            display: flex;
            align-items: center;
            width: 100%;
        }

        .logo {
            display: inline-block;
            cursor: pointer;
            padding: 10px; /* Increase the clickable area around the image */
        }

        .logo img {
            width: 32px; /* Adjust size as needed */
            height: auto;
            display: block;
            pointer-events: none; /* Ensures the click event is not blocked by the image */
        }

        .app-title {
            color: white;
            font-size: 1.05em;
            flex-grow: 1;
           margin-left: 0px;
            background: linear-gradient(90deg, #ffffff 10%, #cccccc 20%, #2a5280 30%, #ffffff 40%);
            background-size: 200% auto;
            color: transparent;
            background-clip: text;
            -webkit-background-clip: text;
            text-fill-color: transparent;
            animation: shimmer 3s linear infinite;
            font-family: 'LEMONMILK-Regular', sans-serif;
            letter-spacing: 0.5px;
        }

        @keyframes shimmer {
            0% {
                background-position: -200% 0;
            }
            100% {
                background-position: 200% 0;
            }
        }

        .wallet-icon {
            display: flex;
            align-items: center;
            padding: 5px 10px;
            border: 2px solid #fff;
            border-radius: 40px;
            background-color: #1b1a3a;
            font-size: 0.9em;
            font-family: 'HindSiliguri-Medium', sans-serif;
        }

        .wallet-icon img {
            height: 20px;
            margin-right: 10px;
        }

        .balance-text {
            font-size: 1.2em;
            color: white;
        }

        .main-content {
            text-align: center;
            margin: 5px 0;
            
        }

        .hamster-icon {
            width: 100px;
            height: auto;
            border-radius: 50%;
            box-shadow: 0 0 10px rgba(255, 215, 0, 0.5);
        }

        .wallet-section {
            margin-top: 20px;
            background-color: #111;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .balance-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #444;
            color: #fff;
        }

        .balance-item:last-child {
            border-bottom: none;
        }

        .balance-title {
            font-size: 14px;
        }

        .balance-amount {
            font-size: 16px;
        }

        .transaction-link {
            color: #FFD700;
            text-decoration: none;
            font-weight: bold;
        }

        .transaction-link:hover {
            text-decoration: underline;
        }

        .action-buttons {
            margin-top: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .action-button {
            padding: 5px 6px;
            background-color: #FFD700;
            color: #000;
            margin-top: -2px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            transition: background-color 0.3s ease;
        }

        .action-button:hover {
            background-color: #FFC107;
        }

        .how-to-section {
            margin-top: 20px;
            color: #ccc;
        }

        .how-to-title {
            font-size: 14px;
            margin-bottom: 10px;
        }

        .how-to-item {
            margin-bottom: 10px;
        }

        .how-to-item a {
            color: #FFD700;
            text-decoration: none;
        }

        .how-to-item a:hover {
            text-decoration: underline;
        }

        .bottom-navigation {
            background-color: #07031e;
            display: flex;
            justify-content: space-around;
            padding: 0px;
            position: fixed;
            width: 100%;
            padding: -4px;
            bottom: 0;
        }

        .nav-item {
            text-align: center;
            color: #ccc;
            text-decoration: none;
            font-size: 0.85em;
            transition: transform 0.2s ease, color 0.2s ease, opacity 0.2s ease;
            cursor: pointer;
            opacity: 1;
            font-family: 'HindSiliguri-Medium', sans-serif;
        }

        .nav-item img {
            width: 22px;
            height: auto;
            display: block;
            margin: 0 auto 3px;
            transition: transform 0.2s ease, opacity 0.2s ease;
        }

        .nav-item:hover, .nav-item:focus, .nav-item:active {
            transform: scale(1.1);
            color: #fff;
        }

        .nav-item:hover img, .nav-item:focus img, .nav-item:active img {
            transform: scale(1.2);
        }

        .inactive {
            opacity: 0.5;
        }

        .referred-users {
            margin-top: 20px;
        }

        .referred-users h3 {
            margin-bottom: 10px;
            color: #FFD700;
            font-size: 18px;
        }

        .referred-users table {
            width: 100%;
            border-collapse: collapse;
        }

        .referred-users th, .referred-users td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #444;
        }

        .referred-users th {
            background-color: #333;
            color: #FFD700;
        }

        .referred-users tr:nth-child(even) {
            background-color: #222;
        }

        .claim-button {
            background-color: #28a745;
            color: #fff;
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }

        .claim-button[disabled] {
            background-color: #ccc;
            cursor: not-allowed;
        }

        .claim-status {
            font-weight: bold;
            font-size: 14px;
        }

        .claim-status.eligible {
            color: #28a745;
        }

        .claim-status.claimed {
            color: #FFD700;
        }

        .claim-status.ineligible {
            color: #FF0000;
        }
       .container {
       margin-bottom: 5rem;
       }
       #toast-container {
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 9999;
}

.toast {
    display: inline-block;
    padding: 10px 20px;
    margin-top: 10px;
    background-color: #28a745;
    color: #fff;
    border-radius: 4px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    opacity: 0;
    animation: fadeInOut 4s forwards;
    font-family: Arial, sans-serif;
}

@keyframes fadeInOut {
    0% {
        opacity: 0;
        transform: translateY(-10px);
    }
    10% {
        opacity: 1;
        transform: translateY(0);
    }
    90% {
        opacity: 1;
        transform: translateY(0);
    }
    100% {
        opacity: 0;
        transform: translateY(-10px);
    }
}

    </style>
</head>
<body style="">

<header class="app-header">
    <div class="header-content">
        <a href="/profile.php" class="logo">
            <img src="to/backbutton.png" alt="Back Icon" />
        </a>
        <h1 class="app-title"><?php echo htmlspecialchars($site_name); ?></h1>
        <div class="wallet-icon" id="walletIcon">
            <img src="to/wallet2.png" alt="Wallet" />
            <span class="balance-text"><?php echo $gaming_balance + $winning_balance; ?></span>
        </div>
    </div>
</header>

<div class="container">
    <div class="main-content">
        <img src="to/share_and_earn.jpg" alt="Banner Image" class="banner" />
        <h2>md Arman</h2>
        
       <div class="refer-content">
            <p>আপনার রেফার কোড ব্যবহার করে আপনার বন্ধুদের অ্যাপে আমন্ত্রণ জানান এবং 50 টাকা রেফার বোনাস জিতুন, যখন তারা তাদের প্রথম পেড ম্যাচে যোগদান করে এবং আপনার রেফার করা ব্যবহারকারী সাইনআপ বোনাস হিসাবে সেও 5 টাকা পাবেন!</p>
        </div>
        <div class="refer-details">
            <p class="refer-code">YOUR REFER CODE: <span><?php echo $referral_code; ?></span></p>
            <p>You have Referred: 0 People</p>
        </div>
        <button class="share-button" id="share-btn">SHARE NOW</button>
    </div>

    <div class="referred-users">
        <h3>Your Referred Users:</h3>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                            </tbody>
        </table>
    </div>
</div>

<nav class="bottom-navigation">
    <a style="color: #fff;" href="admin.php" class="nav-item" id="chat">
        <img src="to/chat1.png" alt="Chat" />
        <span>Chat</span>
    </a>
    <a style="color: #fff;" href="index.php" class="nav-item" id="play">
        <img src="to/play2.png" alt="Play" />
        <span>Play</span>
    </a>
    <a style="color: #fff;" href="profile.php" class="nav-item" id="me">
        <img src="to/profile1.png" alt="Me" />
        <span>Me</span>
    </a>
</nav>

<script>
// Toast Function
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerText = message;

    document.body.appendChild(toast);

    setTimeout(() =&gt; {
        toast.remove();
    }, 4000); // 4 seconds
}

// Share button logic with copy to clipboard functionality
const shareButton = document.getElementById('share-btn');
shareButton.addEventListener('click', () =&gt; {
    const referralCode = '617979';
    const referralLink = 'https://ludobd.com/'; // Replace with your actual referral link
    const shareText = `Join now and use my referral code ${referralCode} to earn rewards! ${referralLink}`;
    
    // Copy the referral text to clipboard
    copyToClipboard(shareText);

    // Show a toast to indicate that the text has been copied
    showToast('Referral link copied to clipboard!');
});

function copyToClipboard(text) {
    const tempInput = document.createElement('input');
    tempInput.value = text;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand('copy');
    document.body.removeChild(tempInput);
}

// JavaScript to handle the wallet-icon click event
document.getElementById('walletIcon').addEventListener('click', function() {
    window.location.href = 'mywallet.php';
});

</script>



</body></html>