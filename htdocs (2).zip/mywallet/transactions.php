<?php
session_start();
require_once 'config.php'; // Database connection

if (!isset($_SESSION['user_uid'])) {
    header("Location: login.php");
    exit();
}

$user_uid = $_SESSION['user_uid'];

// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}

// Fetch last 25 deposits
$deposit_query = "SELECT 'deposit' as type, amount, transaction_id as reference_id, created_at, status FROM deposits WHERE user_uid = ? ORDER BY created_at DESC LIMIT 25";
$deposit_stmt = $conn->prepare($deposit_query);
if (!$deposit_stmt) {
    die("Deposit query failed: " . $conn->error);
}
$deposit_stmt->bind_param("s", $user_uid);
$deposit_stmt->execute();
$deposit_result = $deposit_stmt->get_result();
$deposits = $deposit_result->fetch_all(MYSQLI_ASSOC);

// Fetch last 25 withdrawals
$withdraw_query = "SELECT 'withdraw' as type, amount, transaction_id as reference_id, created_at, status FROM withdrawals WHERE user_uid = ? ORDER BY created_at DESC LIMIT 25";
$withdraw_stmt = $conn->prepare($withdraw_query);
$withdraw_stmt->bind_param("s", $user_uid);
$withdraw_stmt->execute();
$withdraw_result = $withdraw_stmt->get_result();
$withdrawals = $withdraw_result->fetch_all(MYSQLI_ASSOC);

// Merge and sort all transactions by date (latest first)
$transactions = array_merge($deposits, $withdrawals);
usort($transactions, function ($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
});

// Helpers
function getStatusClass($type, $status) {
    if ($type === 'deposit' && $status === 'approved') return 'status-approved';
    if ($type === 'withdraw' && $status === 'approved') return 'status-paid';
    if ($status === 'pending') return 'status-pending';
    if ($status === 'rejected') return 'status-rejected';
    return 'status-pending';
}
function getTransactionTitle($type) {
    return ucfirst($type) . ($type === 'deposit' ? '' : 'al');
}
function formatDate($date) {
    return date('d/M/Y h:i A', strtotime($date));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Transaction History</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <style>
                * {
            outline: none;
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            margin: 0;
            padding: 0;
        }

        a {
            text-decoration: none;
            color: inherit;
            -webkit-touch-callout: none;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .app-header {
            background-color: #07031e;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            box-sizing: border-box;
        }
        .header-content {
            display: flex;
            align-items: center;
            width: 100%;
        }
        .logo {
            display: inline-block;
            cursor: pointer;
            padding: 10px;
        }
        .logo img {
            width: 30px;
            height: auto;
            display: block;
        }
        .app-title {
            color: white;
            font-size: 1.2em;
            flex-grow: 1;
            margin-top: 10px;
            background: linear-gradient(90deg, #ffffff 10%, #cccccc 20%, #2a5280 30%, #ffffff 40%);
            background-size: 200% auto;
            color: transparent;
            background-clip: text;
            -webkit-background-clip: text;
            text-fill-color: transparent;
            animation: shimmer 3s linear infinite;
            font-family: 'LEMONMILK-Regular', sans-serif;
            letter-spacing: 0.5px;
            text-align: center;
        }
        @keyframes shimmer {
            0% {
                background-position: -200% 0;
            }
            100% {
                background-position: 200% 0;
            }
        }

        .transaction-container {
            width: 100%;
            margin: 20px 0;
            padding: 0 10px;
            box-sizing: border-box;
        }

        .transaction-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 8px;
            background-color: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .transaction-info {
            flex-grow: 1;
        }

        .transaction-title {
            font-weight: bold;
            font-size: 16px;
            margin: 0 0 5px;
        }

        .transaction-details {
            margin: 0;
            font-size: 14px;
            color: #666;
        }

        .transaction-amount {
            font-weight: bold;
            font-size: 16px;
            margin-top: 5px;
        }

        .transaction-status {
            font-weight: bold;
            font-size: 14px;
            text-align: right;
            min-width: 100px;
            padding-left: 10px;
        }

        .status-received {
            color: #28a745;
        }

        .status-paid {
            color: #007bff;
        }

        .status-pending {
            color: #ffc107;
        }

        .status-rejected {
            color: #dc3545;
        }

        .status-transfer {
            color: #6f42c1;
        }

        .status-refund {
            color: #fd7e14;
        }

        .status-approved {
            color: #20c997;
        }

        .status-joined {
            color: #17a2b8;
        }

        /* Styles for no transactions message */
        .no-transactions {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 300px;
            text-align: center;
            color: #666;
            padding: 20px;
        }

        .no-transactions .emoji {
            font-size: 80px;
            margin-bottom: 20px;
        }

        .no-transactions .message {
            font-size: 18px;
            margin-bottom: 10px;
        }

        .no-transactions .sub-message {
            font-size: 14px;
            color: #999;
        }
    </style>
</head>
<body>
    <header class="app-header">
        <div class="header-content">
            <a href="/mywallet.php" class="logo">
                <img src="/to/backbutton.png" alt="Back Icon">
            </a>
            <h1 class="app-title" style="margin-right: 164px; margin-top: 13px;"><?php echo htmlspecialchars($site_name); ?></h1>
        </div>
    </header>

    <div class="transaction-container">
        <?php if (empty($transactions)): ?>
            <div class="no-transactions">
                <div class="emoji">📭</div>
                <div class="message">No transactions yet</div>
                <div class="sub-message">Your transaction history will appear here</div>
            </div>
        <?php else: ?>
            <?php foreach ($transactions as $tx): ?>
                <div class="transaction-item">
                    <div class="transaction-info">
                        <p class="transaction-title"><?php echo htmlspecialchars(getTransactionTitle($tx['type'])); ?></p>
                        <p class="transaction-details">Trx ID: <?php echo htmlspecialchars(substr($tx['reference_id'], 0, 10)); ?></p>
                        <p class="transaction-details">Date: <?php echo formatDate($tx['created_at']); ?></p>
                        <p class="transaction-amount">Amount: <?php echo number_format($tx['amount'], 2); ?> TK</p>
                    </div>
                    <div class="transaction-status <?php echo getStatusClass($tx['type'], $tx['status']); ?>">
                        <?php echo ucfirst($tx['status']); ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script>
        document.addEventListener('contextmenu', e => e.preventDefault());
        document.addEventListener('mousedown', e => { if (e.button === 2 || e.button === 3) e.preventDefault(); });
    </script>
</body>
</html>


