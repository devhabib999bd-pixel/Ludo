<?php
session_start();
require_once 'config.php'; // Database connection file

// Check if user is logged in
if (!isset($_SESSION['user_uid'])) {
    header("Location: login.php");
    exit();
}

// Initialize variables
$error = '';
$success = '';
$gaming_balance = 0;
$winning_balance = 0;

// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}

// Get user's current balances
$user_uid = $_SESSION['user_uid'];
$query = "SELECT gaming_balance, winning_balance FROM users WHERE user_uid = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $user_uid);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user) {
    $gaming_balance = $user['gaming_balance'];
    $winning_balance = $user['winning_balance'];
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $transfer_amount = isset($_POST['transfer-amount']) ? floatval($_POST['transfer-amount']) : 0;
    
    // Validate transfer amount
    if ($transfer_amount <= 0) {
        $error = "Please enter a valid amount";
    } elseif ($transfer_amount > $winning_balance) {
        $error = "Insufficient winning balance";
    } else {
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Update balances
            $new_gaming = $gaming_balance + $transfer_amount;
            $new_winning = $winning_balance - $transfer_amount;
            
            $query = "UPDATE users SET gaming_balance = ?, winning_balance = ? WHERE user_uid = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("dds", $new_gaming, $new_winning, $user_uid);
            $stmt->execute();
            
            // Record transaction
            $query = "INSERT INTO transactions (user_uid, type, amount, from_balance, to_balance, reference_id) 
                      VALUES (?, 'transfer', ?, 'winning', 'gaming', ?)";
            $stmt = $conn->prepare($query);
            $reference_id = uniqid('transfer_');
            $stmt->bind_param("sds", $user_uid, $transfer_amount, $reference_id);
            $stmt->execute();
            
            // Commit transaction
            $conn->commit();
            
            $success = "Successfully transferred ৳" . number_format($transfer_amount, 2) . " to gaming balance";
            $gaming_balance = $new_gaming;
            $winning_balance = $new_winning;
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Transfer failed: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($site_name); ?> - Winning to Gaming</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <style>
        * {
            outline: none;
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            margin: 0;
            padding: 0;
        }

        a {
            text-decoration: none;
            color: inherit;
            -webkit-touch-callout: none;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            color: #333;
            margin: 0;
            padding: 0;
        }

        .app-header {
            background-color: #07031e;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            box-sizing: border-box;
        }
        .header-content {
            display: flex;
            align-items: center;
            width: 100%;
        }
        .logo {
            display: inline-block;
            cursor: pointer;
            padding: 10px;
        }
        .logo img {
            width: 32px;
            height: auto;
            display: block;
        }
        .app-title {
            color: white;
            font-size: 1.2em;
            flex-grow: 1;
            margin-top: 13px;
            background: linear-gradient(90deg, #ffffff 10%, #cccccc 20%, #2a5280 30%, #ffffff 40%);
            background-size: 200% auto;
            color: transparent;
            background-clip: text;
            -webkit-background-clip: text;
            text-fill-color: transparent;
            animation: shimmer 3s linear infinite;
            font-family: 'LEMONMILK-Regular', sans-serif;
            letter-spacing: 0.5px;
            
        }
        @keyframes shimmer {
            0% {
                background-position: -200% 0;
            }
            100% {
                background-position: 200% 0;
            }
        }

        .transfer-container {
            max-width: 400px;
            margin: 16px auto;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            background-color: white;
            border-radius: 10px;
            text-align: center;
        }

        .balance-display {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            margin-top: -10px;
            font-size: 18px;
            margin-left: 24px;
            margin-right: 22px;
            font-weight: bold;
            color: #07031e;
        }
         .balance-display2 {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            font-size: 18px;
            color: #07031e;
        }

        .transfer-form label {
            color: #333;
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .transfer-form input[type="text"] {
            width: 90%;
            max-width: 360px;
            height: 30px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 14px;
            color: #555;
            background-color: #f5f5f5;
            text-align: center;
        }

        .transfer-form button {
            padding: 12px 20px;
            background-color: #07031e;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
            width: 100%;
            font-weight: bold;
        }

        .transfer-form button:hover {
            background-color: #2a5280;
        }

        .message {
            margin-top: 20px;
            color: green;
            font-size: 16px;
            font-weight: bold;
            padding: 10px;
            background-color: #e6ffe6;
            border-radius: 4px;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-top: 10px;
            padding: 10px;
            background-color: #ffebeb;
            border-radius: 4px;
        }

        /* Toast styling */
        #toast {
            visibility: hidden;
            max-width: 100%;
            height: 50px;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 8px;
            position: fixed;
            z-index: 1;
            bottom: 10px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 17px;
            white-space: nowrap;
            padding: 10px 20px;
        }

        #toast.show {
            visibility: visible;
            -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
            animation: fadein 0.5s, fadeout 0.5s 2.5s;
        }

        @-webkit-keyframes fadein {
            from {bottom: 0; opacity: 0;} 
            to {bottom: 10px; opacity: 1;}
        }

        @keyframes fadein {
            from {bottom: 0; opacity: 0;}
            to {bottom: 10px; opacity: 1;}
        }

        @-webkit-keyframes fadeout {
            from {bottom: 10px; opacity: 1;} 
            to {bottom: 0; opacity: 0;}
        }

        @keyframes fadeout {
            from {bottom: 10px; opacity: 1;}
            to {bottom: 0; opacity: 0;}
        }
    </style>
</head>
<body>
    <header class="app-header">
        <div class="header-content">
            <a href="/mywallet.php" class="logo">
                <img src="../to/backbutton.png" alt="Back Icon">
            </a>
            <h1 class="app-title"><?php echo htmlspecialchars($site_name); ?></h1>
        </div>
    </header>

    <div class="transfer-container">
        <div class="balance-display2">
            <div>Gaming Balance</div>
            <div>Winning Balance</div>
        </div>
        <div class="balance-display">
            <div>৳<?php echo number_format($gaming_balance, 2); ?></div>
            <div>৳<?php echo number_format($winning_balance, 2); ?></div>
        </div>
        
        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="message"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <form class="transfer-form" method="POST" action="">
            <label for="transfer-amount">Amount to Transfer:</label>
            <input type="text" id="transfer-amount" name="transfer-amount" placeholder="Enter amount" required>
            <button type="submit">Transfer</button>
        </form>
    </div>

    <!-- Toast Container -->
    <div id="toast"><div id="desc"></div></div>

    <script>
        function showToast(message) {
            const toast = document.getElementById("toast");
            document.getElementById("desc").innerText = message;
            toast.className = "show";
            setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 3000);
        }
        
        // Prevent context menu from showing on right-click or long-press
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });

        // Prevent the default behavior for right-click and middle-click
        document.addEventListener('mousedown', function(e) {
            if (e.button === 2 || e.button === 3) {
                e.preventDefault();
            }
        });

        // Prevent link behavior on long press
        document.querySelectorAll('a').forEach(function(link) {
            link.addEventListener('touchstart', function() {
                this.setAttribute('data-href', this.getAttribute('href'));
                this.removeAttribute('href');
            });

            link.addEventListener('touchend', function() {
                this.setAttribute('href', this.getAttribute('data-href'));
            });

            link.addEventListener('touchmove', function() {
                this.setAttribute('href', this.getAttribute('data-href'));
            });
        });
    </script>
</body>
</html>