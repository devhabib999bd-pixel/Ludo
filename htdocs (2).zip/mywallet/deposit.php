<?php
session_start();
require_once 'config.php'; // Database connection file

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Check if user is logged in
if (!isset($_SESSION['user_uid'])) {
    header("Location: login.php");
    exit();
}

// Initialize variables
$error = '';
$success = '';
$payment_methods = [
    'bkash' => ['number' => '01929110012', 'name' => 'bKash'],
    'nagad' => ['number' => '01886689929', 'name' => 'Nagad'],
    'rocket' => ['number' => '018866899292', 'name' => 'Rocket']
];

// Check for messages from redirect
if (isset($_SESSION['deposit_error'])) {
    $error = $_SESSION['deposit_error'];
    unset($_SESSION['deposit_error']);
}

if (isset($_SESSION['deposit_success'])) {
    $success = $_SESSION['deposit_success'];
    unset($_SESSION['deposit_success']);
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error = "Invalid form submission";
    } else {
        // Validate inputs
        $payment_method = $_POST['payment_method'] ?? '';
        $sender_number = trim($_POST['trx-id'] ?? '');
        $amount = trim($_POST['deposit-amount'] ?? '');
        
        // Validate payment method
        if (!array_key_exists($payment_method, $payment_methods)) {
            $error = "Please select a valid payment method";
        }
        
        // Validate amount
        elseif (empty($amount) || $amount < 10) {
            $error = "Minimum deposit amount is 10 BDT";
        }
        elseif ($amount > 99999) {
            $error = "Maximum deposit amount is 99,999 BDT";
        }
    }
    
    // If validation passes
    if (empty($error)) {
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Check if transaction exists in received table
            $query = "SELECT * FROM received WHERE 
                     txid = ? AND 
                     amount = ? AND 
                     type = ? AND 
                     used_txid = 'false' 
                     LIMIT 1 FOR UPDATE";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("sds", $sender_number, $amount, $payment_method);
            $stmt->execute();
            $result = $stmt->get_result();
            $received = $result->fetch_assoc();
            
            if (!$received) {
                throw new Exception("Transaction not found or already used. Please make sure you've sent the exact amount and use the correct transaction ID.");
            }
            
            // Get user's current balance
            $user_uid = $_SESSION['user_uid'];
            $query = "SELECT gaming_balance FROM users WHERE user_uid = ? FOR UPDATE";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("s", $user_uid);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            
            if (!$user) {
                throw new Exception("User not found");
            }
            
            $current_balance = $user['gaming_balance'];
            $new_balance = $current_balance + $amount;
            
            // Update user balance
            $query = "UPDATE users SET gaming_balance = ? WHERE user_uid = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ds", $new_balance, $user_uid);
            $stmt->execute();
            
            // Record transaction
            $query = "INSERT INTO transactions (user_uid, type, amount, from_balance, to_balance, reference_id) 
                      VALUES (?, 'deposit', ?, 'external', 'gaming', ?)";
            $stmt = $conn->prepare($query);
            $reference_id = uniqid('deposit_');
            $stmt->bind_param("sds", $user_uid, $amount, $reference_id);
            $stmt->execute();
            
            // Record deposit details
            $query = "INSERT INTO deposits (user_uid, payment_method, sender_number, amount, transaction_id, status) 
                      VALUES (?, ?, ?, ?, ?, 'approved')";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssdss", $user_uid, $payment_method, $sender_number, $amount, $reference_id);
            $stmt->execute();
            
            // Mark transaction as used in received table
            $query = "UPDATE received SET used_txid = 'true' WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $received['id']);
            $stmt->execute();
            
            // Commit transaction
            $conn->commit();
            
            // Store success message and redirect
            $_SESSION['deposit_success'] = "Deposit successful! Your balance has been updated.";
            header('Location: deposit.php');
            exit;
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['deposit_error'] = $e->getMessage();
            header('Location: deposit.php');
            exit;
        }
    } else {
        // Store error in session and redirect
        $_SESSION['deposit_error'] = $error;
        header('Location: deposit.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Money</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <style>
        /* Your existing CSS styles remain unchanged */
        * {
            outline: none;
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            margin: 0;
            padding: 0;
        }

        a {
            text-decoration: none;
            color: inherit;
            -webkit-touch-callout: none;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #0e0b27;
            color: #000;
            margin: 0;
            padding: 0;
        }
        .app-header {
            background-color: #07031e;
            color: white;
            padding: 15px;
            display: flex;
            align-items: center;
        }
        .app-header h1 {
            margin: 0;
            font-size: 18px;
            flex-grow: 1;
            text-align: center;
        }
        .back-button {
            color: white;
            text-decoration: none;
            font-size: 24px;
            margin-right: 10px;
        }
        .container {
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            margin: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            position: relative;
        }
        .payment-option {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            font-size: 16px;
        }
        .payment-option img {
            width: 25px;
            margin-right: 10px;
        }
        .copy-button {
            margin-left: 10px;
            font-size: 20px;
            cursor: pointer;
        }
        .copy-button img {
            width: 20px;
            height: 20px;
        }
        .min-amount {
            font-size: 14px;
            color: gray;
            margin-left: 10px;
        }
        .wallet-options {
            display: flex;
            justify-content: space-around;
            margin: 20px 0;
        }
        .wallet-options img {
            width: 60px;
            height: auto;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            cursor: pointer;
        }
        .wallet-options img.selected {
            border: 2px solid #000;
        }
        .input-group {
            margin: 20px 0;
        }
        .input-group input {
            width: calc(100% - 20px);
            padding: 10px;
            font-size: 16px;
            margin-left: 12px;
            margin-bottom: 15px;
            border: 2px solid #000;
            border-radius: 8px;
            text-align: center;
            box-sizing: border-box;
        }
        .verify-button {
            background-color: #000;
            color: white;
            padding: 15px;
            font-size: 18px;
            text-align: center;
            border-radius: 8px;
            cursor: pointer;
            margin-bottom: 20px;
            display: block;
            width: 100%;
            box-sizing: border-box;
        }
        .info-text {
            text-align: center;
            font-size: 14px;
            color: gray;
        }
        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 20px;
            padding: 10px;
            background-color: #fdd;
            border-radius: 8px;
        }
        .success-message {
            color: green;
            text-align: center;
            margin-bottom: 20px;
            padding: 10px;
            background-color: #dfd;
            border-radius: 8px;
        }
        #toast {
            visibility: hidden;
            max-width: 100%;
            height: 50px;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 8px;
            position: absolute;
            z-index: 1;
            bottom: 10px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 17px;
            white-space: nowrap;
            padding: 10px 20px;
        }
        #toast.show {
            visibility: visible;
            -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
            animation: fadein 0.5s, fadeout 0.5s 2.5s;
        }
        @-webkit-keyframes fadein {
            from {bottom: 0; opacity: 0;} 
            to {bottom: 10px; opacity: 1;}
        }
        @keyframes fadein {
            from {bottom: 0; opacity: 0;}
            to {bottom: 10px; opacity: 1;}
        }
        @-webkit-keyframes fadeout {
            from {bottom: 10px; opacity: 1;} 
            to {bottom: 0; opacity: 0;}
        }
        @keyframes fadeout {
            from {bottom: 10px; opacity: 1;}
            to {bottom: 0; opacity: 0;}
        }
        .logo img {
            width: 32px;
            height: auto;
            margin-left: 7px;
            margin-right: 8px;
            display: block;
        }
    </style>
</head>
<body>

    <header class="app-header">
        <a href="/deposit.php" class="logo img">
            <img src="/to/backbutton.png" alt="Back" style="vertical-align: middle; margin-right: 10px;">
        </a>
        <h1 style="display: inline-block; margin-right: 185px;">Add Money</h1>
    </header>

    <div class="container">
        <?php if ($error): ?>
            <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <form method="POST" onsubmit="document.getElementById('submitBtn').disabled=true;document.getElementById('submitBtn').innerText='Processing...';">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
            
            <!-- Payment Options -->
            <div class="payment-option">
                <img src="/to/Bkash.png" alt="bKash">
                <span><?php echo htmlspecialchars($payment_methods['bkash']['number']); ?></span>
                <div class="copy-button" onclick="copyToClipboard('<?php echo htmlspecialchars($payment_methods['bkash']['number']); ?>')">
                    <img src="/to/copy-icon.png" alt="Copy">
                </div>
                <span class="min-amount">(Minimum 10BDT)</span>
            </div>
            <div class="payment-option">
                <img src="/to/nogod.png" alt="Nagad">
                <span><?php echo htmlspecialchars($payment_methods['nagad']['number']); ?></span>
                <div class="copy-button" onclick="copyToClipboard('<?php echo htmlspecialchars($payment_methods['nagad']['number']); ?>')">
                    <img src="/to/copy-icon.png" alt="Copy">
                </div>
                <span class="min-amount">(Minimum 10BDT)</span>
            </div>
            <div class="payment-option">
                <img src="/to/roket.png" alt="Rocket">
                <span><?php echo htmlspecialchars($payment_methods['rocket']['number']); ?></span>
                <div class="copy-button" onclick="copyToClipboard('<?php echo htmlspecialchars($payment_methods['rocket']['number']); ?>')">
                    <img src="/to/copy-icon.png" alt="Copy">
                </div>
                <span class="min-amount">(Minimum 10BDT)</span>
            </div>

            <!-- Wallet Options -->
            <div class="wallet-options">
                <label>
                    <input type="radio" name="payment_method" value="bkash" class="wallet-radio" hidden required>
                    <img src="/to/Bkash.png" alt="bKash" class="wallet-option">
                </label>
                <label>
                    <input type="radio" name="payment_method" value="nagad" class="wallet-radio" hidden>
                    <img src="/to/nogod.png" alt="Nagad" class="wallet-option">
                </label>
                <label>
                    <input type="radio" name="payment_method" value="rocket" class="wallet-radio" hidden>
                    <img src="/to/roket.png" alt="Rocket" class="wallet-option">
                </label>
            </div>

            <!-- Input Fields -->
            <div class="input-group">
                <input type="text" name="trx-id" placeholder="আপনার যেই নাম্বার থেকে টাকা পাঠিয়েছেন" required>
                <input type="number" name="deposit-amount" placeholder="Amount (BDT)" min="1" max="99999" required>
            </div>

            <!-- Verify Button -->
            <button type="submit" class="verify-button" id="submitBtn">VERIFY</button>
        </form>

        <!-- Information Text -->
        <div class="info-text">
            Verify করার আগে Send Money করতে হবে, নাহলে আপনার Verification সফল হবে না
        </div>

        <!-- Toast Container -->
        <div id="toast"><div id="desc"></div></div>
    </div>

    <script>
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(function() {
                showToast('Copied to clipboard: ' + text);
            }, function(err) {
                showToast('Failed to copy text: ' + err);
            });
        }

        document.querySelectorAll('.wallet-option').forEach(option => {
            option.addEventListener('click', function() {
                document.querySelectorAll('.wallet-option').forEach(opt => opt.classList.remove('selected'));
                this.classList.add('selected');
                this.previousElementSibling.checked = true;
            });
        });

        function showToast(message) {
            const toast = document.getElementById("toast");
            document.getElementById("desc").innerText = message;
            toast.className = "show";
            setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 3000);
        }

        // Prevent context menu from showing on right-click or long-press
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });

        // Prevent the default behavior for right-click and middle-click
        document.addEventListener('mousedown', function(e) {
            if (e.button === 2 || e.button === 3) {
                e.preventDefault();
            }
        });

        // Prevent link behavior on long press
        document.querySelectorAll('a').forEach(function(link) {
            link.addEventListener('touchstart', function() {
                this.setAttribute('data-href', this.getAttribute('href'));
                this.removeAttribute('href');
            });

            link.addEventListener('touchend', function() {
                this.setAttribute('href', this.getAttribute('data-href'));
            });

            link.addEventListener('touchmove', function() {
                this.setAttribute('href', this.getAttribute('data-href'));
            });
        });
    </script>
</body>
</html>