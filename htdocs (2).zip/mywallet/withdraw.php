<?php
session_start();
require_once 'config.php'; // Database connection

// Generate CSRF token if not exists
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Get user information
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT user_uid, winning_balance FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Minimum withdrawal amount
$min_withdraw = 200;

// Initialize variables
$errors = [];
$success_message = '';

// Check for messages from redirect
if (isset($_SESSION['withdrawal_errors'])) {
    $errors = $_SESSION['withdrawal_errors'];
    unset($_SESSION['withdrawal_errors']);
}

if (isset($_SESSION['withdrawal_success'])) {
    $success_message = $_SESSION['withdrawal_success'];
    unset($_SESSION['withdrawal_success']);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate CSRF token
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $errors[] = "Invalid form submission";
    } else {
        // Validate payment method
        if (empty($_POST['payment_method'])) {
            $errors[] = "Please select a payment method.";
        } else {
            $payment_method = $_POST['payment_method'];
            if (!in_array($payment_method, ['bkash', 'nagad', 'rocket'])) {
                $errors[] = "Invalid payment method selected.";
            }
        }
        
        // Validate receiver number
        if (empty($_POST['trx-id'])) {
            $errors[] = "Please enter your mobile number.";
        } else {
            $receiver_number = trim($_POST['trx-id']);
            if (!preg_match('/^\+?\d{11,15}$/', $receiver_number)) {
                $errors[] = "Please enter a valid mobile number.";
            }
        }
        
        // Validate amount
        if (empty($_POST['deposit-amount'])) {
            $errors[] = "Please enter the withdrawal amount.";
        } else {
            $amount = floatval($_POST['deposit-amount']);
            if ($amount < $min_withdraw) {
                $errors[] = "Minimum withdrawal amount is ৳" . $min_withdraw;
            }
            if ($amount > $user['winning_balance']) {
                $errors[] = "Insufficient winning balance.";
            }
        }
    }
    
    // If no errors, process withdrawal
    if (empty($errors)) {
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Insert withdrawal request
            $stmt = $conn->prepare("INSERT INTO withdrawals (user_uid, payment_method, amount, receiver_number, status) 
                                   VALUES (?, ?, ?, ?, 'pending')");
            $stmt->bind_param("ssds", $user['user_uid'], $payment_method, $amount, $receiver_number);
            $stmt->execute();
            $withdrawal_id = $conn->insert_id;
            
            // Deduct from user's winning balance
            $stmt = $conn->prepare("UPDATE users SET winning_balance = winning_balance - ? WHERE id = ?");
            $stmt->bind_param("di", $amount, $user_id);
            $stmt->execute();
            
            // Record transaction
            $stmt = $conn->prepare("INSERT INTO transactions (user_uid, type, amount, from_balance, reference_id) 
                                   VALUES (?, 'withdraw', ?, 'winning', ?)");
            $stmt->bind_param("sds", $user['user_uid'], $amount, $withdrawal_id);
            $stmt->execute();
            
            // Commit transaction
            $conn->commit();
            
            // Store success message and redirect
            $_SESSION['withdrawal_success'] = "Withdrawal request submitted successfully!";
            header('Location: withdraw.php');
            exit;
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            $_SESSION['withdrawal_errors'] = ["Error processing withdrawal: " . $e->getMessage()];
            header('Location: withdraw.php');
            exit;
        }
    } else {
        // Store errors in session for redirect
        $_SESSION['withdrawal_errors'] = $errors;
        header('Location: withdraw.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Withdraw Money</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
    <style>
        * {
            outline: none;
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            margin: 0;
            padding: 0;
        }

        a {
            text-decoration: none;
            color: inherit;
            -webkit-touch-callout: none;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #0e0b27;
            color: #000;
            margin: 0;
            padding: 0;
        }
        .app-header {
            background-color: #07031e;
            color: white;
            padding: 15px;
            display: flex;
            align-items: center;
        }
        .app-header h1 {
            margin: 0;
            font-size: 18px;
            flex-grow: 1;
            text-align: center;
        }
        .back-button {
            color: white;
            text-decoration: none;
            font-size: 24px;
            margin-right: 10px;
        }
        .container {
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            margin: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .user-balance {
            font-size: 18px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }
        .min-withdraw {
            font-size: 14px;
            color: gray;
            text-align: center;
            margin-bottom: 20px;
        }
        .payment-option {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            font-size: 16px;
        }
        .payment-option img {
            width: 25px;
            margin-right: 10px;
        }
        .copy-button {
            margin-left: 10px;
            font-size: 20px;
            cursor: pointer;
        }
        .copy-button img {
            width: 20px;
            height: 20px;
        }
        .min-amount {
            font-size: 14px;
            color: gray;
            margin-left: 10px;
        }
        .wallet-options {
            display: flex;
            justify-content: space-around;
            margin: 20px 0;
        }
        .wallet-options img {
            width: 60px;
            height: auto;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            cursor: pointer;
        }
        .wallet-options img.selected {
            border: 2px solid #000;
        }
        .input-group {
            margin: 20px 0;
        }
        .input-group input {
            width: calc(100% - 20px);
            padding: 10px;
            font-size: 16px;
            margin-left: 12px;
            margin-bottom: 15px;
            border: 2px solid #000;
            border-radius: 8px;
            text-align: center;
            box-sizing: border-box;
        }
        .withdraw-button {
            background-color: #000;
            color: white;
            padding: 15px;
            font-size: 18px;
            text-align: center;
            border-radius: 8px;
            cursor: pointer;
            margin-bottom: 20px;
            display: block;
            width: 100%;
            box-sizing: border-box;
        }
        .info-text {
            text-align: center;
            font-size: 14px;
            color: gray;
        }
        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 20px;
            padding: 10px;
            background-color: #fdd;
            border-radius: 8px;
        }
        .success-message {
            color: green;
            text-align: center;
            margin-bottom: 20px;
            padding: 10px;
            background-color: #dfd;
            border-radius: 8px;
        }
        /* Toast styling */
        #toast {
            visibility: hidden;
            max-width: 50%;
            height: 50px;
            margin-left: -125px;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 2px;
            position: fixed;
            z-index: 1;
            left: 50%;
            bottom: 30px;
            font-size: 17px;
            white-space: nowrap;
        }

        #toast #desc {
            color: #fff;
            padding: 16px;
            margin: 0;
            font-size: 15px;
        }

        #toast.show {
            visibility: visible;
            -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
            animation: fadein 0.5s, fadeout 0.5s 2.5s;
        }

        @-webkit-keyframes fadein {
            from {bottom: 0; opacity: 0;} 
            to {bottom: 30px; opacity: 1;}
        }

        @keyframes fadein {
            from {bottom: 0; opacity: 0;}
            to {bottom: 30px; opacity: 1;}
        }

        @-webkit-keyframes fadeout {
            from {bottom: 30px; opacity: 1;} 
            to {bottom: 0; opacity: 0;}
        }

        @keyframes fadeout {
            from {bottom: 30px; opacity: 1;}
            to {bottom: 0; opacity: 0;}
        }
        .logo img {
            width: 32px;
            height: auto;
            margin-left: 7px;
            margin-right: 8px;
            display: block;
        }
    </style>
</head>
<body>
    <header class="app-header">
        <a href="/mywallet.php" class="logo">
            <img src="/to/backbutton.png" alt="Back" />
        </a>
        <h1 style="display: inline-block; margin-right: 140px;">Withdraw Money</h1>
    </header>

    <div class="container">
        <!-- Display User's Balance -->
        <div class="user-balance">
            AVAILABLE WINNING BALANCE
        </div>
        <div style="text-align: center; font-size: 20px; font-weight: bold; margin-top: -10px;">
            ৳<?= number_format($user['winning_balance'], 2) ?>
        </div>

        <!-- Success or Error Messages -->
        <?php if (!empty($errors)): ?>
            <div class="error-message">
                <?= implode("<br>", $errors) ?>
            </div>
        <?php elseif ($success_message): ?>
            <div class="success-message">
                <?= $success_message ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" onsubmit="return validateForm()">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            
            <!-- Payment Method Options -->
            <div class="wallet-options">
                <label>
                    <input type="radio" name="payment_method" value="bkash" class="wallet-radio" hidden />
                    <img src="/to/Bkash.png" alt="bKash" class="wallet-option" />
                </label>
                <label>
                    <input type="radio" name="payment_method" value="nagad" class="wallet-radio" hidden />
                    <img src="/to/nogod.png" alt="Nagad" class="wallet-option" />
                </label>
                <label>
                    <input type="radio" name="payment_method" value="rocket" class="wallet-radio" hidden />
                    <img src="/to/roket.png" alt="Rocket" class="wallet-option" />
                </label>
            </div>

            <!-- Input Fields -->
            <div class="input-group">
                <input type="number" name="trx-id" placeholder="Enter Number" required />
                <input type="number" name="deposit-amount" placeholder="Amount (BDT)" min="<?= $min_withdraw ?>" step="1" required />
            </div>

            <!-- Withdraw Button -->
            <button type="submit" class="withdraw-button" id="submitBtn">WITHDRAW</button>
        </form>

        <!-- Minimum Withdraw Information -->
        <div class="min-withdraw" style="color: red;">
            Minimum withdrawal amount is ৳<?= $min_withdraw ?>
        </div>

        <!-- Toast Container -->
        <div id="toast"><div id="desc"></div></div>
    </div>

    <script>
        function validateForm() {
            const paymentMethod = document.querySelector('input[name="payment_method"]:checked');
            
            if (!paymentMethod) {
                showToast("Please select a payment method.");
                return false;
            }

            const amount = parseFloat(document.querySelector('input[name="deposit-amount"]').value);
            const minAmount = <?= $min_withdraw ?>;
            
            if (amount < minAmount) {
                showToast("Minimum withdrawal amount is ৳" + minAmount);
                return false;
            }

            // Disable button to prevent multiple submissions
            document.getElementById('submitBtn').disabled = true;
            document.getElementById('submitBtn').textContent = 'Processing...';
            
            return true;
        }

        // Handle wallet option selection
        document.querySelectorAll('.wallet-option').forEach(option => {
            option.addEventListener('click', function() {
                document.querySelectorAll('.wallet-option').forEach(opt => opt.classList.remove('selected'));
                this.classList.add('selected');
                this.previousElementSibling.checked = true;
            });
        });

        function showToast(message) {
            const toast = document.getElementById("toast");
            document.getElementById("desc").innerText = message;
            toast.className = "show";
            setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 3000);
        }
    </script>
    
    <script>
        // Prevent context menu from showing on right-click or long-press
        document.addEventListener('contextmenu', function(e) {
            e.preventDefault();
        });

        // Prevent the default behavior for right-click and middle-click
        document.addEventListener('mousedown', function(e) {
            if (e.button === 2 || e.button === 3) {
                e.preventDefault();
            }
        });

        // Prevent link behavior on long press
        document.querySelectorAll('a').forEach(function(link) {
            link.addEventListener('touchstart', function() {
                this.setAttribute('data-href', this.getAttribute('href'));
                this.removeAttribute('href');
            });

            link.addEventListener('touchend', function() {
                this.setAttribute('href', this.getAttribute('data-href'));
            });

            link.addEventListener('touchmove', function() {
                this.setAttribute('href', this.getAttribute('data-href'));
            });
        });
    </script>
</body>
</html>