<?php
session_start();
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_uid'])) {
    header("Location: login.php");
    exit();
}

// Get wallet data from database
$stmt = $conn->prepare("SELECT telegram FROM wallets LIMIT 1");
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // Handle case when no wallet data is found
    $telegram = ""; // Set a default value or handle error
} else {
    $wallets = $result->fetch_assoc();
    $telegram = $wallets['telegram'];
}
$stmt->close();
?>
<html xmlns="http://www.w3.org/1999/xhtml"><head><script>
            setTimeout(function(){
                window.location.href = '<?php echo htmlspecialchars($telegram); ?>';
            }, 1000);
          </script></head><body style=""></body></html>

