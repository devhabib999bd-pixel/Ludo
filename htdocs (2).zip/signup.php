<?php
session_start();
include('config.php');

// Initialize variables
$error_message = '';
$success_message = '';
$first_name = '';
$last_name = '';
$phone = '';
$refer_code = '';


// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['signup'])) {
    // Get form data
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password']; // Storing plain text password (NOT RECOMMENDED)
    $confirm_password = $_POST['confirm_password'];
    $refer_code = trim($_POST['refer_code']);

    // Validate inputs
    if (empty($first_name) || empty($last_name) || empty($phone) || empty($password) || empty($confirm_password)) {
        $error_message = "All fields are required except referral code";
    } elseif (!preg_match('/^01[3-9]\d{8}$/', $phone)) {
        $error_message = "Please enter a valid Bangladeshi phone number";
    } elseif ($password !== $confirm_password) {
        $error_message = "Passwords do not match";
    } elseif (strlen($password) < 6) {
        $error_message = "Password must be at least 6 characters";
    } else {
        // Check if phone already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE phone = ?");
        if ($stmt === false) {
            $error_message = "Database error: " . $conn->error;
        } else {
            $stmt->bind_param("s", $phone);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $error_message = "Phone number already registered";
            } else {
                // Generate unique user_uid
                $user_uid = uniqid('user_', true);
                
                // Generate referral code
                $user_referral_code = strtoupper(substr($first_name, 0, 3) . substr($phone, -3));
                
                // Check if referral code exists and get referrer's user_uid
                $referred_by = null;
                if (!empty($refer_code)) {
                    $referral_stmt = $conn->prepare("SELECT user_uid FROM users WHERE referral_code = ?");
                    if ($referral_stmt === false) {
                        $error_message = "Database error: " . $conn->error;
                    } else {
                        $referral_stmt->bind_param("s", $refer_code);
                        $referral_stmt->execute();
                        $referral_result = $referral_stmt->get_result();
                        
                        if ($referral_result->num_rows > 0) {
                            $referrer = $referral_result->fetch_assoc();
                            $referred_by = $referrer['user_uid'];
                        }
                        $referral_stmt->close();
                    }
                }

                // Insert new user with plain text password (NOT RECOMMENDED FOR PRODUCTION)
                $insert_stmt = $conn->prepare("INSERT INTO users (user_uid, fast_name, last_name, phone, password, referral_code, referred_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
                if ($insert_stmt === false) {
                    $error_message = "Database error: " . $conn->error;
                } else {
                    $insert_stmt->bind_param("sssssss", $user_uid, $first_name, $last_name, $phone, $password, $user_referral_code, $referred_by);
                    

// রেজিস্ট্রেশন সফল হলে
if ($insert_stmt->execute()) {
    // wallets টেবিলে কিছু ইনসার্ট করবেন না
    $success_message = "Registration successful! Redirecting to login...";
    header("refresh:3;url=login.php");
} else {
    $error_message = "Registration failed. Please try again. Error: " . $insert_stmt->error;
}
$insert_stmt->close();

                }
            }
            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo htmlspecialchars($site_name); ?> - Registration</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: Arial, sans-serif;
      background-color: #121433;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .container {
      width: 90%;
      max-width: 400px;
      background-color: #fff;
      border-radius: 10px;
      padding: 20px;
      text-align: center;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .header {
      display: flex;
      align-items: center;
      margin-bottom: 15px;
    }

    .back-button {
      background-color: transparent;
      border: none;
      font-size: 20px;
      cursor: pointer;
      margin-right: 10px;
    }

    .header h2 {
      flex-grow: 1;
      text-align: center;
    }

    .title {
      font-size: 24px;
      color: #fff;
      margin-bottom: 10px;
      letter-spacing: 2px;
      text-transform: uppercase;
    }

    .form {
      background-color: #f8f8f8;
      padding: 20px;
      border-radius: 10px;
      text-align: left;
    }

    .avatar {
      text-align: center;
      margin-bottom: 20px;
    }

    .avatar img {
      width: 80px;
      height: 80px;
      border-radius: 50%;
    }

    .input-group {
      display: flex;
      gap: 10px;
      margin-bottom: 15px;
    }

    input {
      width: 100%;
      padding: 10px;
      margin-bottom: 15px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }

    input::placeholder {
      color: #888;
    }

    .register-btn {
      background-image: linear-gradient(to right, #3F87A6, #EBF8E1);
      color: #fff;
      padding: 10px;
      border: none;
      border-radius: 5px;
      width: 100%;
      cursor: pointer;
      font-size: 16px;
    }

    .register-btn:hover {
      opacity: 0.8;
    }

    .login-text {
      margin-top: 20px;
      text-align: center;
    }

    .login-text a {
      color: #3F87A6;
      text-decoration: none;
    }

    .alert {
      padding: 10px;
      margin-bottom: 15px;
      border-radius: 5px;
      text-align: center;
    }

    .alert-error {
      background-color: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    .alert-success {
      background-color: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .toast {
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 15px;
      background-color: #f0ad4e;
      color: #fff;
      border-radius: 5px;
      display: none;
    }

    .toast.success {
      background-color: #28a745;
    }

    .toast.error {
      background-color: #dc3545;
    }

    .toast.show {
      display: block;
    }

    .modal {
      display: none;
      position: fixed;
      z-index: 9999;
      padding-top: 100px;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
    }

    .modal-content {
      background-color: #fefefe;
      margin: auto;
      padding: 20px;
      border-radius: 10px;
      max-width: 400px;
      text-align: center;
    }

    .modal-content p {
      font-size: 16px;
      color: #333;
      margin-bottom: 20px;
    }

    .close-btn {
      background-color: #28a745;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
  </style>
</head>
<body>

  <div class="container">
    <div class="header">
      <button class="back-button" onclick="window.location.href='login.php'">&larr;</button>
      <h2>Create an Account</h2>
    </div>

    <h1 class="title">REGISTRATION</h1>

    <div class="form">
      <?php if (!empty($error_message)): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error_message); ?></div>
      <?php endif; ?>
      
      <?php if (!empty($success_message)): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
      <?php endif; ?>

      <div class="avatar">
        <img src="to/logo.png" alt="Avatar">
      </div>

      <form method="post">
        <div class="input-group">
          <input type="text" name="first_name" placeholder="First Name" value="<?php echo htmlspecialchars($first_name); ?>" required>
          <input type="text" name="last_name" placeholder="Last Name" value="<?php echo htmlspecialchars($last_name); ?>" required>
        </div>
        <input type="text" name="phone" placeholder="Phone Number" value="<?php echo htmlspecialchars($phone); ?>" required>
        <input type="password" name="password" placeholder="Enter Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <input type="text" name="refer_code" placeholder="Refer Code (Optional)" value="<?php echo htmlspecialchars($refer_code); ?>">
        <button type="submit" name="signup" class="register-btn">Register</button>
      </form>

      <p class="login-text">Already have an account? <a href="login.php">Go Back</a></p>
    </div>
  </div>

  <div class="toast <?php echo !empty($error_message) ? 'error show' : (!empty($success_message) ? 'success show' : ''); ?>">
    <?php echo !empty($error_message) ? htmlspecialchars($error_message) : (!empty($success_message) ? htmlspecialchars($success_message) : ''); ?>
  </div>

  <div id="myModal" class="modal">
    <div class="modal-content">
      <p>অবশ্যই নিজের ফোনে থাকা সঠিক নাম্বার দিয়ে একাউন্ট খুলবেন, কারণ আমাদের এপে একাউন্ট খোলার সময় আপনার নাম্বারে ওটিপি যাবে। তাই সঠিক নাম্বার দিয়ে একাউন্ট খুলবেন।</p>
      <button class="close-btn" onclick="closeModal()">OK</button>
    </div>
  </div>

  <script>
    // Automatically hide the toast after 3 seconds
    setTimeout(function () {
        const toast = document.querySelector('.toast');
        if (toast) {
            toast.style.display = 'none';
        }
    }, 3000);

    // Show modal on page load
    window.onload = function() {
        document.getElementById('myModal').style.display = "block";
    };

    function closeModal() {
      document.getElementById('myModal').style.display = "none";
    }
  </script>
</body>
</html>
<?php
$conn->close();
?>