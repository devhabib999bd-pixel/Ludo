<?php
session_start();
require_once 'config.php'; // Database configuration file

// Check if user is logged in
if (!isset($_SESSION['user_uid'])) {
    header("Location: login.php");
    exit();
}

$user_uid = $_SESSION['user_uid'];

// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}

// Fetch user data and balance
$user_query = "SELECT referral_code, gaming_balance, winning_balance, is_banned, ban_reason FROM users WHERE user_uid = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("s", $user_uid);
$stmt->execute();
$user_result = $stmt->get_result();

$gaming_balance = 0;
$winning_balance = 0;
$is_banned = false;
$ban_reason = '';

if ($user_result->num_rows > 0) {
    $user = $user_result->fetch_assoc();
    $gaming_balance = $user['gaming_balance'];
    $winning_balance = $user['winning_balance'];
    $is_banned = $user['is_banned'];
    $ban_reason = $user['ban_reason'];
    $referral_code = $user['referral_code'];
}
$stmt->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no"> <!-- Prevent zooming -->
    <title><?php echo htmlspecialchars($site_name); ?> - Support</title>
    <link rel="stylesheet" href="profile.css">
    <style>
       * {
            outline: none;
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        a {
            text-decoration: none;
            color: inherit;
            -webkit-touch-callout: none;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
        }

        /* Font-face declarations */
        @font-face {
            font-family: 'HindSiliguri-Medium';
            src: url('font/HindSiliguri-Medium.ttf') format('truetype');
        }

        @font-face {
            font-family: 'HindSiliguri-Bold';
            src: url('font/HindSiliguri-Bold.ttf') format('truetype');
        }

        @font-face {
            font-family: 'LEMONMILK-Regular';
            src: url('font/LEMONMILK-Regular.otf') format('truetype');
        }

        @font-face {
            font-family: 'FaRegular';
            src: url('font/fa-regular-400.ttf') format('truetype');
        }

        @font-face {
            font-family: 'FaBrands';
            src: url('font/fa-brands-400.ttf') format('truetype');
        }

        @font-face {
            font-family: 'BebasNeue';
            src: url('font/BebasNeue-Regular.otf') format('opentype');
        }

        body {
            margin: 0;
            padding: 0;
            font-family: 'HindSiliguri-Medium', Arial, sans-serif;
            background-color: #0e0b27; /* Dark background for the entire app */
            color: white;
            display: flex;
            flex-direction: column;
            height: 100vh;
            justify-content: space-between;
        }

        .app-header {
            background-color: #07031e; /* Match the navigation background color */
            height: 50px; /* Set header height to 65px */
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 5px;
        }

        .header-content {
            display: flex;
            align-items: center;
            width: 100%;
        }

        .logo {
            height: 38px; 
            margin-left: 10px;
        }

        .app-title {
            color: white;
            font-size: 1.05em;
            flex-grow: 1;
            text-align: center;
            margin-left: -90px;
            position: relative;
            display: inline-block;
            background: linear-gradient(90deg, #ffffff 10%, #cccccc 20%, #2a5280 30%, #ffffff 40%);
            background-size: 200% auto;
            color: transparent;
            background-clip: text;
            -webkit-background-clip: text;
            text-fill-color: transparent;
            animation: shimmer 3s linear infinite;
            font-family: 'LEMONMILK-Regular', sans-serif;
            letter-spacing: 0.5px;
        }

        @keyframes shimmer {
            0% {
                background-position: -200% 0;
            }
            100% {
                background-position: 200% 0;
            }
        }

        .wallet-icon {
            display: flex;
            align-items: center;
            padding: 5px 10px; /* Padding inside the border */
            border: 2px solid #fff; /* White border */
            border-radius: 40px; /* Rounded corners */
            background-color: #1b1a3a;
            font-size: 0.9em; /* Background color for wallet area */
            font-family: 'HindSiliguri-Medium', sans-serif;
            cursor: pointer; /* Add cursor pointer to indicate it's clickable */
        }

        .wallet-icon img {
            height: 20px; /* Adjust size as needed */
            margin-right: 10px; /* Space between the icon and the balance text */
        }

        .balance-text {
            font-size: 1.2em; /* Adjust font size as needed */
            color: white; /* Text color */
        }

        .main-content {
            flex-grow: 1;
            padding: 20px;
            text-align: center;
        }

        .container {
            max-width: 400px;
            margin: 0 auto;
            padding: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            background-color: #111;
            border-radius: 10px;
            margin-bottom: 3em;
        }

        .hamster-icon {
            width: 80px;
            height: auto;
            border-radius: 50%;
            box-shadow: 0 0 10px rgba(255, 215, 0, 0.5);
        }

        .tasks h3 {
            font-size: 18px;
            margin: 20px 0 10px;
            color: #FFD700;
        }

        .task-item {
            display: flex;
            align-items: center;
            background-color: #fff;
            padding: 7px;
            border-radius: 8px;
            margin-bottom: 6px;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .task-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 12px rgba(30, 136, 229, 0.5);
        }

        .task-icon {
            width: 25px;
            height: auto;
            margin-right: 10px;
        }

        .task-info {
            flex: 1;
            color: #000;
        }

        .task-info button {
            padding: 10px 20px;
            background-color: #FFD700;
            color: #000;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s ease, transform 0.3s ease;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        }

        .task-info button:hover {
            background-color: #FFC107;
            transform: translateY(-2px);
        }

        .bottom-navigation {
            background-color: #07031e; /* Updated background color */
            display: flex;
            justify-content: space-around;
            padding-bottom: -0px;
            position: fixed;
            width: 100%;
            bottom: -4px;
        }

        .nav-item {
            text-align: center;
            color: #ccc;
            text-decoration: none;
            font-size: 0.8.5em;
            transition: transform 0.2s ease, color 0.2s ease, opacity 0.2s ease; /* Add transition for animation */
            cursor: pointer; /* Make the nav item clickable */
            -webkit-tap-highlight-color: transparent; /* Disable tap highlight color */
            opacity: 1; /* Default fully visible */
            font-family: 'HindSiliguri-Medium', sans-serif;
        }

        .nav-item img {
            width: 22px; /* Adjust icon size */
            height: auto;
            display: block;
            margin: 0 auto 5px;
            transition: transform 0.2s ease, opacity 0.2s ease; /* Add transition for animation */
            -webkit-tap-highlight-color: transparent; /* Disable tap highlight color */
        }

        /* Active and hover states */
        .nav-item:hover, .nav-item:focus, .nav-item:active {
            transform: scale(1.1); /* Scale up the icon and text */
            color: #fff; /* Change color to white */
        }

        .nav-item:hover img, .nav-item:focus img, .nav-item:active img {
            transform: scale(1.2); /* Scale up the icon a bit more */
        }

        /* Inactive state when another button is clicked */
        .inactive {
            opacity: 0.5; /* Make other buttons faded */
        }
    </style>
</head>
<body>

<header class="app-header">
    <div class="header-content">
        <img src="<?php echo htmlspecialchars($site_logo); ?>" alt="Site Logo" class="logo">
        <h1 class="app-title"><?php echo htmlspecialchars($site_name); ?></h1>
        <div class="wallet-icon" id="walletIcon">
            <img src="to/wallet2.png" alt="Wallet">
            <span class="balance-text"><?php echo $gaming_balance + $winning_balance; ?></span> <!-- Example balance text -->
        </div>
    </div>
</header>

<div class="main-content">
    <!-- Main content of your page goes here -->

    <div class="container">
        <div class="main-content">
            <img src="to/contact.png" alt="Support Icon" class="hamster-icon">
            <h2>Admin Support</h2>
        </div>

        <!-- Support Options Section -->
        <section class="tasks">
            <h3>Support Options</h3>
            <div class="task-item">
                <img src="to/telegram.png" alt="Telegram Icon" class="task-icon">
                <div class="task-info">
                    <button onclick="openTelegram()">Open Telegram</button>
                </div>
                <div class="task-status">→</div>
            </div>
            <div class="task-item">
                <img src="to/wh.png" alt="WhatsApp Icon" class="task-icon">
                <div class="task-info">
                    <button onclick="openWhatsApp()">Open WhatsApp</button>
                </div>
                <div class="task-status">→</div>
            </div>
        </section>
    </div>
</div>

<nav class="bottom-navigation">
    <a style="color: #fff;" href="admin.php" class="nav-item" id="chat">
        <img src="to/chat1.png" alt="Chat">
        <span>Chat</span>
    </a>
    <a style="color: #fff;" href="index.php" class="nav-item" id="play">
        <img src="to/play2.png" alt="Play">
        <span>Play</span>
    </a>
    <a style="color: #fff;" href="profile.php" class="nav-item" id="me">
        <img src="to/profile1.png" alt="Me">
        <span>Me</span>
    </a>
</nav>

<script>
    // JavaScript to handle the wallet-icon click event
    document.getElementById('walletIcon').addEventListener('click', function() {
        window.location.href = 'mywallet.php';
    });

    // JavaScript to handle active state in bottom navigation
    document.addEventListener('DOMContentLoaded', function () {
        const navItems = document.querySelectorAll('.nav-item');

        navItems.forEach(item => {
            item.addEventListener('click', function () {
                // Remove 'active' class from all nav items
                navItems.forEach(nav => nav.classList.remove('active'));
                
                // Add 'active' class to the clicked nav item
                this.classList.add('active');
            });
        });
    });

    // Open Telegram function
    function openTelegram() {
        window.location.href = 'telegram.php'; // Replace with your Telegram link
    }

    // Open WhatsApp function
    function openWhatsApp() {
        window.location.href = 'whatsapp.php'; // Replace with your WhatsApp link
    }// JavaScript to prevent context menu
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
    });

    // Prevent other long-press actions that might open the context menu
    document.addEventListener('mousedown', function(e) {
        if (e.button === 2 || e.button === 3) { // Right-click or middle-click
            e.preventDefault();
        }
    });

    // Prevent link from showing on long press
    document.querySelectorAll('a').forEach(function(link) {
        link.addEventListener('touchstart', function() {
            this.setAttribute('data-href', this.getAttribute('href')); // Save href
            this.removeAttribute('href'); // Remove href
        });

        link.addEventListener('touchend', function() {
            this.setAttribute('href', this.getAttribute('data-href')); // Restore href
        });

        link.addEventListener('touchmove', function() {
            this.setAttribute('href', this.getAttribute('data-href')); // Restore href on touch move
        });
    });
</script>

</body>
</html>
