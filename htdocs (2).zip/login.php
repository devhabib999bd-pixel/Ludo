<?php
session_start();
require_once 'config.php'; // নিশ্চিত করুন config.php সঠিক

// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}
// Initialize variables
$error_message = '';
$phone = '';

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    
    // Validate inputs
    if (empty($phone) || empty($password)) {
        $error_message = "Phone number and password are required";
    } else {
        // Prepare and execute query - password_hash এর জায়গায় password ব্যবহার করুন
        $stmt = $conn->prepare("SELECT id, user_uid, phone, password, is_banned, ban_reason FROM users WHERE phone = ?");
        
        // Error handling যোগ করুন
        if ($stmt === false) {
            die("Prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param("s", $phone);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            // Verify password (plain text comparison - NOT RECOMMENDED)
            if ($password === $user['password']) {
                // Check if user is banned
                if ($user['is_banned']) {
                    $error_message = "Your account is banned. Reason: " . htmlspecialchars($user['ban_reason']);
                } else {
                    // Login successful
                    $_SESSION['user_uid'] = $user['user_uid'];
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['phone'] = $user['phone'];
                    
                    // Update last login
                    $update_stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
                    $update_stmt->bind_param("i", $user['id']);
                    $update_stmt->execute();
                    $update_stmt->close();
                    
                    header("Location: index.php");
                    exit();
                }
            } else {
                $error_message = "Invalid phone number or password";
            }
        } else {
            $error_message = "Invalid phone number or password";
        }
        $stmt->close();
    }
}

// HTML অংশ এখানে শুরু হবে
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($site_name); ?> - Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #000000, #421C52);
            color: #fff;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            text-align: center;
            padding: 20px;
            width: 100%;
            max-width: 400px;
        }

        .logo h1 {
            font-size: 22px;
            margin-bottom: 5px;
        }

        .logo h2 {
            font-size: 28px;
            font-weight: bold;
            color: #ccc;
            letter-spacing: 1px;
        }

        .logo p {
            font-size: 14px;
            color: #d3d3d3;
            margin-top: 10px;
            margin-bottom: 30px;
        }

        .login-box {
            background: #fff;
            border-radius: 10px;
            padding: 30px 25px;
            margin-left: 16px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.3);
        }

        .login-box form {
            display: flex;
            flex-direction: column;
        }

        .input-group {
            position: relative;
            margin-bottom: 20px;
            margin-left: 6px;
        }

        .input-group input {
            width: 100%;
            padding: 12px 15px;
            padding-left: 40px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        .input-group i {
            position: absolute;
            top: 50%;
            left: 15px;
            transform: translateY(-50%);
            color: #777;
            font-size: 18px;
        }

        .forgot-password {
            text-align: right;
            margin-bottom: 20px;
        }

        .forgot-password a {
            color: #777;
            font-size: 12px;
            text-decoration: none;
        }

        .sign-in-btn {
            background: linear-gradient(90deg, #4e79da, #31a2d4);
            border: none;
            color: white;
            padding: 12px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-bottom: 20px;
        }

        .sign-in-btn:hover {
            opacity: 0.9;
        }

        .register {
            font-size: 14px;
            color: #555;
        }

        .register a {
            color: #31a2d4;
            text-decoration: none;
        }

        .register a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .login-box {
                width: 90%;
            }
        }

        /* Toast Notification */
        .toast {
            visibility: hidden;
            min-width: 250px;
            background-color: #f44336;
            color: #fff;
            text-align: center;
            border-radius: 5px;
            padding: 16px;
            position: fixed;
            z-index: 1;
            top: 30px;
            right: 30px;
            font-size: 17px;
        }

        .toast.show {
            visibility: visible;
            -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
            animation: fadein 0.5s, fadeout 0.5s 2.5s;
        }

        @-webkit-keyframes fadein {
            from {top: 0; opacity: 0;}
            to {top: 30px; opacity: 1;}
        }

        @keyframes fadein {
            from {top: 0; opacity: 0;}
            to {top: 30px; opacity: 1;}
        }

        @-webkit-keyframes fadeout {
            from {top: 30px; opacity: 1;}
            to {top: 0; opacity: 0;}
        }

        @keyframes fadeout {
            from {top: 30px; opacity: 1;}
            to {top: 0; opacity: 0;}
        }

        /* Error message style */
        .error-message {
            color: #ff6b6b;
            text-align: center;
            margin-bottom: 15px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <h1>WELCOME TO</h1>
            <h2><?php echo htmlspecialchars($site_name); ?></h2>
            <p>গেইম খেলুন এবং টাকা জিতুন</p>
        </div>
        <div class="login-box">
            <?php if (!empty($error_message)): ?>
                <div class="error-message"><?php echo htmlspecialchars($error_message); ?></div>
            <?php endif; ?>
            
            <form action="login.php" method="POST">
                <div class="input-group">
                    <i class="fas fa-phone"></i>
                    <input type="text" name="phone" placeholder="Phone Number" value="<?php echo htmlspecialchars($phone); ?>" required>
                </div>
                <div class="input-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" placeholder="Password" required>
                </div>
                
                <div class="forgot-password">
                    <a href="forgot_password.php">Forgot Password?</a>
                </div>
                
                <button type="submit" name="login" class="sign-in-btn">SIGN IN</button>
                <div class="register">
                    <p>New Users? <a href="signup.php">Create an Account</a></p>
                    <p>Have any problem? <a href="redirect_to_telegram.php">Contact Us</a></p>
                </div>
            </form>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toast" class="toast"></div>

    <script>
        // Show toast if error message exists
        <?php if (!empty($error_message)): ?>
            document.addEventListener('DOMContentLoaded', function() {
                var toast = document.getElementById("toast");
                toast.textContent = "<?php echo addslashes($error_message); ?>";
                toast.className = "toast show";
                setTimeout(function(){ toast.className = toast.className.replace("show", ""); }, 3000);
            });
        <?php endif; ?>
    </script>
</body>
</html>
<?php
$conn->close();
?>