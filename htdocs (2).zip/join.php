<?php
session_start();
require_once 'config.php'; // Database connection (MySQLi)

// Check if user is logged in
if (!isset($_SESSION['user_uid'])) {
    header("Location: login.php");
    exit();
}

// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}

// Initialize variables
$error = '';
$success = '';
$room_id = $_POST['roomid'] ?? '';
$game_name = $_POST['game_name'] ?? '';
$userId = $_SESSION['user_uid'];
$userBalance = 0;
$match = null;
$isJoined = false;
$isFull = false;

// Get user balance
$stmt = $conn->prepare("SELECT gaming_balance FROM users WHERE user_uid = ?");
$stmt->bind_param("s", $userId);
$stmt->execute();
$stmt->bind_result($userBalance);
$stmt->fetch();
$stmt->close();

// Get match data
if (!empty($room_id)) {
    $stmt = $conn->prepare("SELECT * FROM matches WHERE room_id = ?");
    $stmt->bind_param("s", $room_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $match = $result->fetch_assoc();
    $stmt->close();
    
    if ($match) {
        // Check if match is full
        $stmt = $conn->prepare("SELECT COUNT(*) FROM match_participants WHERE match_id = ?");
        $stmt->bind_param("i", $match['id']);
        $stmt->execute();
        $stmt->bind_result($joined_players);
        $stmt->fetch();
        $stmt->close();
        
        $isFull = ($joined_players >= $match['total_players']);
        
        // Check if user already joined
        $stmt = $conn->prepare("SELECT COUNT(*) FROM match_participants WHERE match_id = ? AND user_uid = ?");
        $stmt->bind_param("is", $match['id'], $userId);
        $stmt->execute();
        $stmt->bind_result($already_joined);
        $stmt->fetch();
        $stmt->close();
        
        $isJoined = ($already_joined > 0);
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_join'])) {
    if (empty($room_id)) {
        $error = "Room ID is required!";
    } elseif (empty($game_name)) {
        $error = "Game name is required!";
    } elseif (!$match) {
        $error = "Match not found!";
    } elseif ($isFull) {
        $error = "This match is already full!";
    } elseif ($isJoined) {
        $error = "You've already joined this match!";
    } else {
        // Check balance
        if ($userBalance < $match['entry_fee']) {
            $error = "Insufficient balance to join this match!";
        } else {
            // Begin transaction
            $conn->begin_transaction();
            try {
                // Deduct balance
                $stmt = $conn->prepare("UPDATE users SET gaming_balance = gaming_balance - ? WHERE user_uid = ?");
                $stmt->bind_param("ds", $match['entry_fee'], $userId);
                $stmt->execute();
                $stmt->close();

                // Log transaction
                $stmt = $conn->prepare("INSERT INTO transactions (user_uid, type, amount, from_balance, to_balance, reference_id) VALUES (?, 'match_entry', ?, 'gaming', 'gaming', ?)");
                $reference = "Match ID: " . $match['id'];
                $stmt->bind_param("sds", $userId, $match['entry_fee'], $reference);
                $stmt->execute();
                $stmt->close();

                // Add participant
                $stmt = $conn->prepare("INSERT INTO match_participants (match_id, user_uid, game_name) VALUES (?, ?, ?)");
                $stmt->bind_param("iss", $match['id'], $userId, $game_name);
                $stmt->execute();
                $stmt->close();

                // Update joined count
                $stmt = $conn->prepare("UPDATE matches SET joined_players = joined_players + 1 WHERE id = ?");
                $stmt->bind_param("i", $match['id']);
                $stmt->execute();
                $stmt->close();

                // Commit
                $conn->commit();

                $success = "Successfully joined the match! Room ID will be available before the match starts.";
                $isJoined = true;
                
                // Refresh user balance
                $stmt = $conn->prepare("SELECT gaming_balance FROM users WHERE user_uid = ?");
                $stmt->bind_param("s", $userId);
                $stmt->execute();
                $stmt->bind_result($userBalance);
                $stmt->fetch();
                $stmt->close();
            } catch (Exception $e) {
                $conn->rollback();
                $error = "Something went wrong: " . $e->getMessage();
            }
        }
    }
}

// If not POST and no match loaded
if ($_SERVER['REQUEST_METHOD'] !== 'POST' && !$match) {
    header("Location: ludomatch.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($site_name); ?> - Join Match</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
         * {
            outline: none;
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            margin: 0;
            padding: 0;
        }

        a {
            text-decoration: none;
            color: inherit;
            -webkit-touch-callout: none;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
        }

        body {
            background-color: #000033;
            color: white;
            font-family: Arial, sans-serif;
            margin: 0;
        }

        .game-container {
            max-width: 400px;
            margin: 50px auto;
            background-color: #000033;
            border-radius: 10px;
            margin-left: 13px;
            margin-right: 13px;
            overflow: hidden;
        }

        .game-container2 {
            max-width: 400px;
            margin: 50px auto;
            background-color: #000033;
            border-radius: 10px;
            margin-left: 13px;
            margin-right: 13px;
            overflow: hidden;
        }

        .game-header {
            background-color: #000033;
            padding: 0;
        }

        .game-header img {
            width: 100%;
            display: block;
        }

        .section {
            background-color: white;
            color: #000033;
            text-align: center;
            padding: 5px;
            margin-bottom: 15px;
            border-radius: 5px;
        }

        .section h5 {
            margin: 0;
            font-size: 19px;
            font-weight: bold;
        }

        .section p {
            font-size: 15px;
            margin: 5px 0;
        }

        .entry-fee, .win-prize {
            font-weight: bold;
            font-size: 18px;
        }

        .entry-fee span {
            color: green;
        }

        .win-prize span {
            color: orange;
        }

        .player-input input {
            width: 100%;
            padding: 10px;
            border: 1px solid #000033;
            border-radius: 5px;
            color: #000033;
        }

        .join-now {
            margin-top: 20px;
        }

        .join-now button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            border-color: #007bff;
            border-radius: 5px;
            color: white;
            font-size: 16px;
        }

        .app-header {
            background-color: #07031e;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 100%;
            box-sizing: border-box;
        }

        .header-content {
            display: flex;
            align-items: center;
            width: 100%;
        }

        .logo {
            display: inline-block;
            cursor: pointer;
            padding: 10px;
        }

        .logo img {
            width: 30px;
            height: auto;
            display: block;
        }

        .app-title {
            color: white;
            font-size: 1.2em;
            flex-grow: 1;
            margin-top: 10px;
            background: linear-gradient(90deg, #ffffff 10%, #cccccc 20%, #2a5280 30%, #ffffff 40%);
            background-size: 200% auto;
            color: transparent;
            background-clip: text;
            -webkit-background-clip: text;
            text-fill-color: transparent;
            animation: shimmer 3s linear infinite;
            font-family: 'LEMONMILK-Regular', sans-serif;
            letter-spacing: 0.5px;
        }

        @keyframes shimmer {
            0% {
                background-position: -200% 0;
            }

            100% {
                background-position: 200% 0;
            }
        }

        .wallet-icon {
            display: flex;
            align-items: center;
            padding: 5px 10px;
            border: 2px solid #fff;
            border-radius: 40px;
            background-color: #1b1a3a;
            font-size: 0.9em;
            font-family: 'HindSiliguri-Medium', sans-serif;
        }

        .wallet-icon img {
            height: 20px;
            margin-right: 10px;
        }

        .balance-text {
            font-size: 1em;
            color: white;
        }

        .error-message {
            color: red;
            margin-top: 10px;
        }

        .success-message {
            color: green;
            margin-top: 10px;
        }
        
        .btn-joined {
            background-color: #28a745 !important;
            border-color: #28a745 !important;
        }
        
        .btn-full {
            background-color: #dc3545 !important;
            border-color: #dc3545 !important;
            cursor: not-allowed;
        }
    </style>
</head>
<body style="">

<header class="app-header">
    <div class="header-content">
        <a href="/ludomatch.php" class="logo">
            <img src="to/backbutton.png" alt="Back Icon" />
        </a>
     <h1 class="app-title"><?php echo htmlspecialchars($site_name); ?></h1>
        <div class="wallet-icon" id="walletIcon">
            <img src="to/wallet2.png" alt="Wallet" />
            <span class="balance-text">৳<?php echo number_format($userBalance, 2); ?></span>
        </div>
    </div>
</header>

<div class="game-container2">
    <div class="game-header">
        <img src="/to/lll.png" alt="Ludo Hero" />
    </div>
    <div class="section">
     <h5><?php echo htmlspecialchars($match['match_title']); ?></h5>
        <p><?php echo htmlspecialchars($match['match_description']); ?></p>
    </div>
    <div class="section">
        <div style="display: flex; align-items: center; justify-content: center;">
            <p class="entry-fee" style="margin: 0;">Entry Fee: <span>৳<?php echo number_format($match['entry_fee'], 2); ?></span></p>
            <p style="margin: 0 5px;">|</p>
            <p class="win-prize" style="margin: 0;">Win Prize: <span>৳<?php echo htmlspecialchars($match['total_price']); ?></span></p>
        </div>
    </div>
    <form method="POST">
        <input type="hidden" name="roomid" value="<?php echo htmlspecialchars($room_id); ?>" />
        <div class="section player-input">
            <label for="playerName">Enter your game name here:</label>
            <input type="text" class="form-control" id="playerName" name="game_name" value="<?php echo htmlspecialchars($game_name); ?>" <?php echo $isJoined || $isFull ? 'readonly' : ''; ?> />
            <div class="join-now">
                <?php if ($isJoined): ?>
                    <button type="button" class="btn btn-joined btn-lg" disabled>JOINED</button>
                <?php elseif ($isFull): ?>
                    <button type="button" class="btn btn-full btn-lg" disabled>FULL</button>
                <?php else: ?>
                    <button type="button" class="btn btn-primary btn-lg" data-bs-toggle="modal" data-bs-target="#confirmationModal">
                        JOIN NOW
                    </button>
                <?php endif; ?>
            </div>
        </div>
        <input type="hidden" name="confirm_join" value="1" />
    </form>
</div>

<!-- Confirmation Modal -->
<div class="modal fade" id="confirmationModal" tabindex="-1" aria-labelledby="confirmationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 style="color: black;" class="modal-title" id="confirmationModalLabel">Confirm Your Entry</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p style="color: black;">Please confirm the following rules before joining:</p>
                <ul style="color: black;">
                    <li>আপনার মোবাইলে অবশ্যই Ludo King গেমটি থাকতে হবে।</li>
                    <li>LUDO BD অ্যাপে যে নাম দিয়ে User নাম দেওয়া আছে তেমনি হুবুহু নাম দিয়ে Ludo King অ্যাপে নাম দিয়ে একাউন্ট করতে হব।</li>
                    <li>Room ID ম্যাচ শুরু হওয়ার 3 মিনিট পূর্বে দেওয়া হবে।সেই Room Code কপি করে Ludo King Join দিতে হবে।</li>
                </ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="confirmJoin">Confirm</button>
            </div>
        </div>
    </div>
</div>

    <div class="container mt-5">
        <?php if (!empty($error)): ?>
            <div class="error-message">
                <h3><?php echo htmlspecialchars($error); ?></h3>
                <a href="ludomatch.php" class="back-button">Back to Matches</a>
            </div>
        <?php elseif (!empty($success)): ?>
            <div class="success-message">
                <h3><?php echo htmlspecialchars($success); ?></h3>
                <a href="ludomatch.php" class="back-button">Back to Matches</a>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // JavaScript to handle the wallet-icon click event
        document.getElementById('walletIcon').addEventListener('click', function () {
            window.location.href = 'mywallet.php';
        });
        
        // Handle confirm button in modal
        document.getElementById('confirmJoin').addEventListener('click', function() {
            document.querySelector('form').submit();
        });
    </script>
</body>
</html>