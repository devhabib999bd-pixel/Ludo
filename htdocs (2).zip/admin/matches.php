<?php
// Start session and check admin authentication
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit();
}

// Database connection
require_once 'config.php';

// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_match'])) {
        $match_title = $_POST['match_title'];
        $match_description = $_POST['match_description'];
        $match_type = $_POST['match_type'];
        $entry_fee = $_POST['entry_fee'];
        $total_players = $_POST['total_players'];
        $total_price = $_POST['total_price'];
        $version = $_POST['version'];
        $board_type = $_POST['board_type'];
        $room_id = $_POST['room_id'];
        $created_by = $_POST['created_by'];
        $match_time = $_POST['match_time'];
        
        $stmt = $conn->prepare("INSERT INTO matches (match_title, match_description, match_type, entry_fee, total_players, total_price, version, board_type, room_id, created_by, match_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssdississs", $match_title, $match_description, $match_type, $entry_fee, $total_players, $total_price, $version, $board_type, $room_id, $created_by, $match_time);
        
        if ($stmt->execute()) {
            $_SESSION['message'] = "Match created successfully!";
        } else {
            $_SESSION['message'] = "Error creating match: " . $conn->error;
        }
        
        header("Location: matches.php");
        exit();
    }
    if (isset($_POST['update_match'])) {
        // Update existing match
        $match_id = $_POST['match_id'];
        $match_title = $_POST['match_title'];
        $match_description = $_POST['match_description'];
        $match_type = $_POST['match_type'];
        $entry_fee = $_POST['entry_fee'];
        $total_players = $_POST['total_players'];
        $total_price = $_POST['total_price'];
        $version = $_POST['version'];
        $board_type = $_POST['board_type'];
        $room_id = $_POST['room_id'];
        $match_time = $_POST['match_time'];
        $status = $_POST['status'];
        $winner_uid = $_POST['winner_uid'] ?? null;
        
        // Get current status from database
        $stmt = $conn->prepare("SELECT status, total_price FROM matches WHERE id = ?");
        $stmt->bind_param("i", $match_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $current_match = $result->fetch_assoc();
        $current_status = $current_match['status'];
        
        // Begin transaction
        $conn->begin_transaction();
        
        try {
            // Update match details
            $stmt = $conn->prepare("UPDATE matches SET match_title=?, match_description=?, match_type=?, entry_fee=?, total_players=?, total_price=?, version=?, board_type=?, room_id=?, match_time=?, status=? WHERE id=?");
            $stmt->bind_param("sssdississsi", $match_title, $match_description, $match_type, $entry_fee, $total_players, $total_price, $version, $board_type, $room_id, $match_time, $status, $match_id);
            $stmt->execute();
            
            // If status changed to completed and winner is selected
            if ($status === 'completed' && $current_status !== 'completed' && $winner_uid) {
                // Add prize money to winner's WINNING balance
                $stmt = $conn->prepare("UPDATE users SET winning_balance = winning_balance + ?, total_winnings = total_winnings + ? WHERE user_uid = ?");
                $stmt->bind_param("dds", $total_price, $total_price, $winner_uid);
                $stmt->execute();
                
                // Record the transaction (to_balance is 'winning')
                $stmt = $conn->prepare("INSERT INTO transactions (user_uid, type, amount, from_balance, to_balance, reference_id) VALUES (?, 'reward', ?, 'winning', 'winning', ?)");
                $reference_id = 'MATCH_WIN_' . $match_id;
                $stmt->bind_param("sds", $winner_uid, $total_price, $reference_id);
                $stmt->execute();
                
                // Update top players table
                $stmt = $conn->prepare("INSERT INTO top_players (user_uid, total_wins, total_earnings) VALUES (?, 1, ?) ON DUPLICATE KEY UPDATE total_wins = total_wins + 1, total_earnings = total_earnings + ?");
                $stmt->bind_param("sdd", $winner_uid, $total_price, $total_price);
                $stmt->execute();
            }
            
            $conn->commit();
            $_SESSION['message'] = "Match updated successfully!";
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['message'] = "Error updating match: " . $e->getMessage();
        }
        
        header("Location: matches.php");
        exit();
    }
    
    if (isset($_POST['delete_match'])) {
        // Delete match - Fixed deletion logic
        $match_id = $_POST['match_id'];
        
        // First check if match is completed
        $stmt = $conn->prepare("SELECT status FROM matches WHERE id = ?");
        $stmt->bind_param("i", $match_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $match = $result->fetch_assoc();
        
        if ($match['status'] === 'completed') {
            $_SESSION['message'] = "Cannot delete completed matches!";
            header("Location: matches.php");
            exit();
        }
        
        // Begin transaction
        $conn->begin_transaction();
        
        try {
            // First delete participants
            $stmt = $conn->prepare("DELETE FROM match_participants WHERE match_id = ?");
            $stmt->bind_param("i", $match_id);
            $stmt->execute();
            
            // Then delete the match
            $stmt = $conn->prepare("DELETE FROM matches WHERE id = ?");
            $stmt->bind_param("i", $match_id);
            $stmt->execute();
            
            $conn->commit();
            $_SESSION['message'] = "Match and its participants deleted successfully!";
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['message'] = "Error deleting match: " . $e->getMessage();
        }
        
        header("Location: matches.php");
        exit();
    }
}

// Handle view and edit actions
$view_match = null;
$edit_match = null;

if (isset($_GET['action']) && isset($_GET['id'])) {
    $match_id = intval($_GET['id']);
    
    if ($_GET['action'] === 'view') {
        // Get match details for viewing
        $stmt = $conn->prepare("
            SELECT m.*, u.fast_name, u.last_name 
            FROM matches m 
            LEFT JOIN users u ON m.created_by = u.user_uid 
            WHERE m.id = ?
        ");
        $stmt->bind_param("i", $match_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $view_match = $result->fetch_assoc();
        
        if ($view_match) {
            // Get participants
            $stmt = $conn->prepare("
                SELECT mp.*, u.fast_name, u.last_name 
                FROM match_participants mp 
                JOIN users u ON mp.user_uid = u.user_uid 
                WHERE mp.match_id = ?
            ");
            $stmt->bind_param("i", $match_id);
            $stmt->execute();
            $view_match['participants'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            
            // Get count of players
            $stmt = $conn->prepare("SELECT COUNT(*) as player_count FROM match_participants WHERE match_id = ?");
            $stmt->bind_param("i", $match_id);
            $stmt->execute();
            $count_result = $stmt->get_result();
            $count = $count_result->fetch_assoc();
            $view_match['joined_players'] = $count['player_count'];
        }
    } 
    elseif ($_GET['action'] === 'edit') {
        // Get match details for editing
        $stmt = $conn->prepare("SELECT * FROM matches WHERE id = ?");
        $stmt->bind_param("i", $match_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $edit_match = $result->fetch_assoc();
        
        if ($edit_match) {
            // Get participants for winner selection
            $stmt = $conn->prepare("
                SELECT mp.user_uid, u.fast_name, u.last_name, mp.game_name 
                FROM match_participants mp 
                JOIN users u ON mp.user_uid = u.user_uid 
                WHERE mp.match_id = ?
            ");
            $stmt->bind_param("i", $match_id);
            $stmt->execute();
            $edit_match['participants'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            
            // Get count of players
            $stmt = $conn->prepare("SELECT COUNT(*) as player_count FROM match_participants WHERE match_id = ?");
            $stmt->bind_param("i", $match_id);
            $stmt->execute();
            $count_result = $stmt->get_result();
            $count = $count_result->fetch_assoc();
            $edit_match['joined_players'] = $count['player_count'];
        }
    }
}

// Get filter parameters
$match_type_filter = $_GET['match_type'] ?? '';
$status_filter = $_GET['status'] ?? '';
$from_date = $_GET['from_date'] ?? '';
$to_date = $_GET['to_date'] ?? '';

// Build query with filters
$query = "SELECT m.*, u.fast_name, u.last_name FROM matches m LEFT JOIN users u ON m.created_by = u.user_uid WHERE 1=1";
$params = [];
$types = '';

if (!empty($match_type_filter)) {
    $query .= " AND m.match_type = ?";
    $params[] = $match_type_filter;
    $types .= 's';
}

if (!empty($status_filter)) {
    $query .= " AND m.status = ?";
    $params[] = $status_filter;
    $types .= 's';
}

if (!empty($from_date)) {
    $query .= " AND m.match_time >= ?";
    $params[] = $from_date . ' 00:00:00';
    $types .= 's';
}

if (!empty($to_date)) {
    $query .= " AND m.match_time <= ?";
    $params[] = $to_date . ' 23:59:59';
    $types .= 's';
}

$query .= " ORDER BY m.match_time DESC";

// Prepare and execute query
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$matches = $result->fetch_all(MYSQLI_ASSOC);

// Get count of players for each match
foreach ($matches as &$match) {
    $stmt = $conn->prepare("SELECT COUNT(*) as player_count FROM match_participants WHERE match_id = ?");
    $stmt->bind_param("i", $match['id']);
    $stmt->execute();
    $count_result = $stmt->get_result();
    $count = $count_result->fetch_assoc();
    $match['joined_players'] = $count['player_count'];
}
unset($match); // Break the reference
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($site_name); ?> - Matches Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
       :root {
            --primary: #6C5CE7;
            --secondary: #A29BFE;
            --dark: #2D3436;
            --light: #F5F6FA;
            --success: #00B894;
            --danger: #D63031;
            --warning: #FDCB6E;
            --info: #0984E3;
            --gold: #FFD700;
            --purple-dark: #07031E;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: #0F0F1A;
            color: #F5F6FA;
            overflow-x: hidden;
        }

        .admin-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--purple-dark) 0%, #1A1A2E 100%);
            padding: 20px 0;
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
            position: fixed;
            height: 100vh;
            z-index: 100;
            transition: all 0.3s;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .sidebar-header h3 {
            color: var(--gold);
            font-weight: 600;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-category {
            color: var(--secondary);
            text-transform: uppercase;
            font-size: 12px;
            font-weight: 600;
            padding: 15px 20px 10px;
            letter-spacing: 1px;
        }

        .menu-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            margin: 5px 0;
            color: #F5F6FA;
            text-decoration: none;
            border-left: 3px solid transparent;
            transition: all 0.3s;
        }

        .menu-item:hover, .menu-item.active {
            background: rgba(108, 92, 231, 0.1);
            border-left: 3px solid var(--primary);
            color: var(--gold);
        }

        .menu-item i {
            margin-right: 12px;
            font-size: 18px;
            width: 24px;
            text-align: center;
        }

        .menu-item .badge {
            margin-left: auto;
            background: var(--danger);
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 12px;
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 20px;
            transition: all 0.3s;
        }

        /* Top Navigation */
        .top-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 25px;
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .search-bar {
            position: relative;
            width: 300px;
        }

        .search-bar input {
            width: 100%;
            padding: 10px 15px 10px 40px;
            border: none;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 30px;
            color: white;
            outline: none;
        }

        .search-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--secondary);
        }

        .user-profile {
            display: flex;
            align-items: center;
        }

        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
            border: 2px solid var(--gold);
        }

        .notification-bell {
            position: relative;
            margin-right: 20px;
            font-size: 20px;
            color: var(--secondary);
            cursor: pointer;
        }

        .notification-bell .badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Dashboard Cards */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .card-title {
            font-size: 16px;
            color: var(--secondary);
        }

        .card-value {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 10px;
            color: var(--gold);
        }

        .card-footer {
            display: flex;
            align-items: center;
            font-size: 14px;
        }

        .card-footer i {
            margin-right: 5px;
        }

        .positive {
            color: var(--success);
        }

        .negative {
            color: var(--danger);
        }

        /* Recent Activity */
        .activity-section {
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--gold);
        }

        .view-all {
            color: var(--secondary);
            text-decoration: none;
            font-size: 14px;
        }

        .activity-list {
            list-style: none;
        }

        .activity-item {
            display: flex;
            padding: 15px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(108, 92, 231, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            color: var(--primary);
            font-size: 18px;
        }

        .activity-content {
            flex: 1;
        }

        .activity-user {
            font-weight: 600;
            margin-bottom: 5px;
        }

        .activity-details {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.7);
        }

        .activity-time {
            font-size: 12px;
            color: var(--secondary);
        }

        /* Data Tables */
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .data-table th {
            background: rgba(108, 92, 231, 0.2);
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            color: var(--gold);
        }

        .data-table td {
            padding: 12px 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .data-table tr:hover {
            background: rgba(108, 92, 231, 0.05);
        }

        .status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status.active {
            background: rgba(0, 184, 148, 0.2);
            color: var(--success);
        }

        .status.pending {
            background: rgba(253, 203, 110, 0.2);
            color: var(--warning);
        }

        .status.banned {
            background: rgba(214, 48, 49, 0.2);
            color: var(--danger);
        }

        .status.completed {
            background: rgba(108, 92, 231, 0.2);
            color: var(--primary);
        }

        .status.waiting {
            background: rgba(9, 132, 227, 0.2);
            color: var(--info);
        }

        .action-btn {
            padding: 5px 10px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            margin-right: 5px;
            font-size: 12px;
            transition: all 0.3s;
        }

        .edit-btn {
            background: rgba(9, 132, 227, 0.2);
            color: var(--info);
        }

        .delete-btn {
            background: rgba(214, 48, 49, 0.2);
            color: var(--danger);
        }

        .view-btn {
            background: rgba(0, 184, 148, 0.2);
            color: var(--success);
        }

        .approve-btn {
            background: rgba(0, 184, 148, 0.2);
            color: var(--success);
        }

        .reject-btn {
            background: rgba(214, 48, 49, 0.2);
            color: var(--danger);
        }

        /* Form Styles */
        .form-card {
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: var(--secondary);
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: white;
            font-size: 14px;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(108, 92, 231, 0.1);
        }

        .form-select {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: white;
            font-size: 14px;
            transition: all 0.3s;
        }

        .btn {
            padding: 12px 25px;
            border-radius: 8px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: #5a4bc2;
        }

        .btn-secondary {
            background: var(--secondary);
            color: white;
        }

        .btn-secondary:hover {
            background: #8a7bf3;
        }

        /* Modal Styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
        }

        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        .modal-content {
            background: rgba(13, 13, 26, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            transform: translateY(20px);
            transition: all 0.3s;
        }

        .modal-overlay.active .modal-content {
            transform: translateY(0);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .modal-title {
            color: var(--gold);
            font-size: 20px;
            font-weight: 600;
        }

        .modal-close {
            background: none;
            border: none;
            color: var(--secondary);
            font-size: 24px;
            cursor: pointer;
        }

        .modal-body {
            margin-bottom: 20px;
        }

        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            .sidebar-header h3, .menu-category, .menu-item span {
                display: none;
            }
            .menu-item {
                justify-content: center;
                padding: 15px 0;
            }
            .menu-item i {
                margin-right: 0;
                font-size: 20px;
            }
            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .dashboard-cards {
                grid-template-columns: 1fr;
            }
            .top-nav {
                flex-direction: column;
                align-items: flex-start;
            }
            .search-bar {
                width: 100%;
                margin-bottom: 15px;
            }
        }
        
        /* Message styles */
        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            background-color: rgba(0, 184, 148, 0.2);
            color: var(--success);
            border-left: 4px solid var(--success);
        }
        
        .message.error {
            background-color: rgba(214, 48, 49, 0.2);
            color: var(--danger);
            border-left: 4px solid var(--danger);
        }
    </style>
</head>
<body>
    <div class="admin-container">
       <div class="sidebar">
            <div class="sidebar-header">
                <img src="admin.png" alt="Admin Logo">
                <h3>LUDO BD Admin</h3>
            </div>
            
            <div class="sidebar-menu">
                <div class="menu-category">Dashboard</div>
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Overview</span>
                </a>
                
                <div class="menu-category">Management</div>
                <a href="users.php" class="menu-item">
                    <i class="fas fa-users"></i>
                    <span>Users</span>
                </a>
                <a href="matches.php" class="menu-item active">
                    <i class="fas fa-gamepad"></i>
                    <span>Matches</span>
                </a>
                <a href="transactions.php" class="menu-item">
                    <i class="fas fa-wallet"></i>
                    <span>Transactions</span>
                </a>
                <a href="referrals.php" class="menu-item">
                    <i class="fas fa-gift"></i>
                    <span>Referrals</span>
                </a>
                <a href="deposits.php" class="menu-item">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Deposits</span>
                </a>
                <a href="withdrawals.php" class="menu-item">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Withdrawals</span>
                </a>
                
                <div class="menu-category">Content</div>
                <a href="notifications.php" class="menu-item">
                    <i class="fas fa-bullhorn"></i>
                    <span>Notifications</span>
                </a>
                
                <div class="menu-category">Settings</div>
                <a href="settings.php" class="menu-item">
                    <i class="fas fa-cog"></i>
                    <span>System Settings</span>
                </a>
                <a href="admins.php" class="menu-item">
                    <i class="fas fa-user-shield"></i>
                    <span>Admin Users</span>
                </a>
                <a href="wallets.php" class="menu-item">
                    <i class="fas fa-wallet"></i>
                    <span>Payment Wallets</span>
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navigation -->
            <div class="top-nav">
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search matches...">
                </div>
                
                <div class="user-profile">
                    <div class="notification-bell">
                        <i class="fas fa-bell"></i>
                        <span class="badge">3</span>
                    </div>
                    <img src="admin.png" alt="User Profile">
                    <span><?php echo $_SESSION['admin_username']; ?></span>
                </div>
            </div>

            <?php if (isset($_SESSION['message'])): ?>
                <div class="message">
                    <?php 
                    echo $_SESSION['message']; 
                    unset($_SESSION['message']);
                    ?>
                </div>
            <?php endif; ?>
            
            <!-- Matches Management Section -->
            <div class="activity-section">
                <div class="section-header">
                    <h3 class="section-title">Match Management</h3>
                    <a href="matches.php?action=create" class="btn btn-primary">Create New Match</a>
                </div>
                
                <!-- Filter Form -->
                <div class="form-card">
                    <form method="GET">
                        <div class="row" style="display: flex; flex-wrap: wrap; gap: 15px; margin-bottom: 20px;">
                            <div style="flex: 1; min-width: 200px;">
                                <div class="form-group">
                                    <label class="form-label">Match Type</label>
                                    <select class="form-select" name="match_type">
                                        <option value="">All Types</option>
                                        <option value="classic" <?php echo ($match_type_filter === 'classic') ? 'selected' : ''; ?>>Classic</option>
                                        <option value="tdm" <?php echo ($match_type_filter === 'tdm') ? 'selected' : ''; ?>>TDM</option>
                                        <option value="freefire" <?php echo ($match_type_filter === 'freefire') ? 'selected' : ''; ?>>Free Fire</option>
                                        <option value="custom" <?php echo ($match_type_filter === 'custom') ? 'selected' : ''; ?>>Custom</option>
                                    </select>
                                </div>
                            </div>
                            <div style="flex: 1; min-width: 200px;">
                                <div class="form-group">
                                    <label class="form-label">Status</label>
                                    <select class="form-select" name="status">
                                        <option value="">All Statuses</option>
                                        <option value="waiting" <?php echo ($status_filter === 'waiting') ? 'selected' : ''; ?>>Waiting</option>
                                        <option value="ongoing" <?php echo ($status_filter === 'ongoing') ? 'selected' : ''; ?>>Ongoing</option>
                                        <option value="completed" <?php echo ($status_filter === 'completed') ? 'selected' : ''; ?>>Completed</option>
                                    </select>
                                </div>
                            </div>
                            <div style="flex: 1; min-width: 200px;">
                                <div class="form-group">
                                    <label class="form-label">From Date</label>
                                    <input type="date" class="form-control" name="from_date" value="<?php echo $from_date; ?>">
                                </div>
                            </div>
                            <div style="flex: 1; min-width: 200px;">
                                <div class="form-group">
                                    <label class="form-label">To Date</label>
                                    <input type="date" class="form-control" name="to_date" value="<?php echo $to_date; ?>">
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Filter Matches</button>
                        <a href="matches.php" class="btn btn-secondary">Reset</a>
                    </form>
                </div>
                
                <!-- Matches Table -->
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Type</th>
                            <th>Entry Fee</th>
                            <th>Players</th>
                            <th>Total Prize</th>
                            <th>Created By</th>
                            <th>Match Time</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($matches as $match): ?>
                        <tr>
                            <td>#<?php echo $match['id']; ?></td>
                            <td><?php echo $match['match_title']; ?></td>
                            <td><?php echo ucfirst($match['match_type']); ?></td>
                            <td>৳<?php echo number_format($match['entry_fee'], 2); ?></td>
                            <td><?php echo $match['joined_players']; ?>/<?php echo $match['total_players']; ?></td>
                            <td>৳<?php echo number_format($match['total_price'], 2); ?></td>
                            <td>
                                <?php 
                                if ($match['fast_name']) {
                                    echo $match['fast_name'] . ' ' . $match['last_name'] . ' (' . $match['created_by'] . ')';
                                } else {
                                    echo $match['created_by'];
                                }
                                ?>
                            </td>
                            <td><?php echo date('Y-m-d H:i', strtotime($match['match_time'])); ?></td>
                            <td>
                                <?php 
                                $status_class = '';
                                switch ($match['status']) {
                                    case 'waiting': $status_class = 'waiting'; break;
                                    case 'ongoing': $status_class = 'active'; break;
                                    case 'completed': $status_class = 'completed'; break;
                                }
                                ?>
                                <span class="status <?php echo $status_class; ?>"><?php echo ucfirst($match['status']); ?></span>
                            </td>
                            <td>
                                <a href="matches.php?action=view&id=<?php echo $match['id']; ?>" class="action-btn view-btn">View</a>
                                <a href="matches.php?action=edit&id=<?php echo $match['id']; ?>" class="action-btn edit-btn">Edit</a>
                                <a href="matches.php?action=delete&id=<?php echo $match['id']; ?>" class="action-btn delete-btn" onclick="return confirm('Are you sure you want to delete this match?')">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($matches)): ?>
                        <tr>
                            <td colspan="10" style="text-align: center;">No matches found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add Match Modal -->
    <?php if (isset($_GET['action']) && $_GET['action'] === 'create'): ?>
    <div class="modal-overlay active" id="addMatchModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Create New Match</h3>
                <a href="matches.php" class="modal-close">&times;</a>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label">Match Title</label>
                        <input type="text" class="form-control" name="match_title" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Match Description</label>
                        <textarea class="form-control" name="match_description" required></textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Match Type</label>
                        <select class="form-control" name="match_type" required>
                            <option value="">Select Type</option>
                            <option value="classic">Classic</option>
                            <option value="tdm">TDM</option>
                            <option value="freefire">Free Fire</option>
                            <option value="custom">Custom</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Entry Fee (৳)</label>
                        <input type="number" class="form-control" name="entry_fee" step="0.01" min="0" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Total Players</label>
                        <input type="number" class="form-control" name="total_players" min="2" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Total Prize (৳)</label>
                        <input type="number" class="form-control" name="total_price" step="0.01" min="0" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Version</label>
                        <input type="text" class="form-control" name="version" value="Mobile" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Board Type</label>
                        <input type="text" class="form-control" name="board_type" value="Ludo King" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Room ID</label>
                        <input type="text" class="form-control" name="room_id">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Match Time</label>
                        <input type="datetime-local" class="form-control" name="match_time" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Created By (User UID)</label>
                        <input type="text" class="form-control" name="created_by" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="matches.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary" name="create_match">Create Match</button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <!-- Edit Match Modal -->
    <?php if (isset($edit_match)): ?>
    <div class="modal-overlay active" id="editMatchModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Edit Match Details</h3>
                <a href="matches.php" class="modal-close">&times;</a>
            </div>
            <form method="POST">
                <input type="hidden" name="match_id" value="<?php echo $edit_match['id']; ?>">
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label">Match Title</label>
                        <input type="text" class="form-control" name="match_title" value="<?php echo $edit_match['match_title']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Match Description</label>
                        <textarea class="form-control" name="match_description" required><?php echo $edit_match['match_description']; ?></textarea>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Match Type</label>
                        <select class="form-control" name="match_type" required>
                            <option value="">Select Type</option>
                            <option value="classic" <?php echo ($edit_match['match_type'] === 'classic') ? 'selected' : ''; ?>>Classic</option>
                            <option value="tdm" <?php echo ($edit_match['match_type'] === 'tdm') ? 'selected' : ''; ?>>TDM</option>
                            <option value="freefire" <?php echo ($edit_match['match_type'] === 'freefire') ? 'selected' : ''; ?>>Free Fire</option>
                            <option value="custom" <?php echo ($edit_match['match_type'] === 'custom') ? 'selected' : ''; ?>>Custom</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Entry Fee (৳)</label>
                        <input type="number" class="form-control" name="entry_fee" value="<?php echo $edit_match['entry_fee']; ?>" step="0.01" min="0" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Total Players</label>
                        <input type="number" class="form-control" name="total_players" value="<?php echo $edit_match['total_players']; ?>" min="2" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Total Prize (৳)</label>
                        <input type="number" class="form-control" name="total_price" value="<?php echo $edit_match['total_price']; ?>" step="0.01" min="0" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Version</label>
                        <input type="text" class="form-control" name="version" value="<?php echo $edit_match['version']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Board Type</label>
                        <input type="text" class="form-control" name="board_type" value="<?php echo $edit_match['board_type']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Room ID</label>
                        <input type="text" class="form-control" name="room_id" value="<?php echo $edit_match['room_id']; ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Match Time</label>
                        <?php 
                        $match_time = new DateTime($edit_match['match_time']);
                        $formatted_match_time = $match_time->format('Y-m-d\TH:i');
                        ?>
                        <input type="datetime-local" class="form-control" name="match_time" value="<?php echo $formatted_match_time; ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <select class="form-control" name="status" required>
                            <option value="waiting" <?php echo ($edit_match['status'] === 'waiting') ? 'selected' : ''; ?>>Waiting</option>
                            <option value="ongoing" <?php echo ($edit_match['status'] === 'ongoing') ? 'selected' : ''; ?>>Ongoing</option>
                            <option value="completed" <?php echo ($edit_match['status'] === 'completed') ? 'selected' : ''; ?>>Completed</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Winner (if completed)</label>
                        <select class="form-control" name="winner_uid" <?php echo ($edit_match['status'] !== 'completed') ? 'disabled' : ''; ?>>
                            <option value="">Select Winner</option>
                            <?php foreach ($edit_match['participants'] as $participant): ?>
                            <option value="<?php echo $participant['user_uid']; ?>">
                                <?php echo $participant['fast_name'] . ' ' . $participant['last_name'] . ' (' . $participant['user_uid'] . ')'; ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="matches.php" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary" name="update_match">Save Changes</button>
                    <button type="submit" class="btn btn-danger" name="delete_match">Delete Match</button>
                </div>
            </form>
            <script>
                // Enable winner selection when status is set to completed
                document.querySelector('select[name="status"]').addEventListener('change', function() {
                    const winnerSelect = document.querySelector('select[name="winner_uid"]');
                    if (this.value === 'completed') {
                        winnerSelect.disabled = false;
                    } else {
                        winnerSelect.disabled = true;
                        winnerSelect.value = '';
                    }
                });
            </script>
        </div>
    </div>
    <?php endif; ?>

    <!-- View Match Modal -->
    <?php if (isset($view_match)): ?>
    <div class="modal-overlay active" id="viewMatchModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Match Details</h3>
                <a href="matches.php" class="modal-close">&times;</a>
            </div>
            <div class="modal-body">
                <div class="match-info" style="margin-bottom: 20px;">
                    <h4 style="color: var(--gold); margin-bottom: 15px;"><?php echo $view_match['match_title']; ?> - <?php echo ucfirst($view_match['match_type']); ?></h4>
                    <p style="margin-bottom: 15px;"><?php echo $view_match['match_description']; ?></p>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label class="form-label">Entry Fee</label>
                            <p>৳<?php echo number_format($view_match['entry_fee'], 2); ?></p>
                        </div>
                        <div>
                            <label class="form-label">Players</label>
                            <p><?php echo $view_match['joined_players']; ?>/<?php echo $view_match['total_players']; ?></p>
                        </div>
                        <div>
                            <label class="form-label">Total Prize</label>
                            <p>৳<?php echo number_format($view_match['total_price'], 2); ?></p>
                        </div>
                        <div>
                            <label class="form-label">Version</label>
                            <p><?php echo $view_match['version']; ?></p>
                        </div>
                        <div>
                            <label class="form-label">Board Type</label>
                            <p><?php echo $view_match['board_type']; ?></p>
                        </div>
                        <div>
                            <label class="form-label">Room ID</label>
                            <p><?php echo $view_match['room_id'] ? $view_match['room_id'] : 'Not set'; ?></p>
                        </div>
                        <div>
                            <label class="form-label">Created By</label>
                            <p>
                                <?php 
                                if ($view_match['fast_name']) {
                                    echo $view_match['fast_name'] . ' ' . $view_match['last_name'] . ' (' . $view_match['created_by'] . ')';
                                } else {
                                    echo $view_match['created_by'];
                                }
                                ?>
                            </p>
                        </div>
                        <div>
                            <label class="form-label">Match Time</label>
                            <p><?php echo date('Y-m-d H:i', strtotime($view_match['match_time'])); ?></p>
                        </div>
                        <div>
                            <label class="form-label">Status</label>
                            <p>
                                <?php 
                                $status_class = '';
                                switch ($view_match['status']) {
                                    case 'waiting': $status_class = 'waiting'; break;
                                    case 'ongoing': $status_class = 'active'; break;
                                    case 'completed': $status_class = 'completed'; break;
                                }
                                ?>
                                <span class="status <?php echo $status_class; ?>"><?php echo ucfirst($view_match['status']); ?></span>
                            </p>
                        </div>
                        <div>
                            <label class="form-label">Created At</label>
                            <p><?php echo date('Y-m-d H:i', strtotime($view_match['created_at'])); ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="participants-section">
                    <h5 style="color: var(--secondary); margin-bottom: 10px;">Participants</h5>
                    <table class="data-table" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>User UID</th>
                                <th>Name</th>
                                <th>Game Name</th>
                                <th>Joined At</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($view_match['participants'])): ?>
                                <?php foreach ($view_match['participants'] as $participant): ?>
                                <tr>
                                    <td><?php echo $participant['user_uid']; ?></td>
                                    <td><?php echo $participant['fast_name'] . ' ' . $participant['last_name']; ?></td>
                                    <td><?php echo $participant['game_name'] ? $participant['game_name'] : 'N/A'; ?></td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($participant['joined_at'])); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" style="text-align: center;">No participants yet</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <a href="matches.php" class="btn btn-secondary">Close</a>
                <a href="matches.php?action=edit&id=<?php echo $view_match['id']; ?>" class="btn btn-primary">Edit Match</a>
            </div>
        </div>
    </div>
    <?php endif; ?>
</body>
</html>