<?php
session_start();
require_once 'config.php';

// Check if user is logged in as admin
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}
// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}

// Function to safely execute queries
function safeQuery($conn, $sql, $params = []) {
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }
    
    if (!empty($params)) {
        $types = str_repeat('s', count($params));
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    if (!$result) {
        die("Query failed: " . $stmt->error);
    }
    
    return $result;
}

// Get user UID from query parameter
$user_uid = $_GET['uid'] ?? '';
if (empty($user_uid)) {
    header("Location: users.php");
    exit;
}

// Fetch user data
$user = safeQuery($conn, "SELECT * FROM users WHERE user_uid = ?", [$user_uid])->fetch_assoc();
if (!$user) {
    header("Location: users.php");
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fast_name = $_POST['fast_name'] ?? $user['fast_name'];
    $last_name = $_POST['last_name'] ?? $user['last_name'];
    $phone = $_POST['phone'] ?? $user['phone'];
    $winning_balance = $_POST['winning_balance'] ?? $user['winning_balance'];
    $gaming_balance = $_POST['gaming_balance'] ?? $user['gaming_balance'];
    $is_verified = isset($_POST['is_verified']) ? 1 : 0;
    $is_banned = isset($_POST['is_banned']) ? 1 : 0;
    $ban_reason = $_POST['ban_reason'] ?? $user['ban_reason'];
    $referral_code = $_POST['referral_code'] ?? $user['referral_code'];
    $referred_by = $_POST['referred_by'] ?? $user['referred_by'];

    // Update user
    $sql = "UPDATE users SET 
            fast_name = ?, 
            last_name = ?, 
            phone = ?, 
            winning_balance = ?, 
            gaming_balance = ?, 
            is_verified = ?, 
            is_banned = ?, 
            ban_reason = ?, 
            referral_code = ?, 
            referred_by = ? 
            WHERE user_uid = ?";
    
    $params = [
        $fast_name, 
        $last_name, 
        $phone, 
        $winning_balance, 
        $gaming_balance, 
        $is_verified, 
        $is_banned, 
        $ban_reason, 
        $referral_code, 
        $referred_by, 
        $user_uid
    ];
    
    safeQuery($conn, $sql, $params);
    
    // Redirect back to users page with success message
    $_SESSION['success_message'] = "User updated successfully!";
    header("Location: users.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($site_name); ?> - Edit User</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #6C5CE7;
            --secondary: #A29BFE;
            --dark: #2D3436;
            --light: #F5F6FA;
            --success: #00B894;
            --danger: #D63031;
            --warning: #FDCB6E;
            --info: #0984E3;
            --gold: #FFD700;
            --purple-dark: #07031E;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: #0F0F1A;
            color: #F5F6FA;
            overflow-x: hidden;
        }

        .admin-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--purple-dark) 0%, #1A1A2E 100%);
            padding: 20px 0;
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
            position: fixed;
            height: 100vh;
            z-index: 100;
            transition: all 0.3s;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .sidebar-header h3 {
            color: var(--gold);
            font-weight: 600;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-category {
            color: var(--secondary);
            text-transform: uppercase;
            font-size: 12px;
            font-weight: 600;
            padding: 15px 20px 10px;
            letter-spacing: 1px;
        }

        .menu-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            margin: 5px 0;
            color: #F5F6FA;
            text-decoration: none;
            border-left: 3px solid transparent;
            transition: all 0.3s;
        }

        .menu-item:hover, .menu-item.active {
            background: rgba(108, 92, 231, 0.1);
            border-left: 3px solid var(--primary);
            color: var(--gold);
        }

        .menu-item i {
            margin-right: 12px;
            font-size: 18px;
            width: 24px;
            text-align: center;
        }

        .menu-item .badge {
            margin-left: auto;
            background: var(--danger);
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 12px;
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 20px;
            transition: all 0.3s;
        }

        /* Top Navigation */
        .top-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 25px;
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .search-bar {
            position: relative;
            width: 300px;
        }

        .search-bar input {
            width: 100%;
            padding: 10px 15px 10px 40px;
            border: none;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 30px;
            color: white;
            outline: none;
        }

        .search-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--secondary);
        }

        .user-profile {
            display: flex;
            align-items: center;
        }

        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
            border: 2px solid var(--gold);
        }

        .notification-bell {
            position: relative;
            margin-right: 20px;
            font-size: 20px;
            color: var(--secondary);
            cursor: pointer;
        }

        .notification-bell .badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Form Styles */
        .form-card {
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: var(--secondary);
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: white;
            font-size: 14px;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(108, 92, 231, 0.1);
        }

        .form-select {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: white;
            font-size: 14px;
            transition: all 0.3s;
        }

        .btn {
            padding: 12px 25px;
            border-radius: 8px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: #5a4bc2;
        }

        .btn-secondary {
            background: var(--secondary);
            color: white;
        }

        .btn-secondary:hover {
            background: #8a7bf3;
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover {
            background: #b82a2a;
        }

        .checkbox-container {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        .checkbox-container input[type="checkbox"] {
            margin-right: 10px;
            width: 18px;
            height: 18px;
        }

        .user-profile-view {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
        }

        .user-profile-view img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid var(--gold);
            margin-right: 20px;
        }

        .user-profile-view h3 {
            color: var(--gold);
            margin-bottom: 5px;
        }

        .user-profile-view p {
            color: var(--secondary);
        }

        .detail-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 20px;
        }

        .detail-item {
            margin-bottom: 15px;
        }

        .detail-item label {
            display: block;
            margin-bottom: 8px;
            color: var(--secondary);
            font-weight: 500;
        }

        .detail-item p {
            padding: 10px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 5px;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            .sidebar-header h3, .menu-category, .menu-item span {
                display: none;
            }
            .menu-item {
                justify-content: center;
                padding: 15px 0;
            }
            .menu-item i {
                margin-right: 0;
                font-size: 20px;
            }
            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .detail-grid {
                grid-template-columns: 1fr;
            }
            .top-nav {
                flex-direction: column;
                align-items: flex-start;
            }
            .search-bar {
                width: 100%;
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <img src="admin.png" alt="Admin Logo">
                <h3>LUDO BD Admin</h3>
            </div>
            
            <div class="sidebar-menu">
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Overview</span>
                </a>
                
                <div class="menu-category">Management</div>
                <a href="users.php" class="menu-item active">
                    <i class="fas fa-users"></i>
                    <span>Users</span>
                </a>
                <a href="matches.php" class="menu-item">
                    <i class="fas fa-gamepad"></i>
                    <span>Matches</span>
                </a>
                <a href="transactions.php" class="menu-item">
                    <i class="fas fa-wallet"></i>
                    <span>Transactions</span>
                </a>
                <a href="referrals.php" class="menu-item">
                    <i class="fas fa-gift"></i>
                    <span>Referrals</span>
                </a>
                <a href="deposits.php" class="menu-item">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Deposits</span>
                </a>
                <a href="withdrawals.php" class="menu-item">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Withdrawals</span>
                </a>
                
                <div class="menu-category">Content</div>
                <a href="notifications.php" class="menu-item">
                    <i class="fas fa-bullhorn"></i>
                    <span>Notifications</span>
                </a>
                
                <div class="menu-category">Settings</div>
                <a href="settings.php" class="menu-item">
                    <i class="fas fa-cog"></i>
                    <span>System Settings</span>
                </a>
                <a href="admins.php" class="menu-item">
                    <i class="fas fa-user-shield"></i>
                    <span>Admin Users</span>
                </a>
                <a href="wallets.php" class="menu-item">
                    <i class="fas fa-wallet"></i>
                    <span>Payment Wallets</span>
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navigation -->
            <div class="top-nav">
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search...">
                </div>
                
                <div class="user-profile">
                    <div class="notification-bell">
                        <i class="fas fa-bell"></i>
                        <span class="badge">3</span>
                    </div>
                    <img src="admin.png" alt="Admin Profile">
                    <span><?php echo $_SESSION['admin_username']; ?></span>
                    <a href="logout.php" style="margin-left:15px;color:var(--danger)">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                </div>
            </div>

            <!-- Edit User Section -->
            <div class="form-card">
                <div class="user-profile-view">
                    <img src="assets/images/default-user.png" alt="User Profile">
                    <div>
                        <h3>Edit User: <?php echo htmlspecialchars($user['fast_name'] . ' ' . $user['last_name']); ?></h3>
                        <p>UID: <?php echo htmlspecialchars($user['user_uid']); ?></p>
                    </div>
                </div>

                <form method="POST">
                    <div class="detail-grid">
                        <div class="form-group">
                            <label class="form-label">First Name</label>
                            <input type="text" name="fast_name" class="form-control" value="<?php echo htmlspecialchars($user['fast_name']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Last Name</label>
                            <input type="text" name="last_name" class="form-control" value="<?php echo htmlspecialchars($user['last_name']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Phone Number</label>
                            <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Winning Balance</label>
                            <input type="number" name="winning_balance" class="form-control" value="<?php echo htmlspecialchars($user['winning_balance']); ?>" step="0.01" min="0">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Gaming Balance</label>
                            <input type="number" name="gaming_balance" class="form-control" value="<?php echo htmlspecialchars($user['gaming_balance']); ?>" step="0.01" min="0">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Referral Code</label>
                            <input type="text" name="referral_code" class="form-control" value="<?php echo htmlspecialchars($user['referral_code']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Referred By (UID)</label>
                            <input type="text" name="referred_by" class="form-control" value="<?php echo htmlspecialchars($user['referred_by']); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Ban Reason</label>
                            <textarea name="ban_reason" class="form-control"><?php echo htmlspecialchars($user['ban_reason']); ?></textarea>
                        </div>
                    </div>
                    
                    <div class="checkbox-container">
                        <input type="checkbox" name="is_verified" id="is_verified" <?php echo $user['is_verified'] ? 'checked' : ''; ?>>
                        <label for="is_verified">Verified User</label>
                    </div>
                    
                    <div class="checkbox-container">
                        <input type="checkbox" name="is_banned" id="is_banned" <?php echo $user['is_banned'] ? 'checked' : ''; ?>>
                        <label for="is_banned">Banned User</label>
                    </div>
                    
                    <div class="form-actions" style="display: flex; justify-content: space-between; margin-top: 30px;">
                        <a href="users.php" class="btn btn-secondary">Back to Users</a>
                        <div>
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>