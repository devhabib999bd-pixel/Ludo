<?php
// Start session and check admin authentication
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}

// Database connection
require_once 'config.php';
// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}
// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $site_name = $_POST['site_name'];
    $site_logo = $_POST['site_logo'];
    $maintenance_mode = isset($_POST['maintenance']) ? 1 : 0;

    // First check if record exists
    $check = $conn->query("SELECT id FROM site_info WHERE id = 1");
    if ($check->num_rows > 0) {
        // Update existing record
        $stmt = $conn->prepare("UPDATE site_info SET site_name = ?, site_logo = ?, maintenance = ? WHERE id = 1");
    } else {
        // Insert new record
        $stmt = $conn->prepare("INSERT INTO site_info (site_name, site_logo, maintenance) VALUES (?, ?, ?)");
    }
    
    if ($stmt) {
        $stmt->bind_param("ssi", $site_name, $site_logo, $maintenance_mode);
        $stmt->execute();
        
        if ($stmt->affected_rows > 0) {
            $_SESSION['message'] = "Settings updated successfully!";
        } else {
            $_SESSION['message'] = "No changes were made.";
        }
        $stmt->close();
    } else {
        $_SESSION['error'] = "Database error: " . $conn->error;
    }
    
    header("Location: settings.php");
    exit();
}

// Get current settings
$settings = [];
$result = $conn->query("SELECT * FROM site_info WHERE id = 1");
if ($result && $result->num_rows > 0) {
    $settings = $result->fetch_assoc();
} else {
    // Initialize default settings if none exist
    $settings = [
        'site_name' => 'LUDO BD',
        'site_logo' => 'logo.png',
        'maintenance_mode' => 0
    ];
    // Don't insert here to avoid potential issues
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($site_name); ?> - System Settings</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
   :root {
            --primary: #6C5CE7;
            --secondary: #A29BFE;
            --dark: #2D3436;
            --light: #F5F6FA;
            --success: #00B894;
            --danger: #D63031;
            --warning: #FDCB6E;
            --info: #0984E3;
            --gold: #FFD700;
            --purple-dark: #07031E;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: #0F0F1A;
            color: #F5F6FA;
            overflow-x: hidden;
        }

        .admin-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--purple-dark) 0%, #1A1A2E 100%);
            padding: 20px 0;
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
            position: fixed;
            height: 100vh;
            z-index: 100;
            transition: all 0.3s;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .sidebar-header h3 {
            color: var(--gold);
            font-weight: 600;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-category {
            color: var(--secondary);
            text-transform: uppercase;
            font-size: 12px;
            font-weight: 600;
            padding: 15px 20px 10px;
            letter-spacing: 1px;
        }

        .menu-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            margin: 5px 0;
            color: #F5F6FA;
            text-decoration: none;
            border-left: 3px solid transparent;
            transition: all 0.3s;
        }

        .menu-item:hover, .menu-item.active {
            background: rgba(108, 92, 231, 0.1);
            border-left: 3px solid var(--primary);
            color: var(--gold);
        }

        .menu-item i {
            margin-right: 12px;
            font-size: 18px;
            width: 24px;
            text-align: center;
        }

        .menu-item .badge {
            margin-left: auto;
            background: var(--danger);
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 12px;
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 20px;
            transition: all 0.3s;
        }

        /* Top Navigation */
        .top-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 25px;
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .search-bar {
            position: relative;
            width: 300px;
        }

        .search-bar input {
            width: 100%;
            padding: 10px 15px 10px 40px;
            border: none;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 30px;
            color: white;
            outline: none;
        }

        .search-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--secondary);
        }

        .user-profile {
            display: flex;
            align-items: center;
        }

        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
            border: 2px solid var(--gold);
        }

        .notification-bell {
            position: relative;
            margin-right: 20px;
            font-size: 20px;
            color: var(--secondary);
            cursor: pointer;
        }

        .notification-bell .badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Dashboard Cards */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .card-title {
            font-size: 16px;
            color: var(--secondary);
        }

        .card-value {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 10px;
            color: var(--gold);
        }

        .card-footer {
            display: flex;
            align-items: center;
            font-size: 14px;
        }

        .card-footer i {
            margin-right: 5px;
        }

        .positive {
            color: var(--success);
        }

        .negative {
            color: var(--danger);
        }

        /* Recent Activity */
        .activity-section {
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--gold);
        }

        .view-all {
            color: var(--secondary);
            text-decoration: none;
            font-size: 14px;
        }

        .activity-list {
            list-style: none;
        }

        .activity-item {
            display: flex;
            padding: 15px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(108, 92, 231, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            color: var(--primary);
            font-size: 18px;
        }

        .activity-content {
            flex: 1;
        }

        .activity-user {
            font-weight: 600;
            margin-bottom: 5px;
        }

        .activity-details {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.7);
        }

        .activity-time {
            font-size: 12px;
            color: var(--secondary);
        }

        /* Data Tables */
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .data-table th {
            background: rgba(108, 92, 231, 0.2);
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            color: var(--gold);
        }

        .data-table td {
            padding: 12px 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .data-table tr:hover {
            background: rgba(108, 92, 231, 0.05);
        }

        .status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status.active {
            background: rgba(0, 184, 148, 0.2);
            color: var(--success);
        }

        .status.pending {
            background: rgba(253, 203, 110, 0.2);
            color: var(--warning);
        }

        .status.banned {
            background: rgba(214, 48, 49, 0.2);
            color: var(--danger);
        }

        .status.completed {
            background: rgba(108, 92, 231, 0.2);
            color: var(--primary);
        }

        .status.waiting {
            background: rgba(9, 132, 227, 0.2);
            color: var(--info);
        }

        .action-btn {
            padding: 5px 10px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            margin-right: 5px;
            font-size: 12px;
            transition: all 0.3s;
        }

        .edit-btn {
            background: rgba(9, 132, 227, 0.2);
            color: var(--info);
        }

        .delete-btn {
            background: rgba(214, 48, 49, 0.2);
            color: var(--danger);
        }

        .view-btn {
            background: rgba(0, 184, 148, 0.2);
            color: var(--success);
        }

        .approve-btn {
            background: rgba(0, 184, 148, 0.2);
            color: var(--success);
        }

        .reject-btn {
            background: rgba(214, 48, 49, 0.2);
            color: var(--danger);
        }

        /* Form Styles */
        .form-card {
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: var(--secondary);
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: white;
            font-size: 14px;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(108, 92, 231, 0.1);
        }

        .form-select {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: white;
            font-size: 14px;
            transition: all 0.3s;
        }

        .btn {
            padding: 12px 25px;
            border-radius: 8px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: #5a4bc2;
        }

        .btn-secondary {
            background: var(--secondary);
            color: white;
        }

        .btn-secondary:hover {
            background: #8a7bf3;
        }

        /* Modal Styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
        }

        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        .modal-content {
            background: rgba(13, 13, 26, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            transform: translateY(20px);
            transition: all 0.3s;
        }

        .modal-overlay.active .modal-content {
            transform: translateY(0);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .modal-title {
            color: var(--gold);
            font-size: 20px;
            font-weight: 600;
        }

        .modal-close {
            background: none;
            border: none;
            color: var(--secondary);
            font-size: 24px;
            cursor: pointer;
        }

        .modal-body {
            margin-bottom: 20px;
        }

        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            .sidebar-header h3, .menu-category, .menu-item span {
                display: none;
            }
            .menu-item {
                justify-content: center;
                padding: 15px 0;
            }
            .menu-item i {
                margin-right: 0;
                font-size: 20px;
            }
            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .dashboard-cards {
                grid-template-columns: 1fr;
            }
            .top-nav {
                flex-direction: column;
                align-items: flex-start;
            }
            .search-bar {
                width: 100%;
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
       <div class="sidebar">
            <div class="sidebar-header">
                <img src="admin.png" alt="Admin Logo">
                <h3>LUDO BD Admin</h3>
            </div>
            
            <div class="sidebar-menu">
                <div class="menu-category">Dashboard</div>
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Overview</span>
                </a>
                
                <div class="menu-category">Management</div>
                <a href="users.php" class="menu-item">
                    <i class="fas fa-users"></i>
                    <span>Users</span>
                </a>
                <a href="matches.php" class="menu-item">
                    <i class="fas fa-gamepad"></i>
                    <span>Matches</span>
                </a>
                <a href="transactions.php" class="menu-item">
                    <i class="fas fa-wallet"></i>
                    <span>Transactions</span>
                </a>
                <a href="referrals.php" class="menu-item">
                    <i class="fas fa-gift"></i>
                    <span>Referrals</span>
                </a>
                <a href="deposits.php" class="menu-item">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Deposits</span>
                </a>
                <a href="withdrawals.php" class="menu-item">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Withdrawals</span>
                </a>
                
                <div class="menu-category">Content</div>
                <a href="notifications.php" class="menu-item">
                    <i class="fas fa-bullhorn"></i>
                    <span>Notifications</span>
                </a>
                
                <div class="menu-category">Settings</div>
                <a href="settings.php" class="menu-item active">
                    <i class="fas fa-cog"></i>
                    <span>System Settings</span>
                </a>
                <a href="admins.php" class="menu-item">
                    <i class="fas fa-user-shield"></i>
                    <span>Admin Users</span>
                </a>
                <a href="wallets.php" class="menu-item">
                    <i class="fas fa-wallet"></i>
                    <span>Payment Wallets</span>
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navigation -->
            <div class="top-nav">
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search settings...">
                </div>
                
                <div class="user-profile">
                    <div class="notification-bell">
                        <i class="fas fa-bell"></i>
                        <span class="badge">3</span>
                    </div>
                    <img src="admin.png" alt="User Profile">
                    <span><?php echo $_SESSION['admin_username']; ?></span>
                </div>
            </div>
            
            <?php if (isset($_SESSION['message'])): ?>
                <div class="message">
                    <span><?php echo $_SESSION['message']; ?></span>
                    <button class="close-message">&times;</button>
                </div>
                <?php unset($_SESSION['message']); ?>
            <?php endif; ?>
            
            <!-- System Settings Section -->
            <div class="activity-section">
                <div class="section-header">
                    <h3 class="section-title">System Settings</h3>
                </div>
                
                <!-- Settings Form -->
                <div class="form-card">
                    <form method="POST" action="settings.php">
                        <div class="form-group">
                            <label class="form-label">Site Name</label>
                            <input type="text" name="site_name" class="form-control" value="<?php echo htmlspecialchars($settings['site_name']); ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Site Logo URL</label>
                            <input type="text" name="site_logo" class="form-control" value="<?php echo htmlspecialchars($settings['site_logo']); ?>">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Site Maintenance Mode</label>
                            <select name="maintenance_mode" class="form-select">
                                <option value="0" <?php echo $settings['maintenance_mode'] == 0 ? 'selected' : ''; ?>>Disabled</option>
                                <option value="1" <?php echo $settings['maintenance_mode'] == 1 ? 'selected' : ''; ?>>Enabled</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Save Settings</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Close message functionality
        const closeMessageBtn = document.querySelector('.close-message');
        if (closeMessageBtn) {
            closeMessageBtn.addEventListener('click', () => {
                document.querySelector('.message').style.display = 'none';
            });
        }
    </script>
</body>
</html>