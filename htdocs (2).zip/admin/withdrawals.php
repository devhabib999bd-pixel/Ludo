<?php
session_start();
require_once 'config.php'; // Database connection

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit;
}

// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}
// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['approve_withdrawal'])) {
        $withdrawal_id = $_POST['withdrawal_id'];
        $transaction_id = $_POST['transaction_id'];
        $admin_notes = $_POST['admin_notes'];
        
        // Update withdrawal status
        $stmt = $conn->prepare("UPDATE withdrawals SET status = 'approved', transaction_id = ?, admin_notes = ?, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("ssi", $transaction_id, $admin_notes, $withdrawal_id);
        $stmt->execute();
        
        // Add to transactions table
        $stmt = $conn->prepare("INSERT INTO transactions (user_uid, type, amount, from_balance, reference_id) 
                               SELECT user_uid, 'withdraw', amount, 'winning', ? FROM withdrawals WHERE id = ?");
        $stmt->bind_param("si", $transaction_id, $withdrawal_id);
        $stmt->execute();
        
        $_SESSION['message'] = "Withdrawal approved successfully!";
        
    } elseif (isset($_POST['reject_withdrawal'])) {
        $withdrawal_id = $_POST['withdrawal_id'];
        $admin_notes = $_POST['admin_notes'];
        
        // Update withdrawal status
        $stmt = $conn->prepare("UPDATE withdrawals SET status = 'rejected', admin_notes = ?, updated_at = NOW() WHERE id = ?");
        $stmt->bind_param("si", $admin_notes, $withdrawal_id);
        $stmt->execute();
        
        // Return amount to user's winning balance
        $stmt = $conn->prepare("UPDATE users u 
                               JOIN withdrawals w ON u.user_uid = w.user_uid 
                               SET u.winning_balance = u.winning_balance + w.amount 
                               WHERE w.id = ?");
        $stmt->bind_param("i", $withdrawal_id);
        $stmt->execute();
        
        $_SESSION['message'] = "Withdrawal rejected successfully!";
    }
    
    header("Location: withdrawals.php");
    exit;
}

// Get filter parameters
$user_uid = $_GET['user_uid'] ?? '';
$payment_method = $_GET['payment_method'] ?? '';
$status = $_GET['status'] ?? '';
$date = $_GET['date'] ?? '';

// Build query with filters
$query = "SELECT w.*, u.fast_name, u.last_name 
          FROM withdrawals w 
          JOIN users u ON w.user_uid = u.user_uid 
          WHERE 1=1";

$params = [];
$types = '';

if (!empty($user_uid)) {
    $query .= " AND w.user_uid LIKE ?";
    $params[] = "%$user_uid%";
    $types .= 's';
}

if (!empty($payment_method)) {
    $query .= " AND w.payment_method = ?";
    $params[] = $payment_method;
    $types .= 's';
}

if (!empty($status)) {
    $query .= " AND w.status = ?";
    $params[] = $status;
    $types .= 's';
}

if (!empty($date)) {
    $query .= " AND DATE(w.created_at) = ?";
    $params[] = $date;
    $types .= 's';
}

$query .= " ORDER BY w.created_at DESC";

// Prepare and execute query
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$withdrawals = $result->fetch_all(MYSQLI_ASSOC);

// Get counts for badges
$stmt = $conn->query("SELECT COUNT(*) as total FROM withdrawals WHERE status = 'pending'");
$pending_count = $stmt->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($site_name); ?> - Withdrawals Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
          :root {
            --primary: #6C5CE7;
            --secondary: #A29BFE;
            --dark: #2D3436;
            --light: #F5F6FA;
            --success: #00B894;
            --danger: #D63031;
            --warning: #FDCB6E;
            --info: #0984E3;
            --gold: #FFD700;
            --purple-dark: #07031E;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: #0F0F1A;
            color: #F5F6FA;
            overflow-x: hidden;
        }

        .admin-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--purple-dark) 0%, #1A1A2E 100%);
            padding: 20px 0;
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
            position: fixed;
            height: 100vh;
            z-index: 100;
            transition: all 0.3s;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .sidebar-header h3 {
            color: var(--gold);
            font-weight: 600;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-category {
            color: var(--secondary);
            text-transform: uppercase;
            font-size: 12px;
            font-weight: 600;
            padding: 15px 20px 10px;
            letter-spacing: 1px;
        }

        .menu-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            margin: 5px 0;
            color: #F5F6FA;
            text-decoration: none;
            border-left: 3px solid transparent;
            transition: all 0.3s;
        }

        .menu-item:hover, .menu-item.active {
            background: rgba(108, 92, 231, 0.1);
            border-left: 3px solid var(--primary);
            color: var(--gold);
        }

        .menu-item i {
            margin-right: 12px;
            font-size: 18px;
            width: 24px;
            text-align: center;
        }

        .menu-item .badge {
            margin-left: auto;
            background: var(--danger);
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 12px;
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 20px;
            transition: all 0.3s;
        }

        /* Top Navigation */
        .top-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 25px;
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .search-bar {
            position: relative;
            width: 300px;
        }

        .search-bar input {
            width: 100%;
            padding: 10px 15px 10px 40px;
            border: none;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 30px;
            color: white;
            outline: none;
        }

        .search-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--secondary);
        }

        .user-profile {
            display: flex;
            align-items: center;
        }

        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
            border: 2px solid var(--gold);
        }

        .notification-bell {
            position: relative;
            margin-right: 20px;
            font-size: 20px;
            color: var(--secondary);
            cursor: pointer;
        }

        .notification-bell .badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Dashboard Cards */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .card-title {
            font-size: 16px;
            color: var(--secondary);
        }

        .card-value {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 10px;
            color: var(--gold);
        }

        .card-footer {
            display: flex;
            align-items: center;
            font-size: 14px;
        }

        .card-footer i {
            margin-right: 5px;
        }

        .positive {
            color: var(--success);
        }

        .negative {
            color: var(--danger);
        }

        /* Recent Activity */
        .activity-section {
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--gold);
        }

        .view-all {
            color: var(--secondary);
            text-decoration: none;
            font-size: 14px;
        }

        .activity-list {
            list-style: none;
        }

        .activity-item {
            display: flex;
            padding: 15px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(108, 92, 231, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            color: var(--primary);
            font-size: 18px;
        }

        .activity-content {
            flex: 1;
        }

        .activity-user {
            font-weight: 600;
            margin-bottom: 5px;
        }

        .activity-details {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.7);
        }

        .activity-time {
            font-size: 12px;
            color: var(--secondary);
        }

        /* Data Tables */
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .data-table th {
            background: rgba(108, 92, 231, 0.2);
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            color: var(--gold);
        }

        .data-table td {
            padding: 12px 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .data-table tr:hover {
            background: rgba(108, 92, 231, 0.05);
        }

        .status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status.active {
            background: rgba(0, 184, 148, 0.2);
            color: var(--success);
        }

        .status.pending {
            background: rgba(253, 203, 110, 0.2);
            color: var(--warning);
        }

        .status.banned {
            background: rgba(214, 48, 49, 0.2);
            color: var(--danger);
        }

        .status.completed {
            background: rgba(108, 92, 231, 0.2);
            color: var(--primary);
        }

        .status.waiting {
            background: rgba(9, 132, 227, 0.2);
            color: var(--info);
        }

        .action-btn {
            padding: 5px 10px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            margin-right: 5px;
            font-size: 12px;
            transition: all 0.3s;
        }

        .edit-btn {
            background: rgba(9, 132, 227, 0.2);
            color: var(--info);
        }

        .delete-btn {
            background: rgba(214, 48, 49, 0.2);
            color: var(--danger);
        }

        .view-btn {
            background: rgba(0, 184, 148, 0.2);
            color: var(--success);
        }

        .approve-btn {
            background: rgba(0, 184, 148, 0.2);
            color: var(--success);
        }

        .reject-btn {
            background: rgba(214, 48, 49, 0.2);
            color: var(--danger);
        }

        /* Form Styles */
        .form-card {
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: var(--secondary);
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: white;
            font-size: 14px;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(108, 92, 231, 0.1);
        }

        .form-select {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: white;
            font-size: 14px;
            transition: all 0.3s;
        }

        .btn {
            padding: 12px 25px;
            border-radius: 8px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: #5a4bc2;
        }

        .btn-secondary {
            background: var(--secondary);
            color: white;
        }

        .btn-secondary:hover {
            background: #8a7bf3;
        }

        /* Modal Styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
        }

        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        .modal-content {
            background: rgba(13, 13, 26, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            transform: translateY(20px);
            transition: all 0.3s;
        }

        .modal-overlay.active .modal-content {
            transform: translateY(0);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .modal-title {
            color: var(--gold);
            font-size: 20px;
            font-weight: 600;
        }

        .modal-close {
            background: none;
            border: none;
            color: var(--secondary);
            font-size: 24px;
            cursor: pointer;
        }

        .modal-body {
            margin-bottom: 20px;
        }

        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            .sidebar-header h3, .menu-category, .menu-item span {
                display: none;
            }
            .menu-item {
                justify-content: center;
                padding: 15px 0;
            }
            .menu-item i {
                margin-right: 0;
                font-size: 20px;
            }
            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .dashboard-cards {
                grid-template-columns: 1fr;
            }
            .top-nav {
                flex-direction: column;
                align-items: flex-start;
            }
            .search-bar {
                width: 100%;
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <img src="admin.png" alt="Admin Logo">
                <h3>LUDO BD Admin</h3>
            </div>
            
            <div class="sidebar-menu">
                <div class="menu-category">Dashboard</div>
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Overview</span>
                </a>
                
                <div class="menu-category">Management</div>
                <a href="users.php" class="menu-item">
                    <i class="fas fa-users"></i>
                    <span>Users</span>
                </a>
                <a href="matches.php" class="menu-item">
                    <i class="fas fa-gamepad"></i>
                    <span>Matches</span>
                </a>
                <a href="transactions.php" class="menu-item">
                    <i class="fas fa-wallet"></i>
                    <span>Transactions</span>
                </a>
                <a href="referrals.php" class="menu-item">
                    <i class="fas fa-gift"></i>
                    <span>Referrals</span>
                </a>
                <a href="deposits.php" class="menu-item">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Deposits</span>
                </a>
                <a href="withdrawals.php" class="menu-item active">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Withdrawals</span>
                    <span class="badge"><?= $pending_count ?></span>
                </a>
                
                <div class="menu-category">Content</div>
                <a href="notifications.php" class="menu-item">
                    <i class="fas fa-bullhorn"></i>
                    <span>Notifications</span>
                </a>
                
                <div class="menu-category">Settings</div>
                <a href="settings.php" class="menu-item">
                    <i class="fas fa-cog"></i>
                    <span>System Settings</span>
                </a>
                <a href="admins.php" class="menu-item">
                    <i class="fas fa-user-shield"></i>
                    <span>Admin Users</span>
                </a>
                <a href="wallets.php" class="menu-item">
                    <i class="fas fa-wallet"></i>
                    <span>Payment Wallets</span>
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navigation -->
            <div class="top-nav">
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search users...">
                </div>
                
                <div class="user-profile">
                    <div class="notification-bell">
                        <i class="fas fa-bell"></i>
                        <span class="badge">3</span>
                    </div>
                    <img src="admin.png" alt="User Profile">
                    <span><?= $_SESSION['admin_username'] ?></span>
                </div>
            </div>
            
            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-success">
                    <?= $_SESSION['message'] ?>
                    <?php unset($_SESSION['message']); ?>
                </div>
            <?php endif; ?>
            
            <!-- Withdrawals Management Section -->
            <div class="activity-section">
                <div class="section-header">
                    <h3 class="section-title">Withdrawal Requests</h3>
                </div>
                
                <!-- Filter Form -->
                <div class="form-card">
                    <form method="GET" action="withdrawals.php">
                        <div class="row" style="display: flex; flex-wrap: wrap; gap: 15px; margin-bottom: 20px;">
                            <div style="flex: 1; min-width: 200px;">
                                <div class="form-group">
                                    <label class="form-label">User UID</label>
                                    <input type="text" class="form-control" name="user_uid" placeholder="Enter UID" value="<?= htmlspecialchars($user_uid) ?>">
                                </div>
                            </div>
                            <div style="flex: 1; min-width: 200px;">
                                <div class="form-group">
                                    <label class="form-label">Payment Method</label>
                                    <select class="form-select" name="payment_method">
                                        <option value="">All Methods</option>
                                        <option value="bkash" <?= $payment_method == 'bkash' ? 'selected' : '' ?>>Bkash</option>
                                        <option value="nagad" <?= $payment_method == 'nagad' ? 'selected' : '' ?>>Nagad</option>
                                        <option value="rocket" <?= $payment_method == 'rocket' ? 'selected' : '' ?>>Rocket</option>
                                    </select>
                                </div>
                            </div>
                            <div style="flex: 1; min-width: 200px;">
                                <div class="form-group">
                                    <label class="form-label">Status</label>
                                    <select class="form-select" name="status">
                                        <option value="">All Statuses</option>
                                        <option value="pending" <?= $status == 'pending' ? 'selected' : '' ?>>Pending</option>
                                        <option value="approved" <?= $status == 'approved' ? 'selected' : '' ?>>Approved</option>
                                        <option value="rejected" <?= $status == 'rejected' ? 'selected' : '' ?>>Rejected</option>
                                    </select>
                                </div>
                            </div>
                            <div style="flex: 1; min-width: 200px;">
                                <div class="form-group">
                                    <label class="form-label">Date</label>
                                    <input type="date" class="form-control" name="date" value="<?= htmlspecialchars($date) ?>">
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Filter Withdrawals</button>
                        <a href="withdrawals.php" class="btn btn-secondary">Reset</a>
                    </form>
                </div>
                
                <!-- Withdrawals Table -->
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User UID</th>
                            <th>Method</th>
                            <th>Amount</th>
                            <th>Receiver Number</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($withdrawals as $withdrawal): ?>
                            <tr>
                                <td>#<?= $withdrawal['id'] ?></td>
                                <td><?= htmlspecialchars($withdrawal['user_uid']) ?></td>
                                <td>
                                    <?php 
                                    $badge_class = '';
                                    if ($withdrawal['payment_method'] == 'bkash') $badge_class = 'bg-primary';
                                    elseif ($withdrawal['payment_method'] == 'nagad') $badge_class = 'bg-success';
                                    elseif ($withdrawal['payment_method'] == 'rocket') $badge_class = 'bg-info';
                                    ?>
                                    <span class="badge <?= $badge_class ?>"><?= ucfirst($withdrawal['payment_method']) ?></span>
                                </td>
                                <td>৳<?= number_format($withdrawal['amount'], 2) ?></td>
                                <td><?= htmlspecialchars($withdrawal['receiver_number']) ?></td>
                                <td>
                                    <?php 
                                    $status_class = '';
                                    if ($withdrawal['status'] == 'pending') $status_class = 'pending';
                                    elseif ($withdrawal['status'] == 'approved') $status_class = 'active';
                                    elseif ($withdrawal['status'] == 'rejected') $status_class = 'banned';
                                    ?>
                                    <span class="status <?= $status_class ?>"><?= ucfirst($withdrawal['status']) ?></span>
                                </td>
                                <td><?= date('Y-m-d H:i', strtotime($withdrawal['created_at'])) ?></td>
                                <td>
                                    <?php if ($withdrawal['status'] == 'pending'): ?>
                                        <button class="action-btn approve-btn" onclick="approveWithdrawal(<?= $withdrawal['id'] ?>)">Approve</button>
                                        <button class="action-btn reject-btn" onclick="rejectWithdrawal(<?= $withdrawal['id'] ?>)">Reject</button>
                                    <?php endif; ?>
                                    <button class="action-btn view-btn" onclick="viewWithdrawal(<?= $withdrawal['id'] ?>)">View</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($withdrawals)): ?>
                            <tr>
                                <td colspan="8" style="text-align: center;">No withdrawals found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- View Withdrawal Modal -->
    <div class="modal-overlay" id="viewWithdrawalModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Withdrawal Request Details</h3>
                <button class="modal-close">&times;</button>
            </div>
            <form id="withdrawalForm" method="POST" action="withdrawals.php">
                <input type="hidden" name="withdrawal_id" id="modalWithdrawalId">
                <div class="modal-body">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                        <div>
                            <label class="form-label">Withdrawal ID</label>
                            <p id="modalWithdrawalIdText"></p>
                        </div>
                        <div>
                            <label class="form-label">Date</label>
                            <p id="modalDate"></p>
                        </div>
                        <div>
                            <label class="form-label">User UID</label>
                            <p id="modalUser"></p>
                        </div>
                        <div>
                            <label class="form-label">Status</label>
                            <p id="modalStatus"></p>
                        </div>
                        <div>
                            <label class="form-label">Payment Method</label>
                            <p id="modalMethod"></p>
                        </div>
                        <div>
                            <label class="form-label">Amount</label>
                            <p id="modalAmount"></p>
                        </div>
                        <div>
                            <label class="form-label">Receiver Number</label>
                            <p id="modalReceiver"></p>
                        </div>
                        <div>
                            <label class="form-label">Transaction ID</label>
                            <p id="modalTransactionId"></p>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Admin Notes</label>
                        <textarea class="form-control" name="admin_notes" id="modalNotes" rows="3" placeholder="Add any notes about this withdrawal"></textarea>
                    </div>
                    <div class="form-group" id="transactionIdField">
                        <label class="form-label">Transaction ID (After processing)</label>
                        <input type="text" class="form-control" name="transaction_id" id="modalTransactionIdInput" placeholder="Enter transaction ID after processing">
                    </div>
                </div>
                <div class="modal-footer" id="modalActions">
                    <button type="submit" name="reject_withdrawal" class="btn btn-danger">Reject Withdrawal</button>
                    <button type="submit" name="approve_withdrawal" class="btn btn-success">Approve Withdrawal</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Withdrawal Modal functionality
        const viewWithdrawalModal = document.getElementById('viewWithdrawalModal');
        const closeViewWithdrawalModal = document.querySelector('#viewWithdrawalModal .modal-close');
        
        // Function to fetch withdrawal details via AJAX
        function fetchWithdrawalDetails(withdrawalId) {
            return fetch(`get_withdrawal.php?id=${withdrawalId}`)
                .then(response => response.json())
                .catch(error => console.error('Error:', error));
        }
        
        // View Withdrawal
        async function viewWithdrawal(withdrawalId) {
            const withdrawal = await fetchWithdrawalDetails(withdrawalId);
            
            if (withdrawal) {
                document.getElementById('modalWithdrawalId').value = withdrawal.id;
                document.getElementById('modalWithdrawalIdText').textContent = '#' + withdrawal.id;
                document.getElementById('modalDate').textContent = withdrawal.created_at;
                document.getElementById('modalUser').textContent = withdrawal.user_uid + ' (' + withdrawal.fast_name + ' ' + withdrawal.last_name + ')';
                
                // Set status with appropriate class
                let statusClass = '';
                if (withdrawal.status == 'pending') statusClass = 'pending';
                else if (withdrawal.status == 'approved') statusClass = 'active';
                else if (withdrawal.status == 'rejected') statusClass = 'banned';
                
                document.getElementById('modalStatus').innerHTML = `<span class="status ${statusClass}">${withdrawal.status.charAt(0).toUpperCase() + withdrawal.status.slice(1)}</span>`;
                
                // Set payment method with appropriate class
                let methodClass = '';
                if (withdrawal.payment_method == 'bkash') methodClass = 'bg-primary';
                else if (withdrawal.payment_method == 'nagad') methodClass = 'bg-success';
                else if (withdrawal.payment_method == 'rocket') methodClass = 'bg-info';
                
                document.getElementById('modalMethod').innerHTML = `<span class="badge ${methodClass}">${withdrawal.payment_method.charAt(0).toUpperCase() + withdrawal.payment_method.slice(1)}</span>`;
                
                document.getElementById('modalAmount').textContent = '৳' + parseFloat(withdrawal.amount).toFixed(2);
                document.getElementById('modalReceiver').textContent = withdrawal.receiver_number;
                document.getElementById('modalTransactionId').textContent = withdrawal.transaction_id || 'Not processed yet';
                document.getElementById('modalNotes').value = withdrawal.admin_notes || '';
                document.getElementById('modalTransactionIdInput').value = withdrawal.transaction_id || '';
                
                // Show/hide fields based on status
                const transactionIdField = document.getElementById('transactionIdField');
                const modalActions = document.getElementById('modalActions');
                
                if (withdrawal.status === 'pending') {
                    transactionIdField.style.display = 'block';
                    modalActions.style.display = 'flex';
                } else {
                    transactionIdField.style.display = 'none';
                    modalActions.style.display = 'none';
                }
                
                viewWithdrawalModal.classList.add('active');
            }
        }
        
        // Approve Withdrawal
        function approveWithdrawal(withdrawalId) {
            viewWithdrawal(withdrawalId);
        }
        
        // Reject Withdrawal
        function rejectWithdrawal(withdrawalId) {
            viewWithdrawal(withdrawalId);
        }
        
        closeViewWithdrawalModal.addEventListener('click', () => {
            viewWithdrawalModal.classList.remove('active');
        });
        
        // Close modal when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === viewWithdrawalModal) {
                viewWithdrawalModal.classList.remove('active');
            }
        });
    </script>
</body>
</html>