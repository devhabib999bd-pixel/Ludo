<?php
session_start();
require_once 'config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit;
}
// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}

// Function to safely execute queries
function safeQuery($conn, $sql, $params = []) {
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }
    
    if (!empty($params)) {
        $types = str_repeat('s', count($params));
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    if (!$result) {
        die("Query failed: " . $stmt->error);
    }
    
    return $result;
}

// Handle form submission for filtering
$filter_uid = $_GET['uid'] ?? '';
$filter_method = $_GET['method'] ?? '';
$filter_status = $_GET['status'] ?? '';
$filter_date = $_GET['date'] ?? '';

// Build WHERE clause for filtering
$where = [];
$params = [];

if (!empty($filter_uid)) {
    $where[] = "d.user_uid LIKE ?";
    $params[] = "%$filter_uid%";
}

if (!empty($filter_method)) {
    $where[] = "d.payment_method = ?";
    $params[] = $filter_method;
}

if (!empty($filter_status)) {
    $where[] = "d.status = ?";
    $params[] = $filter_status;
}

if (!empty($filter_date)) {
    $where[] = "DATE(d.created_at) = ?";
    $params[] = $filter_date;
}

$where_clause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);

// Get total deposits count
$total_deposits = safeQuery($conn, "SELECT COUNT(*) as count FROM deposits d $where_clause", $params)->fetch_assoc()['count'];

// Pagination
$per_page = 10;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $per_page;
$total_pages = ceil($total_deposits / $per_page);

// Get deposits with pagination
$deposits_query = safeQuery($conn, 
    "SELECT d.*, u.fast_name, u.last_name 
     FROM deposits d
     JOIN users u ON d.user_uid = u.user_uid
     $where_clause 
     ORDER BY d.created_at DESC 
     LIMIT ? OFFSET ?", 
    array_merge($params, [$per_page, $offset])
);

// Handle actions (approve/reject)
if (isset($_POST['action'])) {
    $deposit_id = $_POST['deposit_id'];
    $action = $_POST['action'];
    $admin_notes = $_POST['admin_notes'] ?? '';
    
    switch ($action) {
        case 'approve':
            // Update deposit status
            safeQuery($conn, "UPDATE deposits SET status = 'approved', admin_notes = ?, updated_at = NOW() WHERE id = ?", [$admin_notes, $deposit_id]);
            
            // Add to user's gaming balance
            $deposit = safeQuery($conn, "SELECT user_uid, amount FROM deposits WHERE id = ?", [$deposit_id])->fetch_assoc();
            safeQuery($conn, "UPDATE users SET gaming_balance = gaming_balance + ? WHERE user_uid = ?", [$deposit['amount'], $deposit['user_uid']]);
            
            // Create transaction record
            safeQuery($conn, 
                "INSERT INTO transactions (user_uid, type, amount, reference_id) 
                 VALUES (?, 'deposit', ?, ?)",
                [$deposit['user_uid'], $deposit['amount'], "DEP-$deposit_id"]
            );
            break;
            
        case 'reject':
            safeQuery($conn, "UPDATE deposits SET status = 'rejected', admin_notes = ?, updated_at = NOW() WHERE id = ?", [$admin_notes, $deposit_id]);
            break;
    }
    
    // Refresh the page
    header("Location: deposits.php?" . http_build_query($_GET));
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($site_name); ?> - System Settings</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #6C5CE7;
            --secondary: #A29BFE;
            --dark: #2D3436;
            --light: #F5F6FA;
            --success: #00B894;
            --danger: #D63031;
            --warning: #FDCB6E;
            --info: #0984E3;
            --gold: #FFD700;
            --purple-dark: #07031E;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: #0F0F1A;
            color: #F5F6FA;
            overflow-x: hidden;
        }

        .admin-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--purple-dark) 0%, #1A1A2E 100%);
            padding: 20px 0;
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
            position: fixed;
            height: 100vh;
            z-index: 100;
            transition: all 0.3s;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .sidebar-header h3 {
            color: var(--gold);
            font-weight: 600;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-category {
            color: var(--secondary);
            text-transform: uppercase;
            font-size: 12px;
            font-weight: 600;
            padding: 15px 20px 10px;
            letter-spacing: 1px;
        }

        .menu-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            margin: 5px 0;
            color: #F5F6FA;
            text-decoration: none;
            border-left: 3px solid transparent;
            transition: all 0.3s;
        }

        .menu-item:hover, .menu-item.active {
            background: rgba(108, 92, 231, 0.1);
            border-left: 3px solid var(--primary);
            color: var(--gold);
        }

        .menu-item i {
            margin-right: 12px;
            font-size: 18px;
            width: 24px;
            text-align: center;
        }

        .menu-item .badge {
            margin-left: auto;
            background: var(--danger);
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 12px;
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 20px;
            transition: all 0.3s;
        }

        /* Top Navigation */
        .top-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 25px;
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .search-bar {
            position: relative;
            width: 300px;
        }

        .search-bar input {
            width: 100%;
            padding: 10px 15px 10px 40px;
            border: none;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 30px;
            color: white;
            outline: none;
        }

        .search-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--secondary);
        }

        .user-profile {
            display: flex;
            align-items: center;
        }

        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
            border: 2px solid var(--gold);
        }

        .notification-bell {
            position: relative;
            margin-right: 20px;
            font-size: 20px;
            color: var(--secondary);
            cursor: pointer;
        }

        .notification-bell .badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Dashboard Cards */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .card-title {
            font-size: 16px;
            color: var(--secondary);
        }

        .card-value {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 10px;
            color: var(--gold);
        }

        .card-footer {
            display: flex;
            align-items: center;
            font-size: 14px;
        }

        .card-footer i {
            margin-right: 5px;
        }

        .positive {
            color: var(--success);
        }

        .negative {
            color: var(--danger);
        }

        /* Recent Activity */
        .activity-section {
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--gold);
        }

        .view-all {
            color: var(--secondary);
            text-decoration: none;
            font-size: 14px;
        }

        .activity-list {
            list-style: none;
        }

        .activity-item {
            display: flex;
            padding: 15px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(108, 92, 231, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            color: var(--primary);
            font-size: 18px;
        }

        .activity-content {
            flex: 1;
        }

        .activity-user {
            font-weight: 600;
            margin-bottom: 5px;
        }

        .activity-details {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.7);
        }

        .activity-time {
            font-size: 12px;
            color: var(--secondary);
        }

        /* Data Tables */
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .data-table th {
            background: rgba(108, 92, 231, 0.2);
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            color: var(--gold);
        }

        .data-table td {
            padding: 12px 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .data-table tr:hover {
            background: rgba(108, 92, 231, 0.05);
        }

        .status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status.active {
            background: rgba(0, 184, 148, 0.2);
            color: var(--success);
        }

        .status.pending {
            background: rgba(253, 203, 110, 0.2);
            color: var(--warning);
        }

        .status.banned {
            background: rgba(214, 48, 49, 0.2);
            color: var(--danger);
        }

        .status.completed {
            background: rgba(108, 92, 231, 0.2);
            color: var(--primary);
        }

        .status.waiting {
            background: rgba(9, 132, 227, 0.2);
            color: var(--info);
        }

        .action-btn {
            padding: 5px 10px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            margin-right: 5px;
            font-size: 12px;
            transition: all 0.3s;
        }

        .edit-btn {
            background: rgba(9, 132, 227, 0.2);
            color: var(--info);
        }

        .delete-btn {
            background: rgba(214, 48, 49, 0.2);
            color: var(--danger);
        }

        .view-btn {
            background: rgba(0, 184, 148, 0.2);
            color: var(--success);
        }

        .approve-btn {
            background: rgba(0, 184, 148, 0.2);
            color: var(--success);
        }

        .reject-btn {
            background: rgba(214, 48, 49, 0.2);
            color: var(--danger);
        }

        /* Form Styles */
        .form-card {
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: var(--secondary);
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: white;
            font-size: 14px;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(108, 92, 231, 0.1);
        }

        .form-select {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: white;
            font-size: 14px;
            transition: all 0.3s;
        }

        .btn {
            padding: 12px 25px;
            border-radius: 8px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: #5a4bc2;
        }

        .btn-secondary {
            background: var(--secondary);
            color: white;
        }

        .btn-secondary:hover {
            background: #8a7bf3;
        }

        /* Modal Styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
        }

        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        .modal-content {
            background: rgba(13, 13, 26, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            transform: translateY(20px);
            transition: all 0.3s;
        }

        .modal-overlay.active .modal-content {
            transform: translateY(0);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .modal-title {
            color: var(--gold);
            font-size: 20px;
            font-weight: 600;
        }

        .modal-close {
            background: none;
            border: none;
            color: var(--secondary);
            font-size: 24px;
            cursor: pointer;
        }

        .modal-body {
            margin-bottom: 20px;
        }

        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            .sidebar-header h3, .menu-category, .menu-item span {
                display: none;
            }
            .menu-item {
                justify-content: center;
                padding: 15px 0;
            }
            .menu-item i {
                margin-right: 0;
                font-size: 20px;
            }
            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .dashboard-cards {
                grid-template-columns: 1fr;
            }
            .top-nav {
                flex-direction: column;
                align-items: flex-start;
            }
            .search-bar {
                width: 100%;
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <img src="admin.png" alt="Admin Logo">
                <h3>LUDO BD Admin</h3>
            </div>
            
            <div class="sidebar-menu">
                
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Overview</span>
                </a>
                
                <div class="menu-category">Management</div>
                <a href="users.php" class="menu-item">
                    <i class="fas fa-users"></i>
                    <span>Users</span>
                    <span class="badge"><?php echo $total_users; ?></span>
                </a>
                <a href="matches.php" class="menu-item">
                    <i class="fas fa-gamepad"></i>
                    <span>Matches</span>
                </a>
                <a href="transactions.php" class="menu-item">
                    <i class="fas fa-wallet"></i>
                    <span>Transactions</span>
                </a>
                <a href="referrals.php" class="menu-item">
                    <i class="fas fa-gift"></i>
                    <span>Referrals</span>
                </a>
                <a href="deposits.php" class="menu-item active">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Deposits</span>
                    <?php 
                    $pending_count = safeQuery($conn, "SELECT COUNT(*) as count FROM deposits WHERE status = 'pending'")->fetch_assoc()['count'];
                    if ($pending_count > 0): ?>
                        <span class="badge"><?php echo $pending_count; ?></span>
                    <?php endif; ?>
                </a>
                <a href="withdrawals.php" class="menu-item">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Withdrawals</span>
                </a>
                
                <div class="menu-category">Content</div>
                <a href="notifications.php" class="menu-item">
                    <i class="fas fa-bullhorn"></i>
                    <span>Notifications</span>
                </a>
                
                <div class="menu-category">Settings</div>
                <a href="settings.php" class="menu-item">
                    <i class="fas fa-cog"></i>
                    <span>System Settings</span>
                </a>
                <a href="admins.php" class="menu-item">
                    <i class="fas fa-user-shield"></i>
                    <span>Admin Users</span>
                </a>
                <a href="wallets.php" class="menu-item">
                    <i class="fas fa-wallet"></i>
                    <span>Payment Wallets</span>
                </a>
            </div>
        </div>
        

        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navigation -->
            <div class="top-nav">
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search deposits..." id="searchInput">
                </div>
                
                <div class="user-profile">
                    <div class="notification-bell">
                        <i class="fas fa-bell"></i>
                        <span class="badge"><?php echo $pending_count; ?></span>
                    </div>
                    <img src="assets/images/admin-avatar.png" alt="Admin Profile">
                    <span><?php echo $_SESSION['admin_username']; ?></span>
                    <a href="logout.php" style="margin-left:15px;color:var(--danger)">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                </div>
            </div>

            <!-- Deposits Management Section -->
            <div class="activity-section">
                <div class="section-header">
                    <h3 class="section-title">Deposit Requests</h3>
                </div>
                
                <!-- Filter Form -->
                <div class="form-card">
                    <form method="GET">
                        <div class="row" style="display: flex; flex-wrap: wrap; gap: 15px; margin-bottom: 20px;">
                            <div style="flex: 1; min-width: 200px;">
                                <div class="form-group">
                                    <label class="form-label">User UID</label>
                                    <input type="text" name="uid" class="form-control" placeholder="Enter UID" value="<?php echo htmlspecialchars($filter_uid); ?>">
                                </div>
                            </div>
                            <div style="flex: 1; min-width: 200px;">
                                <div class="form-group">
                                    <label class="form-label">Payment Method</label>
                                    <select name="method" class="form-select">
                                        <option value="">All Methods</option>
                                        <option value="bkash" <?php echo ($filter_method === 'bkash') ? 'selected' : ''; ?>>Bkash</option>
                                        <option value="nagad" <?php echo ($filter_method === 'nagad') ? 'selected' : ''; ?>>Nagad</option>
                                        <option value="rocket" <?php echo ($filter_method === 'rocket') ? 'selected' : ''; ?>>Rocket</option>
                                    </select>
                                </div>
                            </div>
                            <div style="flex: 1; min-width: 200px;">
                                <div class="form-group">
                                    <label class="form-label">Status</label>
                                    <select name="status" class="form-select">
                                        <option value="">All Statuses</option>
                                        <option value="pending" <?php echo ($filter_status === 'pending') ? 'selected' : ''; ?>>Pending</option>
                                        <option value="approved" <?php echo ($filter_status === 'approved') ? 'selected' : ''; ?>>Approved</option>
                                        <option value="rejected" <?php echo ($filter_status === 'rejected') ? 'selected' : ''; ?>>Rejected</option>
                                    </select>
                                </div>
                            </div>
                            <div style="flex: 1; min-width: 200px;">
                                <div class="form-group">
                                    <label class="form-label">Date</label>
                                    <input type="date" name="date" class="form-control" value="<?php echo htmlspecialchars($filter_date); ?>">
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Filter Deposits</button>
                        <a href="deposits.php" class="btn btn-secondary">Reset</a>
                    </form>
                </div>
                
                <!-- Deposits Table -->
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Method</th>
                            <th>Amount</th>
                            <th>Sender Number</th>
                            <th>Transaction ID</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($deposit = $deposits_query->fetch_assoc()): ?>
                        <tr>
                            <td>#<?php echo $deposit['id']; ?></td>
                            <td><?php echo htmlspecialchars($deposit['user_uid']); ?> (<?php echo htmlspecialchars($deposit['fast_name'] . ' ' . $deposit['last_name']); ?>)</td>
                            <td>
                                <?php 
                                $badge_class = [
                                    'bkash' => 'bg-primary',
                                    'nagad' => 'bg-success',
                                    'rocket' => 'bg-info'
                                ];
                                ?>
                                <span class="badge <?php echo $badge_class[$deposit['payment_method']]; ?>">
                                    <?php echo ucfirst($deposit['payment_method']); ?>
                                </span>
                            </td>
                            <td>৳<?php echo number_format($deposit['amount'], 2); ?></td>
                            <td><?php echo htmlspecialchars($deposit['sender_number']); ?></td>
                            <td><?php echo htmlspecialchars($deposit['transaction_id']); ?></td>
                            <td>
                                <?php 
                                $status_class = [
                                    'pending' => 'pending',
                                    'approved' => 'active',
                                    'rejected' => 'banned'
                                ];
                                ?>
                                <span class="status <?php echo $status_class[$deposit['status']]; ?>">
                                    <?php echo ucfirst($deposit['status']); ?>
                                </span>
                            </td>
                            <td><?php echo date('Y-m-d H:i', strtotime($deposit['created_at'])); ?></td>
                            <td>
                                <?php if ($deposit['status'] === 'pending'): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="deposit_id" value="<?php echo $deposit['id']; ?>">
                                        <input type="hidden" name="action" value="approve">
                                        <button type="submit" class="action-btn approve-btn">Approve</button>
                                    </form>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="deposit_id" value="<?php echo $deposit['id']; ?>">
                                        <input type="hidden" name="action" value="reject">
                                        <button type="submit" class="action-btn reject-btn">Reject</button>
                                    </form>
                                <?php endif; ?>
                                <button class="action-btn view-btn" data-deposit='<?php echo json_encode($deposit); ?>'>View</button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                <div class="pagination" style="margin-top: 20px; display: flex; justify-content: center;">
                    <?php if ($page > 1): ?>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" class="btn btn-secondary" style="margin-right: 10px;">Previous</a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" class="btn <?php echo ($i == $page) ? 'btn-primary' : 'btn-secondary'; ?>" style="margin: 0 5px;"><?php echo $i; ?></a>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" class="btn btn-secondary" style="margin-left: 10px;">Next</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- View Deposit Modal -->
    <div class="modal-overlay" id="viewDepositModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Deposit Request Details</h3>
                <button class="modal-close">&times;</button>
            </div>
            <div class="modal-body">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;" id="depositDetails">
                    <!-- Will be populated by JavaScript -->
                </div>
                <form id="depositActionForm" method="POST">
                    <input type="hidden" name="deposit_id" id="modalDepositId">
                    <input type="hidden" name="action" id="modalAction">
                    <div class="form-group">
                        <label class="form-label">Admin Notes</label>
                        <textarea name="admin_notes" class="form-control" rows="3" placeholder="Add any notes about this deposit" id="modalAdminNotes"></textarea>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" id="rejectDepositBtn">Reject Deposit</button>
                <button type="button" class="btn btn-success" id="approveDepositBtn">Approve Deposit</button>
                <button type="button" class="btn btn-secondary close-view-modal">Close</button>
            </div>
        </div>
    </div>

    <script>
        // Modal functionality
        const viewDepositModal = document.getElementById('viewDepositModal');
        const closeViewModal = document.querySelector('.close-view-modal');
        const depositDetails = document.getElementById('depositDetails');
        const depositActionForm = document.getElementById('depositActionForm');
        const modalDepositId = document.getElementById('modalDepositId');
        const modalAdminNotes = document.getElementById('modalAdminNotes');
        const modalAction = document.getElementById('modalAction');

        // View Deposit Modal
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const depositData = JSON.parse(btn.dataset.deposit);
                
                // Populate modal with deposit data
                depositDetails.innerHTML = `
                    <div>
                        <label class="form-label">Deposit ID</label>
                        <p>#${depositData.id}</p>
                    </div>
                    <div>
                        <label class="form-label">Date</label>
                        <p>${new Date(depositData.created_at).toLocaleString()}</p>
                    </div>
                    <div>
                        <label class="form-label">User UID</label>
                        <p>${depositData.user_uid} (${depositData.fast_name} ${depositData.last_name})</p>
                    </div>
                    <div>
                        <label class="form-label">Status</label>
                        <p><span class="status ${depositData.status === 'pending' ? 'pending' : depositData.status === 'approved' ? 'active' : 'banned'}">
                            ${depositData.status.charAt(0).toUpperCase() + depositData.status.slice(1)}
                        </span></p>
                    </div>
                    <div>
                        <label class="form-label">Payment Method</label>
                        <p><span class="badge ${depositData.payment_method === 'bkash' ? 'bg-primary' : depositData.payment_method === 'nagad' ? 'bg-success' : 'bg-info'}">
                            ${depositData.payment_method.charAt(0).toUpperCase() + depositData.payment_method.slice(1)}
                        </span></p>
                    </div>
                    <div>
                        <label class="form-label">Amount</label>
                        <p>৳${parseFloat(depositData.amount).toFixed(2)}</p>
                    </div>
                    <div>
                        <label class="form-label">Sender Number</label>
                        <p>${depositData.sender_number}</p>
                    </div>
                    <div>
                        <label class="form-label">Transaction ID</label>
                        <p>${depositData.transaction_id}</p>
                    </div>
                    ${depositData.admin_notes ? `
                    <div style="grid-column: span 2;">
                        <label class="form-label">Admin Notes</label>
                        <p>${depositData.admin_notes}</p>
                    </div>
                    ` : ''}
                `;
                
                // Set form values
                modalDepositId.value = depositData.id;
                modalAdminNotes.value = depositData.admin_notes || '';
                
                // Show/hide action buttons based on status
                document.getElementById('approveDepositBtn').style.display = depositData.status === 'pending' ? 'inline-block' : 'none';
                document.getElementById('rejectDepositBtn').style.display = depositData.status === 'pending' ? 'inline-block' : 'none';
                
                viewDepositModal.classList.add('active');
            });
        });

        // Approve/Reject buttons
        document.getElementById('approveDepositBtn').addEventListener('click', () => {
            modalAction.value = 'approve';
            depositActionForm.submit();
        });

        document.getElementById('rejectDepositBtn').addEventListener('click', () => {
            modalAction.value = 'reject';
            depositActionForm.submit();
        });

        closeViewModal.addEventListener('click', () => {
            viewDepositModal.classList.remove('active');
        });

        // Close modal when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === viewDepositModal) {
                viewDepositModal.classList.remove('active');
            }
        });

        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function(e) {
            if (e.key === 'Enter') {
                const searchTerm = this.value.trim();
                if (searchTerm) {
                    window.location.href = `deposits.php?uid=${encodeURIComponent(searchTerm)}&transaction_id=${encodeURIComponent(searchTerm)}`;
                }
            }
        });
    </script>
</body>
</html>

