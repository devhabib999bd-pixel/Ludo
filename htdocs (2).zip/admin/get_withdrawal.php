<?php
require_once 'config.php';

header('Content-Type: application/json');

if (!isset($_GET['id'])) {
    echo json_encode(['error' => 'Withdrawal ID not provided']);
    exit;
}

$withdrawal_id = $_GET['id'];

$stmt = $conn->prepare("SELECT w.*, u.fast_name, u.last_name 
                       FROM withdrawals w 
                       JOIN users u ON w.user_uid = u.user_uid 
                       WHERE w.id = ?");
$stmt->bind_param("i", $withdrawal_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $withdrawal = $result->fetch_assoc();
    echo json_encode($withdrawal);
} else {
    echo json_encode(['error' => 'Withdrawal not found']);
}