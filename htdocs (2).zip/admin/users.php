<?php
session_start();
require_once 'config.php';
// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}


// Function to safely execute queries
function safeQuery($conn, $sql, $params = []) {
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }
    
    if (!empty($params)) {
        $types = str_repeat('s', count($params));
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    if (!$result) {
        die("Query failed: " . $stmt->error);
    }
    
    return $result;
}

// Handle form submission for filtering
$filter_uid = $_GET['uid'] ?? '';
$filter_phone = $_GET['phone'] ?? '';
$filter_status = $_GET['status'] ?? '';
$filter_verified = $_GET['verified'] ?? '';

// Build WHERE clause for filtering
$where = [];
$params = [];

if (!empty($filter_uid)) {
    $where[] = "user_uid LIKE ?";
    $params[] = "%$filter_uid%";
}

if (!empty($filter_phone)) {
    $where[] = "phone LIKE ?";
    $params[] = "%$filter_phone%";
}

if (!empty($filter_status)) {
    if ($filter_status === 'active') {
        $where[] = "is_banned = 0";
    } elseif ($filter_status === 'banned') {
        $where[] = "is_banned = 1";
    }
}

if (!empty($filter_verified)) {
    $where[] = "is_verified = ?";
    $params[] = ($filter_verified === 'verified') ? 1 : 0;
}

$where_clause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);

// Get total users count
$total_users = safeQuery($conn, "SELECT COUNT(*) as count FROM users $where_clause", $params)->fetch_assoc()['count'];

// Pagination
$per_page = 10;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $per_page;
$total_pages = ceil($total_users / $per_page);

// Get users with pagination
$users_query = safeQuery($conn, 
    "SELECT * FROM users $where_clause ORDER BY created_at DESC LIMIT ? OFFSET ?", 
    array_merge($params, [$per_page, $offset])
);

// Handle actions (ban/unban, verify)
if (isset($_POST['action'])) {
    $user_uid = $_POST['user_uid'];
    $action = $_POST['action'];
    
    switch ($action) {
        case 'ban':
            safeQuery($conn, "UPDATE users SET is_banned = 1 WHERE user_uid = ?", [$user_uid]);
            break;
        case 'unban':
            safeQuery($conn, "UPDATE users SET is_banned = 0, ban_reason = NULL WHERE user_uid = ?", [$user_uid]);
            break;
        case 'verify':
            safeQuery($conn, "UPDATE users SET is_verified = 1 WHERE user_uid = ?", [$user_uid]);
            break;
    }
    
    // Refresh the page
    header("Location: users.php?" . http_build_query($_GET));
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($site_name); ?> - Users Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #6C5CE7;
            --secondary: #A29BFE;
            --dark: #2D3436;
            --light: #F5F6FA;
            --success: #00B894;
            --danger: #D63031;
            --warning: #FDCB6E;
            --info: #0984E3;
            --gold: #FFD700;
            --purple-dark: #07031E;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background-color: #0F0F1A;
            color: #F5F6FA;
            overflow-x: hidden;
        }

        .admin-container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, var(--purple-dark) 0%, #1A1A2E 100%);
            padding: 20px 0;
            box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
            position: fixed;
            height: 100vh;
            z-index: 100;
            transition: all 0.3s;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .sidebar-header h3 {
            color: var(--gold);
            font-weight: 600;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .menu-category {
            color: var(--secondary);
            text-transform: uppercase;
            font-size: 12px;
            font-weight: 600;
            padding: 15px 20px 10px;
            letter-spacing: 1px;
        }

        .menu-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            margin: 5px 0;
            color: #F5F6FA;
            text-decoration: none;
            border-left: 3px solid transparent;
            transition: all 0.3s;
        }

        .menu-item:hover, .menu-item.active {
            background: rgba(108, 92, 231, 0.1);
            border-left: 3px solid var(--primary);
            color: var(--gold);
        }

        .menu-item i {
            margin-right: 12px;
            font-size: 18px;
            width: 24px;
            text-align: center;
        }

        .menu-item .badge {
            margin-left: auto;
            background: var(--danger);
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 12px;
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 20px;
            transition: all 0.3s;
        }

        /* Top Navigation */
        .top-nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 25px;
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .search-bar {
            position: relative;
            width: 300px;
        }

        .search-bar input {
            width: 100%;
            padding: 10px 15px 10px 40px;
            border: none;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 30px;
            color: white;
            outline: none;
        }

        .search-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--secondary);
        }

        .user-profile {
            display: flex;
            align-items: center;
        }

        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
            border: 2px solid var(--gold);
        }

        .notification-bell {
            position: relative;
            margin-right: 20px;
            font-size: 20px;
            color: var(--secondary);
            cursor: pointer;
        }

        .notification-bell .badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Dashboard Cards */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .card-title {
            font-size: 16px;
            color: var(--secondary);
        }

        .card-value {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 10px;
            color: var(--gold);
        }

        .card-footer {
            display: flex;
            align-items: center;
            font-size: 14px;
        }

        .card-footer i {
            margin-right: 5px;
        }

        .positive {
            color: var(--success);
        }

        .negative {
            color: var(--danger);
        }

        /* Recent Activity */
        .activity-section {
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--gold);
        }

        .view-all {
            color: var(--secondary);
            text-decoration: none;
            font-size: 14px;
        }

        .activity-list {
            list-style: none;
        }

        .activity-item {
            display: flex;
            padding: 15px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(108, 92, 231, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            color: var(--primary);
            font-size: 18px;
        }

        .activity-content {
            flex: 1;
        }

        .activity-user {
            font-weight: 600;
            margin-bottom: 5px;
        }

        .activity-details {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.7);
        }

        .activity-time {
            font-size: 12px;
            color: var(--secondary);
        }

        /* Data Tables */
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .data-table th {
            background: rgba(108, 92, 231, 0.2);
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            color: var(--gold);
        }

        .data-table td {
            padding: 12px 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }

        .data-table tr:hover {
            background: rgba(108, 92, 231, 0.05);
        }

        .status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status.active {
            background: rgba(0, 184, 148, 0.2);
            color: var(--success);
        }

        .status.pending {
            background: rgba(253, 203, 110, 0.2);
            color: var(--warning);
        }

        .status.banned {
            background: rgba(214, 48, 49, 0.2);
            color: var(--danger);
        }

        .status.completed {
            background: rgba(108, 92, 231, 0.2);
            color: var(--primary);
        }

        .status.waiting {
            background: rgba(9, 132, 227, 0.2);
            color: var(--info);
        }

        .action-btn {
            padding: 5px 10px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            margin-right: 5px;
            font-size: 12px;
            transition: all 0.3s;
        }

        .edit-btn {
            background: rgba(9, 132, 227, 0.2);
            color: var(--info);
        }

        .delete-btn {
            background: rgba(214, 48, 49, 0.2);
            color: var(--danger);
        }

        .view-btn {
            background: rgba(0, 184, 148, 0.2);
            color: var(--success);
        }

        .approve-btn {
            background: rgba(0, 184, 148, 0.2);
            color: var(--success);
        }

        .reject-btn {
            background: rgba(214, 48, 49, 0.2);
            color: var(--danger);
        }

        /* Form Styles */
        .form-card {
            background: rgba(13, 13, 26, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            color: var(--secondary);
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: white;
            font-size: 14px;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(108, 92, 231, 0.1);
        }

        .form-select {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            color: white;
            font-size: 14px;
            transition: all 0.3s;
        }

        .btn {
            padding: 12px 25px;
            border-radius: 8px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background: #5a4bc2;
        }

        .btn-secondary {
            background: var(--secondary);
            color: white;
        }

        .btn-secondary:hover {
            background: #8a7bf3;
        }

        /* Modal Styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
        }

        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        .modal-content {
            background: rgba(13, 13, 26, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            transform: translateY(20px);
            transition: all 0.3s;
        }

        .modal-overlay.active .modal-content {
            transform: translateY(0);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .modal-title {
            color: var(--gold);
            font-size: 20px;
            font-weight: 600;
        }

        .modal-close {
            background: none;
            border: none;
            color: var(--secondary);
            font-size: 24px;
            cursor: pointer;
        }

        .modal-body {
            margin-bottom: 20px;
        }

        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                overflow: hidden;
            }
            .sidebar-header h3, .menu-category, .menu-item span {
                display: none;
            }
            .menu-item {
                justify-content: center;
                padding: 15px 0;
            }
            .menu-item i {
                margin-right: 0;
                font-size: 20px;
            }
            .main-content {
                margin-left: 80px;
            }
        }

        @media (max-width: 768px) {
            .dashboard-cards {
                grid-template-columns: 1fr;
            }
            .top-nav {
                flex-direction: column;
                align-items: flex-start;
            }
            .search-bar {
                width: 100%;
                margin-bottom: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <img src="admin.png" alt="Admin Logo">
                <h3>LUDO BD Admin</h3>
            </div>
            
            <div class="sidebar-menu">
                <a href="dashboard.php" class="menu-item">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Overview</span>
                </a>
                
                <div class="menu-category">Management</div>
                <a href="users.php" class="menu-item active">
                    <i class="fas fa-users"></i>
                    <span>Users</span>
                    <span class="badge"><?php echo $total_users; ?></span>
                </a>
                <a href="matches.php" class="menu-item">
                    <i class="fas fa-gamepad"></i>
                    <span>Matches</span>
                </a>
                <a href="transactions.php" class="menu-item">
                    <i class="fas fa-wallet"></i>
                    <span>Transactions</span>
                </a>
                <a href="referrals.php" class="menu-item">
                    <i class="fas fa-gift"></i>
                    <span>Referrals</span>
                </a>
                <a href="deposits.php" class="menu-item">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Deposits</span>
                </a>
                <a href="withdrawals.php" class="menu-item">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Withdrawals</span>
                </a>
                
                <div class="menu-category">Content</div>
                <a href="notifications.php" class="menu-item">
                    <i class="fas fa-bullhorn"></i>
                    <span>Notifications</span>
                </a>
                
                <div class="menu-category">Settings</div>
                <a href="settings.php" class="menu-item">
                    <i class="fas fa-cog"></i>
                    <span>System Settings</span>
                </a>
                <a href="admins.php" class="menu-item">
                    <i class="fas fa-user-shield"></i>
                    <span>Admin Users</span>
                </a>
                <a href="wallets.php" class="menu-item">
                    <i class="fas fa-wallet"></i>
                    <span>Payment Wallets</span>
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Top Navigation -->
            <div class="top-nav">
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search users..." id="searchInput">
                </div>
                
                <div class="user-profile">
                    <div class="notification-bell">
                        <i class="fas fa-bell"></i>
                        <span class="badge">3</span>
                    </div>
                    <img src="admin.png" alt="Admin Profile">
                    <span><?php echo $_SESSION['admin_username']; ?></span>
                    <a href="logout.php" style="margin-left:15px;color:var(--danger)">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                </div>
            </div>

            <!-- Users Management Section -->
            <div class="activity-section">
                <div class="section-header">
                    <h3 class="section-title">User Management</h3>
                    <button class="btn btn-primary" id="addUserBtn">Add New User</button>
                </div>
                
                <!-- Filter Form -->
                <div class="form-card">
                    <form method="GET">
                        <div class="row" style="display: flex; flex-wrap: wrap; gap: 15px; margin-bottom: 20px;">
                            <div style="flex: 1; min-width: 200px;">
                                <div class="form-group">
                                    <label class="form-label">User UID</label>
                                    <input type="text" name="uid" class="form-control" placeholder="Enter UID" value="<?php echo htmlspecialchars($filter_uid); ?>">
                                </div>
                            </div>
                            <div style="flex: 1; min-width: 200px;">
                                <div class="form-group">
                                    <label class="form-label">Phone Number</label>
                                    <input type="text" name="phone" class="form-control" placeholder="Enter phone" value="<?php echo htmlspecialchars($filter_phone); ?>">
                                </div>
                            </div>
                            <div style="flex: 1; min-width: 200px;">
                                <div class="form-group">
                                    <label class="form-label">Status</label>
                                    <select name="status" class="form-select">
                                        <option value="">All Statuses</option>
                                        <option value="active" <?php echo ($filter_status === 'active') ? 'selected' : ''; ?>>Active</option>
                                        <option value="banned" <?php echo ($filter_status === 'banned') ? 'selected' : ''; ?>>Banned</option>
                                    </select>
                                </div>
                            </div>
                            <div style="flex: 1; min-width: 200px;">
                                <div class="form-group">
                                    <label class="form-label">Verification</label>
                                    <select name="verified" class="form-select">
                                        <option value="">All</option>
                                        <option value="verified" <?php echo ($filter_verified === 'verified') ? 'selected' : ''; ?>>Verified</option>
                                        <option value="unverified" <?php echo ($filter_verified === 'unverified') ? 'selected' : ''; ?>>Unverified</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Filter Users</button>
                        <a href="users.php" class="btn btn-secondary">Reset</a>
                    </form>
                </div>
                
                <!-- Users Table -->
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>UID</th>
                            <th>Name</th>
                            <th>Phone</th>
                            <th>Winnings</th>
                            <th>Gaming</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($user = $users_query->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['user_uid']); ?></td>
                            <td><?php echo htmlspecialchars($user['fast_name'] . ' ' . $user['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($user['phone']); ?></td>
                            <td>৳<?php echo number_format($user['winning_balance'], 2); ?></td>
                            <td>৳<?php echo number_format($user['gaming_balance'], 2); ?></td>
                            <td>
                                <?php if ($user['is_banned']): ?>
                                    <span class="status banned">Banned</span>
                                <?php else: ?>
                                    <span class="status active">Active</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="action-btn view-btn" data-user='<?php echo json_encode($user); ?>'>View</button>
                                <button class="action-btn edit-btn">Edit</button>
                                <?php if ($user['is_banned']): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="user_uid" value="<?php echo $user['user_uid']; ?>">
                                        <input type="hidden" name="action" value="unban">
                                        <button type="submit" class="action-btn approve-btn">Unban</button>
                                    </form>
                                <?php else: ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="user_uid" value="<?php echo $user['user_uid']; ?>">
                                        <input type="hidden" name="action" value="ban">
                                        <button type="submit" class="action-btn delete-btn">Ban</button>
                                    </form>
                                <?php endif; ?>
                                <?php if (!$user['is_verified']): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="user_uid" value="<?php echo $user['user_uid']; ?>">
                                        <input type="hidden" name="action" value="verify">
                                        <button type="submit" class="action-btn approve-btn">Verify</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                <div class="pagination" style="margin-top: 20px; display: flex; justify-content: center;">
                    <?php if ($page > 1): ?>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>" class="btn btn-secondary" style="margin-right: 10px;">Previous</a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>" class="btn <?php echo ($i == $page) ? 'btn-primary' : 'btn-secondary'; ?>" style="margin: 0 5px;"><?php echo $i; ?></a>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>" class="btn btn-secondary" style="margin-left: 10px;">Next</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Add User Modal -->
    <div class="modal-overlay" id="addUserModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Add New User</h3>
                <button class="modal-close" id="closeModal">&times;</button>
            </div>
            <div class="modal-body">
                <form action="add_user.php" method="POST">
                    <div class="form-group">
                        <label class="form-label">First Name</label>
                        <input type="text" name="fast_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Last Name</label>
                        <input type="text" name="last_name" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Phone Number</label>
                        <input type="text" name="phone" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Referral Code (Optional)</label>
                        <input type="text" name="referral_code" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Initial Gaming Balance</label>
                        <input type="number" name="gaming_balance" class="form-control" value="0" step="0.01">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Initial Winning Balance</label>
                        <input type="number" name="winning_balance" class="form-control" value="0" step="0.01">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" id="cancelModal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Create User</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View User Modal -->
    <div class="modal-overlay" id="viewUserModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">User Details</h3>
                <button class="modal-close">&times;</button>
            </div>
            <div class="modal-body">
                <div class="user-profile-view" style="display: flex; align-items: center; margin-bottom: 20px;">
                    <img src="assets/images/default-user.png" alt="User Profile" style="width: 80px; height: 80px; border-radius: 50%; border: 3px solid var(--gold); margin-right: 20px;">
                    <div>
                        <h3 style="color: var(--gold); margin-bottom: 5px;" id="viewUserName"></h3>
                        <p style="color: var(--secondary);" id="viewUserUID"></p>
                    </div>
                </div>
                
                <div class="user-details" style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="detail-item">
                        <label class="form-label">Phone</label>
                        <p id="viewUserPhone"></p>
                    </div>
                    <div class="detail-item">
                        <label class="form-label">Status</label>
                        <p id="viewUserStatus"></p>
                    </div>
                    <div class="detail-item">
                        <label class="form-label">Verified</label>
                        <p id="viewUserVerified"></p>
                    </div>
                    <div class="detail-item">
                        <label class="form-label">Banned</label>
                        <p id="viewUserBanned"></p>
                    </div>
                    <div class="detail-item">
                        <label class="form-label">Winning Balance</label>
                        <p id="viewUserWinning"></p>
                    </div>
                    <div class="detail-item">
                        <label class="form-label">Gaming Balance</label>
                        <p id="viewUserGaming"></p>
                    </div>
                    <div class="detail-item">
                        <label class="form-label">Total Winnings</label>
                        <p id="viewUserTotalWinnings"></p>
                    </div>
                    <div class="detail-item">
                        <label class="form-label">Matches Played</label>
                        <p id="viewUserMatches"></p>
                    </div>
                    <div class="detail-item" style="grid-column: span 2;">
                        <label class="form-label">Referral Code</label>
                        <p id="viewUserReferral"></p>
                    </div>
                    <div class="detail-item" style="grid-column: span 2;">
                        <label class="form-label">Referred By</label>
                        <p id="viewUserReferredBy"></p>
                    </div>
                    <div class="detail-item" style="grid-column: span 2;">
                        <label class="form-label">Join Date</label>
                        <p id="viewUserJoinDate"></p>
                    </div>
                    <div class="detail-item" style="grid-column: span 2;">
                        <label class="form-label">Last Login</label>
                        <p id="viewUserLastLogin"></p>
                    </div>
                    <?php if (!empty($user['ban_reason'])): ?>
                    <div class="detail-item" style="grid-column: span 2;">
                        <label class="form-label">Ban Reason</label>
                        <p id="viewUserBanReason"></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary close-view-modal">Close</button>
                <button type="button" class="btn btn-primary" id="editUserBtn">Edit User</button>
            </div>
        </div>
    </div>

    <script>
        // Modal functionality
        const addUserBtn = document.getElementById('addUserBtn');
        const addUserModal = document.getElementById('addUserModal');
        const closeModal = document.getElementById('closeModal');
        const cancelModal = document.getElementById('cancelModal');
        const viewUserModal = document.getElementById('viewUserModal');
        const closeViewModal = document.querySelector('.close-view-modal');

        // Add User Modal
        addUserBtn.addEventListener('click', () => {
            addUserModal.classList.add('active');
        });

        closeModal.addEventListener('click', () => {
            addUserModal.classList.remove('active');
        });

        cancelModal.addEventListener('click', () => {
            addUserModal.classList.remove('active');
        });

        // View User Modal
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const userData = JSON.parse(btn.dataset.user);
                
                // Populate modal with user data
                document.getElementById('viewUserName').textContent = userData.fast_name + ' ' + userData.last_name;
                document.getElementById('viewUserUID').textContent = 'UID: ' + userData.user_uid;
                document.getElementById('viewUserPhone').textContent = userData.phone;
                document.getElementById('viewUserStatus').innerHTML = userData.is_banned ? 
                    '<span class="status banned">Banned</span>' : 
                    '<span class="status active">Active</span>';
                document.getElementById('viewUserVerified').textContent = userData.is_verified ? 'Yes' : 'No';
                document.getElementById('viewUserBanned').textContent = userData.is_banned ? 'Yes' : 'No';
                document.getElementById('viewUserWinning').textContent = '৳' + parseFloat(userData.winning_balance).toFixed(2);
                document.getElementById('viewUserGaming').textContent = '৳' + parseFloat(userData.gaming_balance).toFixed(2);
                document.getElementById('viewUserTotalWinnings').textContent = '৳' + parseFloat(userData.total_winnings).toFixed(2);
                document.getElementById('viewUserMatches').textContent = userData.match_played;
                document.getElementById('viewUserReferral').textContent = userData.referral_code || 'None';
                document.getElementById('viewUserReferredBy').textContent = userData.referred_by || 'None';
                document.getElementById('viewUserJoinDate').textContent = new Date(userData.created_at).toLocaleString();
                document.getElementById('viewUserLastLogin').textContent = userData.last_login ? 
                    new Date(userData.last_login).toLocaleString() : 'Never';
                
                if (userData.ban_reason) {
                    document.getElementById('viewUserBanReason').textContent = userData.ban_reason;
                }
                
                viewUserModal.classList.add('active');
            });
        });

        closeViewModal.addEventListener('click', () => {
            viewUserModal.classList.remove('active');
        });

        // Close modals when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === addUserModal) {
                addUserModal.classList.remove('active');
            }
            if (e.target === viewUserModal) {
                viewUserModal.classList.remove('active');
            }
        });

        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function(e) {
            if (e.key === 'Enter') {
                const searchTerm = this.value.trim();
                if (searchTerm) {
                    window.location.href = `users.php?uid=${encodeURIComponent(searchTerm)}&phone=${encodeURIComponent(searchTerm)}`;
                }
            }
        });

        // Edit user button
        document.getElementById('editUserBtn').addEventListener('click', function() {
            const uid = document.getElementById('viewUserUID').textContent.replace('UID: ', '');
            window.location.href = `edit_user.php?uid=${uid}`;
        });
    </script>
</body>
</html>


