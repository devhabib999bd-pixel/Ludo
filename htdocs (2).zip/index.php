<?php
session_start();
require_once 'config.php'; // Database configuration file

// Check if user is logged in
if (!isset($_SESSION['user_uid'])) {
    header("Location: login.php");
    exit();
}

$user_uid = $_SESSION['user_uid'];

// Fetch user data and balance
$user_query = "SELECT gaming_balance, winning_balance, is_banned, ban_reason FROM users WHERE user_uid = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("s", $user_uid);
$stmt->execute();
$user_result = $stmt->get_result();

$gaming_balance = 0;
$winning_balance = 0;
$is_banned = false;
$ban_reason = '';

if ($user_result->num_rows > 0) {
    $user = $user_result->fetch_assoc();
    $gaming_balance = $user['gaming_balance'];
    $winning_balance = $user['winning_balance'];
    $is_banned = $user['is_banned'];
    $ban_reason = $user['ban_reason'];
}
$stmt->close();

// Fetch site information from database
$site_query = "SELECT site_logo, site_name FROM site_info LIMIT 1";
$site_result = $conn->query($site_query);

$site_logo = "to/logo.png"; // Default logo path
$site_name = "LUDO BD"; // Default site name

if ($site_result && $site_result->num_rows > 0) {
    $site_info = $site_result->fetch_assoc();
    $site_logo = $site_info['site_logo'];
    $site_name = $site_info['site_name'];
}

// Fetch latest notice from database
$notice_query = "SELECT notice, notification FROM notification ORDER BY id DESC LIMIT 1";
$notice_result = $conn->query($notice_query);

$scroll_notice = "Welcome to LUDO BD! Explore our latest games and enjoy the experience.";
$popup_notice = "🔕 জরুরী নোটিশ 🔕 ম্যাচের ভিতরে স্টিকার দেওয়া নিষেধ ❌ ম্যাচের ভিতরে ইচ্ছে করে লেট করে মারা নিষেধ। 🚫 আমরা যথাযথ প্রুফ পেলে আপনার ম্যাচ থেকে জরিমানা করা হবে।🛡 এ ধরনের কাজ করলে পাঁচ মিনিটের ভিডিও দিবেন। ভিডিও দেখে যে কোন ডিসিশন এডমিন নিয়ে থাকবে ধন্যবাদ ✅";

if ($notice_result && $notice_result->num_rows > 0) {
    $notice = $notice_result->fetch_assoc();
    $scroll_notice = $notice['notice'] ?? $scroll_notice;
    $popup_notice = $notice['notification'] ?? $popup_notice;
}

// Count active matches
$matches_query = "SELECT COUNT(*) as match_count FROM matches WHERE status = 'waiting'";
$matches_result = $conn->query($matches_query);
$match_count = $matches_result && $matches_result->num_rows > 0 ? $matches_result->fetch_assoc()['match_count'] : 49;

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title><?php echo htmlspecialchars($site_name); ?> - Home</title>
    <link rel="stylesheet" href="home.css">
    <style>
        /* Full-page popup styles for banned users */
        .full-page-popup {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8); /* Semi-transparent background */
            color: #fff;
            padding: 20px;
            box-sizing: border-box;
            z-index: 10000;
            align-items: center;
            justify-content: center;
            text-align: center;
        }
        .full-page-popup-content {
            max-width: 600px;
            background-color: #222;
            padding: 30px;
            border-radius: 10px;
        }
        .full-page-popup-content h2 {
            margin-bottom: 20px;
            font-size: 2em;
        }
        .popup-button {
            background-color: #ff0000;
            color: #fff;
            padding: 10px 20px;
            margin-top: 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.2em;
        }
        .popup-button:hover {
            background-color: #cc0000;
        }
        .contact-button {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            margin-top: 20px;
            margin-left: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.2em;
        }
        .contact-button:hover {
            background-color: #0056b3;
        }
        body.locked {
            overflow: hidden;
            pointer-events: none;
        }
        .locked .full-page-popup {
            pointer-events: auto;
        }
        /* Popup for app notice */
        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 80%;
            max-width: 400px;
            background-color: #222;
            color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            border-radius: 10px;
            z-index: 1000;
        }
        .popup-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        .popup-header h2 {
            margin: 0;
            font-size: 1.5em;
        }
        .popup-header .close-btn {
            background-color: transparent;
            border: none;
            color: #fff;
            font-size: 1.5em;
            cursor: pointer;
        }
        /* Other page styles */
        * {
            outline: none;
            -webkit-tap-highlight-color: transparent;
            user-select: none;
            -webkit-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        a {
            text-decoration: none;
            color: inherit;
            -webkit-touch-callout: none;
            -ms-touch-action: manipulation;
            touch-action: manipulation;
        }

        /* Font-face declarations */
        @font-face {
            font-family: 'HindSiliguri-Medium';
            src: url('font/HindSiliguri-Medium.ttf') format('truetype');
        }

        @font-face {
            font-family: 'HindSiliguri-Bold';
            src: url('font/HindSiliguri-Bold.ttf') format('truetype');
        }

        @font-face {
            font-family: 'LEMONMILK-Regular';
            src: url('./font/LEMONMILK-Regular.otf') format('truetype');
        }

        @font-face {
            font-family: 'FaRegular';
            src: url('font/fa-regular-400.ttf') format('truetype');
        }

        @font-face {
            font-family: 'FaBrands';
            src: url('font/fa-brands-400.ttf') format('truetype');
        }

        @font-face {
            font-family: 'BebasNeue';
            src: url('font/BebasNeue-Regular.otf') format('opentype');
        }

        .banner-slider {
            margin-top: 5px;
            position: relative;
            width: 100%;
            height: 150px; /* Adjust height as needed */
            overflow: hidden;
            margin-bottom: 0px; /* Space between slider and content */
            border-radius: 10px;
        }
        .click-effect:active {
            transform: scale(0.95);
            transition: transform 0.2s ease;
        }
        .slider-image {
            width: 100%;
            height: 150px;
            object-fit: cover;
            transition: opacity 0.5s ease;
            position: absolute;
            top: 0;
            left: 0;
        }
        .slider-image:not(.active) {
            opacity: 0;
        }
        .dot {
            display: inline-block;
            width: 10px;
            height: 10px;
            margin: 0 5px;
            background-color: #bbb;
            border-radius: 50%;
            cursor: pointer;
        }
        .dot.active {
            background-color: gold;
        }
        .scroll-container {
            width: 97%;
            overflow: hidden;
            background-color: #0f172e;
            margin-top: 2px;
            padding: 5px;
            position: relative;
            font-family: Arial, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .scroll-text {
            display: inline-block;
            white-space: nowrap;
            animation: scroll-text 15s linear infinite;
            color: yellow;
            
            font-weight: bold;
            padding-left: 100px; /* Add padding to ensure text is visible */
        }
        .scroll-title {
            position: absolute;
            left: 0px;
            font-weight: bold;
            color: yellow;
            background-color: #0f172e; /* Background color for the notice */
            padding: 5px 10px;
            border-radius: 3px;
            z-index: 2; /* Ensure the notice stays on top */
        }
        @keyframes scroll-text {
            from {
                transform: translateX(60%);
            }
            to {
                transform: translateX(-100%);
            }
        }
        a {
            text-decoration: none; /* Remove underline */
            color: inherit; /* Inherit text color from parent */
        }
        a:hover {
            text-decoration: none; /* Remove underline on hover */
        }
        .vip img {
            height: 25px;
        }
        .vip {
            margin-left: 40px;
            display: flex;
            align-items: center;
            background-color: #222;
            padding: 4px 8px;
            border-radius: 10px;
        }
        main {
            padding: 1px;
            background-color: #1E2538;
            margin-top: 15px;
            margin-right: 10px;
            margin:13px;
            margin-left: 10px;
            border-radius: 3px;
        }
        .matches {
            display: flex;
            align-items: center;
            background-image: url('to/kingbg.jpg');
            background-size: calc(100% - 10px) calc(100% - 1px); /* Adjust size to simulate margin */
            background-position: center; /* Position the image in the center */
            background-repeat: no-repeat; /* Prevent repetition of the image */
            border-radius: 0px;
            height: 160px;
            color: #fff;
            margin-top: 0.6em;
            position: relative;
            z-index: 1;
        }

        .matches::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.1); /* Dark overlay for better readability */
            border-radius: 25px;
            z-index: -1;
        }
        .matches img {
            width: 47px;
            height: 47px;
            border-radius: 1px;
            margin-left: 4px;
        }
        .matches h2 {
            font-size: 16px;
            margin-bottom: 5px;
            font-family: 'Roboto', sans-serif;
            display: flex;
            align-items: center;
        }
        .matches h2 i {
            margin-right: 4px;
            color: #FFC107;
        }
        .matches p {
            font-size: 12px;
            font-family: 'Roboto', sans-serif;
            display: flex;
            align-items: center;
        }
        .matches p i {
            margin-right: 4px;
            color: #FFC107;
        }
        .slider-text-container {
            background-color: #0f172e;
        }

        body {
            margin: 0;
            font-family: 'HindSiliguri-Medium', Arial, sans-serif;
            background-color: #0e0b27; /* Dark background for the entire app */
            color: white;
            display: flex;
            flex-direction: column;
            height: 100vh;
            justify-content: space-between;
        }

        .app-header {
            background-color: #07031e; /* Match the navigation background color */
            height: 50px; /* Set header height to 65px */
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 5px;
        }

        .header-content {
            display: flex;
            align-items: center;
            width: 100%;
        }

        .logo {
            height: 38px; 
            margin-left: 10px;
        }

        .app-title {
            color: white;
            
            margin-left: 1em;
            font-size: 1.07em;
            flex-grow: 1;
            position: relative;
            display: inline-block;
            background: linear-gradient(90deg, #ffffff 10%, #cccccc 20%, #2a5280 30%, #ffffff 40%);
            background-size: 200% auto;
            color: transparent;
            background-clip: text;
            -webkit-background-clip: text;
            text-fill-color: transparent;
            animation: shimmer 3s linear infinite;
            font-family: 'LEMONMILK-Regular', sans-serif;
            letter-spacing: 0.5px;
        }

        @keyframes shimmer {
            0% {
                background-position: -200% 0;
            }
            100% {
                background-position: 200% 0;
            }
        }

        .wallet-icon {
            display: flex;
            align-items: center;
            padding: 5px 10px; /* Padding inside the border */
            border: 2px solid #fff; /* White border */
            border-radius: 40px; /* Rounded corners */
            background-color: #1b1a3a;
            font-size: 0.9em; /* Background color for wallet area */
            font-family: 'HindSiliguri-Medium', sans-serif;
        }

        .wallet-icon img {
            height: 20px; /* Adjust size as needed */
            margin-right: 10px; /* Space between the icon and the balance text */
        }
        .wallet-icon2 {
            display: flex;
            align-items: center;
            padding: 0px; /* Padding inside the border */
            border: 2px solid #fff; /* White border */
            border-radius: 40px; /* Rounded corners */
            background-color: ;
            margin-right: 10px;
            font-size: 0.9em; /* Background color for wallet area */
            font-family: 'HindSiliguri-Medium', sans-serif;
        }

        .wallet-icon2 img {
            height: 30px; /* Adjust size as needed */
            margin-right: 0px; /* Space between the icon and the balance text */
        }

        .balance-text {
            font-size: 1.2em; /* Adjust font size as needed */
            color: white; /* Text color */
        }

        .main-content {
            flex-grow: 1;
            padding: 12px;
            text-align: center;
            background-color: #07031e;
        }

        .bottom-navigation {
            background-color: #07031e; /* Updated background color */
            display: flex;
            justify-content: space-around;
            padding-bottom: 2px;
            position: fixed;
            width: 100%;
            bottom: -5px;
        }

        .nav-item {
            text-align: center;
            color: #ccc;
            text-decoration: none;
            font-size: 0.8.5em;
            transition: transform 0.2s ease, color 0.2s ease, opacity 0.2s ease; /* Add transition for animation */
            cursor: pointer; /* Make the nav item clickable */
            -webkit-tap-highlight-color: transparent; /* Disable tap highlight color */
            opacity: 1; /* Default fully visible */
            font-family: 'HindSiliguri-Medium', sans-serif;
        }

        .nav-item img {
            width: 22px; /* Adjust icon size */
            height: auto;
            display: block;
            margin: 0 auto 5px;
            transition: transform 0.2s ease, opacity 0.2s ease; /* Add transition for animation */
            -webkit-tap-highlight-color: transparent; /* Disable tap highlight color */
        }

        /* Active and hover states */
        .nav-item:hover, .nav-item:focus, .nav-item:active {
            transform: scale(1.1); /* Scale up the icon and text */
            color: #fff; /* Change color to white */
        }

        .nav-item:hover img, .nav-item:focus img, .nav-item:active img {
            transform: scale(1.2); /* Scale up the icon a bit more */
        }

        /* Inactive state when another button is clicked */
        .inactive {
            opacity: 0.5; /* Make other buttons faded */
        }
    </style>
</head>
<body class="<?php echo $is_banned ? 'locked' : ''; ?>">

<!-- Banned user popup -->
<?php if ($is_banned): ?>
<div class="full-page-popup" style="display: block;">
    <div class="full-page-popup-content">
        <h2>Account Banned</h2>
        <p>Your account has been banned. Reason: <?php echo htmlspecialchars($ban_reason); ?></p>
        <button class="popup-button" onclick="window.location.href='logout.php'">Logout</button>
        <button class="contact-button" onclick="window.location.href='redirect_to_telegram.php'">Contact Support</button>
    </div>
</div>
<?php endif; ?>

<header class="app-header">
    <div class="header-content">
        <img src="<?php echo htmlspecialchars($site_logo); ?>" alt="Site Logo" class="logo">
        <h1 class="app-title"><?php echo htmlspecialchars($site_name); ?></h1>

        <!-- Telegram Link Icon -->
        <a href="redirect_to_telegram.php">
            <img src="to/co.png" alt="Click to Redirect" style="width: 35px; height: 35px; margin-right: 10px">
        </a>

        <!-- Notice Link Icon -->
        <a href="javascript:void(0);" onclick="showNoticePopup()">
            <img src="to/12891962.png" alt="Click to Redirect" style="width: 25px; height: 25px; margin-right: 10px">
        </a>

        <!-- Wallet Icon and Balance -->
        <div class="wallet-icon">
            <img src="to/wallet2.png" alt="Wallet">
            <span class="balance-text"><?php echo $gaming_balance + $winning_balance; ?></span>
        </div>
    </div>
</header>

<!-- Popup for app notice -->
<div class="popup" id="appNoticePopup">
    <div class="popup-header">
        <h2>Notice</h2>
        <button class="close-btn" onclick="closePopup()">&times;</button>
    </div>
    <div class="popup-content">
        <p><?php echo htmlspecialchars($popup_notice); ?></p>
    </div>
</div>

<div class="banner-slider">
    <img class="slider-image active bn1" src="to/1.png" alt="Banner 1">
    <img class="slider-image bn2" src="to/2.png" alt="Banner 2">
    <img class="slider-image bn3" src="to/3.png" alt="Banner 3">
</div>

<div class="scroll-container">
    <span class="scroll-title">নোটিশঃ</span>
    <span class="scroll-text"><?php echo htmlspecialchars($scroll_notice); ?></span>
</div>

<div class="main-content">
    <div class="matches ludomatch">
        <img src="to/lodu.png" alt="Ludo King Icon">
        <div>
            <h2><i class="fas fa-chess-board"></i> Ludo Matches</h2>
            <p><i class="fas fa-search"></i> <?php echo $match_count; ?> Matches Found</p>
        </div>
    </div>
</div>

<nav class="bottom-navigation">
    <a href="admin.php" class="nav-item" id="chat">
        <img src="to/chat1.png" alt="Chat">
        <span>Chat</span>
    </a>
    <a href="index.php" class="nav-item" id="play">
        <img src="to/play2.png" alt="Play">
        <span>Play</span>
    </a>
    <a href="profile.php" class="nav-item" id="me">
        <img src="to/profile1.png" alt="Me">
        <span>Me</span>
    </a>
</nav>

<script>
// Function to show the popup
function showNoticePopup() {
    var popup = document.getElementById('appNoticePopup');
    if (popup) {
        popup.style.display = 'block';
    }
}

// Function to close the popup
function closePopup() {
    var popup = document.getElementById('appNoticePopup');
    if (popup) {
        popup.style.display = 'none';
    }
}

// JavaScript for automatic slider
var currentSlide = 0;
var slides = document.querySelectorAll('.slider-image');
var slideInterval = setInterval(nextSlide, 3000);

function nextSlide() {
    slides[currentSlide].classList.remove('active');
    currentSlide = (currentSlide + 1) % slides.length;
    slides[currentSlide].classList.add('active');
}

// Navigation functions
function navigateTo(url) {
    window.location.href = url;
}

document.querySelector('.ludomatch').addEventListener('click', function() {
    navigateTo('ludomatch.php');
});

document.querySelector('.wallet-icon').addEventListener('click', function() {
    navigateTo('mywallet.php');
});

// Click events for banner navigation
document.querySelector('.bn1').addEventListener('click', function() {
    navigateTo('#');
});
document.querySelector('.bn2').addEventListener('click', function() {
    navigateTo('#');
});
document.querySelector('.bn3').addEventListener('click', function() {
    navigateTo('#');
});

// Security measures
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});

document.addEventListener('mousedown', function(e) {
    if (e.button === 2 || e.button === 3) {
        e.preventDefault();
    }
});

// Prevent link from showing on long press
document.querySelectorAll('a').forEach(function(link) {
    link.addEventListener('touchstart', function() {
        this.setAttribute('data-href', this.getAttribute('href'));
        this.removeAttribute('href');
    });

    link.addEventListener('touchend', function() {
        this.setAttribute('href', this.getAttribute('data-href'));
    });

    link.addEventListener('touchmove', function() {
        this.setAttribute('href', this.getAttribute('data-href'));
    });
});
</script>

</body>
</html>